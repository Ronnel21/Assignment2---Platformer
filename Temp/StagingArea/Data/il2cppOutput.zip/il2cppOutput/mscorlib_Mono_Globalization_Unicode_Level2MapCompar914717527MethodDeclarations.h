﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.Level2MapComparer
struct Level2MapComparer_t914717527;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Object2689449295.h"

// System.Void Mono.Globalization.Unicode.Level2MapComparer::.ctor()
extern "C"  void Level2MapComparer__ctor_m28475402 (Level2MapComparer_t914717527 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void Mono.Globalization.Unicode.Level2MapComparer::.cctor()
extern "C"  void Level2MapComparer__cctor_m3753124597 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Int32 Mono.Globalization.Unicode.Level2MapComparer::Compare(System.Object,System.Object)
extern "C"  int32_t Level2MapComparer_Compare_m2537942367 (Level2MapComparer_t914717527 * __this, Il2CppObject * ___o10, Il2CppObject * ___o21, const MethodInfo* method) IL2CPP_METHOD_ATTR;
