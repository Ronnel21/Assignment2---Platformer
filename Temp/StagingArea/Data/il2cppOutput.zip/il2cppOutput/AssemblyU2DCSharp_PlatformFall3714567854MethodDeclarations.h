﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// PlatformFall
struct PlatformFall_t3714567854;
// UnityEngine.Collision2D
struct Collision2D_t1539500754;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Collision2D1539500754.h"

// System.Void PlatformFall::.ctor()
extern "C"  void PlatformFall__ctor_m1587340359 (PlatformFall_t3714567854 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void PlatformFall::Awake()
extern "C"  void PlatformFall_Awake_m3477407450 (PlatformFall_t3714567854 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void PlatformFall::Update()
extern "C"  void PlatformFall_Update_m4166893336 (PlatformFall_t3714567854 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void PlatformFall::onCollisionEnter2D(UnityEngine.Collision2D)
extern "C"  void PlatformFall_onCollisionEnter2D_m1318076185 (PlatformFall_t3714567854 * __this, Collision2D_t1539500754 * ___other0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void PlatformFall::Fall()
extern "C"  void PlatformFall_Fall_m460228584 (PlatformFall_t3714567854 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
