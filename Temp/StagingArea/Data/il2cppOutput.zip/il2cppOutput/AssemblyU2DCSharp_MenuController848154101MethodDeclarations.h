﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// MenuController
struct MenuController_t848154101;

#include "codegen/il2cpp-codegen.h"

// System.Void MenuController::.ctor()
extern "C"  void MenuController__ctor_m1077658770 (MenuController_t848154101 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void MenuController::Start()
extern "C"  void MenuController_Start_m3141389506 (MenuController_t848154101 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void MenuController::Update()
extern "C"  void MenuController_Update_m843216889 (MenuController_t848154101 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void MenuController::StartButton_Click()
extern "C"  void MenuController_StartButton_Click_m3360109091 (MenuController_t848154101 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
