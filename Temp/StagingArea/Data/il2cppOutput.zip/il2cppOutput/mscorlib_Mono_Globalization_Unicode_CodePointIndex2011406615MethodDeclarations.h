﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.CodePointIndexer/TableRange
struct TableRange_t2011406615;
struct TableRange_t2011406615_marshaled_pinvoke;
struct TableRange_t2011406615_marshaled_com;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_Mono_Globalization_Unicode_CodePointIndex2011406615.h"

// System.Void Mono.Globalization.Unicode.CodePointIndexer/TableRange::.ctor(System.Int32,System.Int32,System.Int32)
extern "C"  void TableRange__ctor_m1944319286 (TableRange_t2011406615 * __this, int32_t ___start0, int32_t ___end1, int32_t ___indexStart2, const MethodInfo* method) IL2CPP_METHOD_ATTR;

// Methods for marshaling
struct TableRange_t2011406615;
struct TableRange_t2011406615_marshaled_pinvoke;

extern "C" void TableRange_t2011406615_marshal_pinvoke(const TableRange_t2011406615& unmarshaled, TableRange_t2011406615_marshaled_pinvoke& marshaled);
extern "C" void TableRange_t2011406615_marshal_pinvoke_back(const TableRange_t2011406615_marshaled_pinvoke& marshaled, TableRange_t2011406615& unmarshaled);
extern "C" void TableRange_t2011406615_marshal_pinvoke_cleanup(TableRange_t2011406615_marshaled_pinvoke& marshaled);

// Methods for marshaling
struct TableRange_t2011406615;
struct TableRange_t2011406615_marshaled_com;

extern "C" void TableRange_t2011406615_marshal_com(const TableRange_t2011406615& unmarshaled, TableRange_t2011406615_marshaled_com& marshaled);
extern "C" void TableRange_t2011406615_marshal_com_back(const TableRange_t2011406615_marshaled_com& marshaled, TableRange_t2011406615& unmarshaled);
extern "C" void TableRange_t2011406615_marshal_com_cleanup(TableRange_t2011406615_marshaled_com& marshaled);
