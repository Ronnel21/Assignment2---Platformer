﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_ArgIterator2628088752.h"
#include "mscorlib_System_Object2689449295.h"

// System.Boolean System.ArgIterator::Equals(System.Object)
extern "C"  bool ArgIterator_Equals_m2415994310 (ArgIterator_t2628088752 * __this, Il2CppObject * ___o0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Int32 System.ArgIterator::GetHashCode()
extern "C"  int32_t ArgIterator_GetHashCode_m1527754670 (ArgIterator_t2628088752 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
