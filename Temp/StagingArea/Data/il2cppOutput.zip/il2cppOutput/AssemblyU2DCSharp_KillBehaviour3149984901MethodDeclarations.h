﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// KillBehaviour
struct KillBehaviour_t3149984901;
// UnityEngine.Collision2D
struct Collision2D_t1539500754;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Collision2D1539500754.h"

// System.Void KillBehaviour::.ctor()
extern "C"  void KillBehaviour__ctor_m1997008466 (KillBehaviour_t3149984901 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void KillBehaviour::OnCollisionEnter2D(UnityEngine.Collision2D)
extern "C"  void KillBehaviour_OnCollisionEnter2D_m3271917484 (KillBehaviour_t3149984901 * __this, Collision2D_t1539500754 * ___other0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
