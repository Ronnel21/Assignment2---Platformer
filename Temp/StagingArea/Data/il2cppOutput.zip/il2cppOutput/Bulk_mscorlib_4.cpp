﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>

// System.Runtime.CompilerServices.CompilerGeneratedAttribute
struct CompilerGeneratedAttribute_t497097752;
// System.Runtime.CompilerServices.DecimalConstantAttribute
struct DecimalConstantAttribute_t569828555;
// System.Runtime.CompilerServices.DefaultDependencyAttribute
struct DefaultDependencyAttribute_t3858269114;
// System.Runtime.CompilerServices.InternalsVisibleToAttribute
struct InternalsVisibleToAttribute_t1037732567;
// System.String
struct String_t;
// System.Runtime.CompilerServices.RuntimeCompatibilityAttribute
struct RuntimeCompatibilityAttribute_t2430705542;
// System.Array
struct Il2CppArray;
// System.Runtime.CompilerServices.StringFreezingAttribute
struct StringFreezingAttribute_t2691375565;
// System.Runtime.ConstrainedExecution.CriticalFinalizerObject
struct CriticalFinalizerObject_t1920899984;
// System.Runtime.ConstrainedExecution.ReliabilityContractAttribute
struct ReliabilityContractAttribute_t1625655220;
// System.Runtime.InteropServices.ClassInterfaceAttribute
struct ClassInterfaceAttribute_t910653559;
// System.Runtime.InteropServices.ComDefaultInterfaceAttribute
struct ComDefaultInterfaceAttribute_t347642415;
// System.Type
struct Type_t;
// System.Runtime.InteropServices.COMException
struct COMException_t1790481504;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t228987430;
// System.Runtime.InteropServices.ComImportAttribute
struct ComImportAttribute_t468083054;
// System.Runtime.InteropServices.ComVisibleAttribute
struct ComVisibleAttribute_t2245573759;
// System.Runtime.InteropServices.DispIdAttribute
struct DispIdAttribute_t607560947;
// System.Runtime.InteropServices.DllImportAttribute
struct DllImportAttribute_t3000813225;
// System.Runtime.InteropServices.ExternalException
struct ExternalException_t1252662682;
// System.Runtime.InteropServices.FieldOffsetAttribute
struct FieldOffsetAttribute_t1553145711;
// System.Object
struct Il2CppObject;
// System.Runtime.InteropServices.GuidAttribute
struct GuidAttribute_t222072359;
// System.Runtime.InteropServices.InAttribute
struct InAttribute_t1394050551;
// System.Runtime.InteropServices.InterfaceTypeAttribute
struct InterfaceTypeAttribute_t4113096249;
// System.Byte[]
struct ByteU5BU5D_t3397334013;
// System.Char[]
struct CharU5BU5D_t1328083999;
// System.Runtime.InteropServices.MarshalAsAttribute
struct MarshalAsAttribute_t2900773360;
// System.Runtime.InteropServices.MarshalDirectiveException
struct MarshalDirectiveException_t1326890414;
// System.Runtime.InteropServices.OptionalAttribute
struct OptionalAttribute_t827982902;
// System.Runtime.InteropServices.OutAttribute
struct OutAttribute_t1539424546;
// System.Runtime.InteropServices.PreserveSigAttribute
struct PreserveSigAttribute_t1564965109;
// System.Runtime.InteropServices.SafeHandle
struct SafeHandle_t2733794115;
// System.Runtime.InteropServices.TypeLibImportClassAttribute
struct TypeLibImportClassAttribute_t2390314680;
// System.Runtime.InteropServices.TypeLibVersionAttribute
struct TypeLibVersionAttribute_t3346496961;
// System.Runtime.Remoting.ActivatedClientTypeEntry
struct ActivatedClientTypeEntry_t4060499430;
// System.Runtime.Remoting.Contexts.IContextAttribute[]
struct IContextAttributeU5BU5D_t435398453;
// System.Runtime.Remoting.ActivatedServiceTypeEntry
struct ActivatedServiceTypeEntry_t3934090848;
// System.Runtime.Remoting.Activation.IActivator
struct IActivator_t1538980900;
// System.Object[]
struct ObjectU5BU5D_t3614634134;
// System.Runtime.Remoting.Messaging.ConstructionCall
struct ConstructionCall_t1254994451;
// System.Runtime.Remoting.Activation.AppDomainLevelActivator
struct AppDomainLevelActivator_t834876328;
// System.Runtime.Remoting.Activation.ConstructionLevelActivator
struct ConstructionLevelActivator_t2284932402;
// System.Runtime.Remoting.Activation.ContextLevelActivator
struct ContextLevelActivator_t1784331636;
// System.Runtime.Remoting.Activation.UrlAttribute
struct UrlAttribute_t1544437301;
// System.Runtime.Remoting.Activation.IConstructionCallMessage
struct IConstructionCallMessage_t2459197515;
// System.Runtime.Remoting.Contexts.Context
struct Context_t502196753;
// System.Runtime.Remoting.ChannelData
struct ChannelData_t1489610737;
// System.Collections.ArrayList
struct ArrayList_t4252133567;
// System.Collections.Hashtable
struct Hashtable_t909839986;
// System.Runtime.Remoting.ChannelInfo
struct ChannelInfo_t709892715;
// System.Runtime.Remoting.Messaging.IMessageSink
struct IMessageSink_t2189618969;
// System.Runtime.Remoting.Channels.IChannelSender
struct IChannelSender_t714647579;
// System.Runtime.Remoting.Channels.IChannel
struct IChannel_t321318132;
// System.Runtime.Remoting.ProviderData
struct ProviderData_t2518653487;
// System.Runtime.Remoting.Channels.CrossAppDomainChannel
struct CrossAppDomainChannel_t2471623380;
// System.Runtime.Remoting.Channels.CrossAppDomainData
struct CrossAppDomainData_t816071813;
// System.Runtime.Remoting.Channels.CrossAppDomainSink
struct CrossAppDomainSink_t2368859578;
// System.Runtime.Remoting.Channels.SinkProviderData
struct SinkProviderData_t2645445792;
// System.Collections.IList
struct IList_t3321498491;
// System.Collections.IDictionary
struct IDictionary_t596158605;
// System.Runtime.Remoting.ClientActivatedIdentity
struct ClientActivatedIdentity_t1467784146;
// System.MarshalByRefObject
struct MarshalByRefObject_t1285298191;
// System.Runtime.Remoting.ClientIdentity
struct ClientIdentity_t2254682501;
// System.Runtime.Remoting.ObjRef
struct ObjRef_t318414488;
// System.Runtime.Remoting.ConfigHandler
struct ConfigHandler_t2180714860;
// System.String[]
struct StringU5BU5D_t1642385972;
// Mono.Xml.SmallXmlParser
struct SmallXmlParser_t3549787957;
// Mono.Xml.SmallXmlParser/IAttrList
struct IAttrList_t4064541270;
// System.Runtime.Remoting.Contexts.IContextProperty[]
struct IContextPropertyU5BU5D_t977923046;
// System.Runtime.Remoting.Contexts.IDynamicProperty
struct IDynamicProperty_t603529997;
// System.ContextBoundObject
struct ContextBoundObject_t4264702438;
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection
struct DynamicPropertyCollection_t2282532998;
// System.Runtime.Remoting.Messaging.IMessage
struct IMessage_t3044378324;
// System.Runtime.Remoting.Contexts.IContextProperty
struct IContextProperty_t287246399;
// System.Runtime.Remoting.Contexts.CrossContextDelegate
struct CrossContextDelegate_t754146990;
// System.LocalDataStoreSlot
struct LocalDataStoreSlot_t486331200;
// System.Runtime.Remoting.Contexts.ContextAttribute
struct ContextAttribute_t197102333;
// System.Runtime.Remoting.Contexts.ContextCallbackObject
struct ContextCallbackObject_t3978189709;
// System.Runtime.Remoting.Contexts.CrossContextChannel
struct CrossContextChannel_t2302426108;
// System.IAsyncResult
struct IAsyncResult_t1999651008;
// System.AsyncCallback
struct AsyncCallback_t163412349;
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection/DynamicPropertyReg
struct DynamicPropertyReg_t1839195831;
// System.Runtime.Remoting.Contexts.SynchronizationAttribute
struct SynchronizationAttribute_t3073724998;
// System.Runtime.Remoting.Contexts.SynchronizedClientContextSink
struct SynchronizedClientContextSink_t3779986825;
// System.Runtime.Remoting.Contexts.SynchronizedServerContextSink
struct SynchronizedServerContextSink_t462987365;
// System.Runtime.Remoting.EnvoyInfo
struct EnvoyInfo_t815109115;
// System.Runtime.Remoting.FormatterData
struct FormatterData_t12176916;
// System.Runtime.Remoting.Identity
struct Identity_t3647548000;
// System.Runtime.Remoting.Metadata.SoapAttribute
struct SoapAttribute_t1982224933;
// System.Runtime.Remoting.Lifetime.LeaseManager
struct LeaseManager_t1025868639;
// System.Runtime.Remoting.Lifetime.LeaseSink
struct LeaseSink_t3007073869;
// System.Runtime.Remoting.Messaging.ArgInfo
struct ArgInfo_t688271106;
// System.Reflection.MethodBase
struct MethodBase_t904190842;
// System.Runtime.Remoting.Messaging.AsyncResult
struct AsyncResult_t2232356043;
// System.Threading.WaitHandle
struct WaitHandle_t677569169;
// System.Runtime.Remoting.Messaging.IMessageCtrl
struct IMessageCtrl_t2081697019;
// System.Runtime.Remoting.Messaging.MonoMethodMessage
struct MonoMethodMessage_t771543475;
// System.Runtime.Remoting.Messaging.CallContextRemotingData
struct CallContextRemotingData_t2648008188;
// System.Runtime.Remoting.Messaging.ClientContextTerminatorSink
struct ClientContextTerminatorSink_t3236389774;
// System.Runtime.Remoting.Messaging.ConstructionCallDictionary
struct ConstructionCallDictionary_t2993650247;
// System.Runtime.Remoting.Messaging.EnvoyTerminatorSink
struct EnvoyTerminatorSink_t3043186997;
// System.Runtime.Remoting.Messaging.Header
struct Header_t2756440555;
// System.Runtime.Remoting.Messaging.HeaderHandler
struct HeaderHandler_t324204131;
// System.Runtime.Remoting.Messaging.Header[]
struct HeaderU5BU5D_t2408360458;
// System.Runtime.Remoting.Messaging.LogicalCallContext
struct LogicalCallContext_t725724420;
// System.Runtime.Remoting.Messaging.MethodCall
struct MethodCall_t2461541281;
// System.Type[]
struct TypeU5BU5D_t1664964607;
// System.Runtime.Remoting.Messaging.MethodCallDictionary
struct MethodCallDictionary_t1516131009;
// System.Runtime.Remoting.Messaging.IMethodMessage
struct IMethodMessage_t1899389025;
// System.Runtime.Remoting.Messaging.MethodDictionary
struct MethodDictionary_t1742974787;
// System.Collections.IEnumerator
struct IEnumerator_t1466026749;
// System.Collections.ICollection
struct ICollection_t91669223;
// System.Collections.IDictionaryEnumerator
struct IDictionaryEnumerator_t259680273;
// System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator
struct DictionaryEnumerator_t492828146;
// System.Runtime.Remoting.Messaging.MethodReturnDictionary
struct MethodReturnDictionary_t981009581;
// System.Runtime.Remoting.Messaging.IMethodReturnMessage
struct IMethodReturnMessage_t323645523;
// System.Exception
struct Exception_t1927440687;
// System.Runtime.Remoting.Messaging.ObjRefSurrogate
struct ObjRefSurrogate_t3912784830;
// System.Runtime.Serialization.ISurrogateSelector
struct ISurrogateSelector_t1912587528;
// System.Runtime.Remoting.Messaging.RemotingSurrogate
struct RemotingSurrogate_t3248446683;
// System.Runtime.Remoting.Messaging.RemotingSurrogateSelector
struct RemotingSurrogateSelector_t2821375126;
// System.Runtime.Serialization.ISerializationSurrogate
struct ISerializationSurrogate_t1282780357;
// System.Runtime.Remoting.Messaging.ReturnMessage
struct ReturnMessage_t3411975905;
// System.Runtime.Remoting.Messaging.IMethodCallMessage
struct IMethodCallMessage_t645865707;
// System.Runtime.Remoting.Messaging.ServerContextTerminatorSink
struct ServerContextTerminatorSink_t1054294306;

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Array3829468939.h"
#include "mscorlib_System_Runtime_CompilerServices_CompilerGe497097752.h"
#include "mscorlib_System_Runtime_CompilerServices_CompilerGe497097752MethodDeclarations.h"
#include "mscorlib_System_Void1841601450.h"
#include "mscorlib_System_Attribute542643598MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_DecimalCon569828555.h"
#include "mscorlib_System_Runtime_CompilerServices_DecimalCon569828555MethodDeclarations.h"
#include "mscorlib_System_Byte3683104436.h"
#include "mscorlib_System_UInt322149682021.h"
#include "mscorlib_System_Convert2607082565MethodDeclarations.h"
#include "mscorlib_System_Boolean3825574718.h"
#include "mscorlib_System_Int322071877448.h"
#include "mscorlib_System_Runtime_CompilerServices_DefaultDe3858269114.h"
#include "mscorlib_System_Runtime_CompilerServices_DefaultDe3858269114MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_LoadHint3781660191.h"
#include "mscorlib_System_Runtime_CompilerServices_Internals1037732567.h"
#include "mscorlib_System_Runtime_CompilerServices_Internals1037732567MethodDeclarations.h"
#include "mscorlib_System_String2029220233.h"
#include "mscorlib_System_Runtime_CompilerServices_IsVolatile700755342.h"
#include "mscorlib_System_Runtime_CompilerServices_IsVolatile700755342MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_LoadHint3781660191MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeCo2430705542.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeCo2430705542MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeHel266230107.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeHel266230107MethodDeclarations.h"
#include "mscorlib_System_IntPtr2504060609.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674.h"
#include "mscorlib_System_IntPtr2504060609MethodDeclarations.h"
#include "mscorlib_System_ArgumentNullException628810857MethodDeclarations.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674MethodDeclarations.h"
#include "mscorlib_System_ArgumentNullException628810857.h"
#include "mscorlib_System_Runtime_CompilerServices_StringFre2691375565.h"
#include "mscorlib_System_Runtime_CompilerServices_StringFre2691375565MethodDeclarations.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Cer2101567438.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Cer2101567438MethodDeclarations.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Consi1390725888.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Consi1390725888MethodDeclarations.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Criti1920899984.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Criti1920899984MethodDeclarations.h"
#include "mscorlib_System_Object2689449295MethodDeclarations.h"
#include "mscorlib_System_Object2689449295.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Relia1625655220.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Relia1625655220MethodDeclarations.h"
#include "mscorlib_System_Runtime_Hosting_ActivationArguments640021366.h"
#include "mscorlib_System_Runtime_Hosting_ActivationArguments640021366MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_CallingCon3354538265.h"
#include "mscorlib_System_Runtime_InteropServices_CallingCon3354538265MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_CharSet2778376310.h"
#include "mscorlib_System_Runtime_InteropServices_CharSet2778376310MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf910653559.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf910653559MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf295178211.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf295178211MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ComDefaultI347642415.h"
#include "mscorlib_System_Runtime_InteropServices_ComDefaultI347642415MethodDeclarations.h"
#include "mscorlib_System_Type1303803226.h"
#include "mscorlib_System_Runtime_InteropServices_COMExcepti1790481504.h"
#include "mscorlib_System_Runtime_InteropServices_COMExcepti1790481504MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ExternalEx1252662682MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon1417235061.h"
#include "mscorlib_System_Exception1927440687MethodDeclarations.h"
#include "mscorlib_System_Environment3662374671MethodDeclarations.h"
#include "mscorlib_System_String2029220233MethodDeclarations.h"
#include "mscorlib_ArrayTypes.h"
#include "mscorlib_System_Exception1927440687.h"
#include "mscorlib_System_Runtime_InteropServices_ComImportAt468083054.h"
#include "mscorlib_System_Runtime_InteropServices_ComImportAt468083054MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ComInterfa1898221498.h"
#include "mscorlib_System_Runtime_InteropServices_ComInterfa1898221498MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ComVisible2245573759.h"
#include "mscorlib_System_Runtime_InteropServices_ComVisible2245573759MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_DispIdAttri607560947.h"
#include "mscorlib_System_Runtime_InteropServices_DispIdAttri607560947MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_DllImportA3000813225.h"
#include "mscorlib_System_Runtime_InteropServices_DllImportA3000813225MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ErrorWrapp2775489663.h"
#include "mscorlib_System_Runtime_InteropServices_ErrorWrapp2775489663MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ExternalEx1252662682.h"
#include "mscorlib_Locale4255929014MethodDeclarations.h"
#include "mscorlib_System_SystemException3877406272MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_FieldOffse1553145711.h"
#include "mscorlib_System_Runtime_InteropServices_FieldOffse1553145711MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandle3409268066.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandle3409268066MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandleTy1970708122.h"
#include "mscorlib_System_InvalidOperationException721527559MethodDeclarations.h"
#include "mscorlib_System_InvalidOperationException721527559.h"
#include "mscorlib_System_Int322071877448MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandleTy1970708122MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_GuidAttribu222072359.h"
#include "mscorlib_System_Runtime_InteropServices_GuidAttribu222072359MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_InAttribut1394050551.h"
#include "mscorlib_System_Runtime_InteropServices_InAttribut1394050551MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_InterfaceT4113096249.h"
#include "mscorlib_System_Runtime_InteropServices_InterfaceT4113096249MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_Marshal785896760.h"
#include "mscorlib_System_Runtime_InteropServices_Marshal785896760MethodDeclarations.h"
#include "mscorlib_System_OperatingSystem290860502MethodDeclarations.h"
#include "mscorlib_System_OperatingSystem290860502.h"
#include "mscorlib_System_PlatformID1006634368.h"
#include "mscorlib_System_Char3454481338.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalAsA2900773360.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalAsA2900773360MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_UnmanagedT2550630890.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalDir1326890414.h"
#include "mscorlib_System_Runtime_InteropServices_MarshalDir1326890414MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_OptionalAtt827982902.h"
#include "mscorlib_System_Runtime_InteropServices_OptionalAtt827982902MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_OutAttribu1539424546.h"
#include "mscorlib_System_Runtime_InteropServices_OutAttribu1539424546MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_PreserveSi1564965109.h"
#include "mscorlib_System_Runtime_InteropServices_PreserveSi1564965109MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_SafeHandle2733794115.h"
#include "mscorlib_System_Runtime_InteropServices_SafeHandle2733794115MethodDeclarations.h"
#include "mscorlib_System_ObjectDisposedException2695136451MethodDeclarations.h"
#include "mscorlib_System_Threading_Interlocked1625106012MethodDeclarations.h"
#include "mscorlib_System_Type1303803226MethodDeclarations.h"
#include "mscorlib_System_ObjectDisposedException2695136451.h"
#include "mscorlib_System_GC2902933594MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibImp2390314680.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibImp2390314680MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibVer3346496961.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibVer3346496961MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_UnmanagedT2550630890MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedClientTy4060499430.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedClientTy4060499430MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_TypeEntry3321373506MethodDeclarations.h"
#include "mscorlib_System_Reflection_Assembly4268412390MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_RemotingException109604560MethodDeclarations.h"
#include "mscorlib_System_Reflection_Assembly4268412390.h"
#include "mscorlib_System_Runtime_Remoting_RemotingException109604560.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedServiceT3934090848.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedServiceT3934090848MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Activa1532663650.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Activa1532663650MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Constr2284932402MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Constr2284932402.h"
#include "mscorlib_System_Runtime_Remoting_Activation_UrlAtt1544437301MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_RemotingServices2399536837MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_RemotingConfigurat438177651MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_UrlAtt1544437301.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru1254994451.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru1254994451MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_AppDoma834876328MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Contex1784331636MethodDeclarations.h"
#include "mscorlib_System_Collections_ArrayList4252133567MethodDeclarations.h"
#include "mscorlib_System_Threading_Thread241561612MethodDeclarations.h"
#include "mscorlib_System_Collections_ArrayList4252133567.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Context502196753.h"
#include "mscorlib_System_Runtime_Remoting_Activation_AppDoma834876328.h"
#include "mscorlib_System_Runtime_Remoting_Activation_Contex1784331636.h"
#include "mscorlib_System_Runtime_Remoting_Channels_ChannelS2007814595.h"
#include "mscorlib_System_Runtime_Remoting_Channels_ChannelS2007814595MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberInfo4043097260MethodDeclarations.h"
#include "mscorlib_System_Reflection_MemberInfo4043097260.h"
#include "mscorlib_System_Runtime_Remoting_Activation_RemoteA213750447.h"
#include "mscorlib_System_Runtime_Remoting_Activation_RemoteA213750447MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ChannelData1489610737.h"
#include "mscorlib_System_Runtime_Remoting_ChannelData1489610737MethodDeclarations.h"
#include "mscorlib_System_Collections_Hashtable909839986MethodDeclarations.h"
#include "mscorlib_System_Collections_Hashtable909839986.h"
#include "mscorlib_System_Runtime_Remoting_ProviderData2518653487MethodDeclarations.h"
#include "mscorlib_System_Collections_DictionaryEntry3048875398.h"
#include "mscorlib_System_Runtime_Remoting_ProviderData2518653487.h"
#include "mscorlib_System_Collections_DictionaryEntry3048875398MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ChannelInfo709892715.h"
#include "mscorlib_System_Runtime_Remoting_ChannelInfo709892715MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCon2302426108MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCon2302426108.h"
#include "mscorlib_System_Threading_Monitor3228523394MethodDeclarations.h"
#include "mscorlib_System_Reflection_ConstructorInfo2851816542MethodDeclarations.h"
#include "mscorlib_System_Reflection_ConstructorInfo2851816542.h"
#include "mscorlib_System_Reflection_TargetInvocationExcepti4098620458.h"
#include "mscorlib_System_RuntimeTypeHandle2330101084.h"
#include "mscorlib_System_Activator1850728717MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2471623380.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2471623380MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossAppD816071813MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossAppD816071813.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2368859578MethodDeclarations.h"
#include "mscorlib_System_NotSupportedException1793819818MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Channels_CrossApp2368859578.h"
#include "mscorlib_System_NotSupportedException1793819818.h"
#include "mscorlib_System_Reflection_MethodInfo3330546337.h"
#include "mscorlib_System_Reflection_BindingFlags1082350898.h"
#include "mscorlib_System_Runtime_Remoting_Channels_SinkProv2645445792.h"
#include "mscorlib_System_Runtime_Remoting_Channels_SinkProv2645445792MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ClientActivatedId1467784146.h"
#include "mscorlib_System_Runtime_Remoting_ClientActivatedId1467784146MethodDeclarations.h"
#include "mscorlib_System_MarshalByRefObject1285298191.h"
#include "mscorlib_System_Runtime_Remoting_ServerIdentity1656058977.h"
#include "mscorlib_System_Runtime_Remoting_ClientIdentity2254682501.h"
#include "mscorlib_System_Runtime_Remoting_ClientIdentity2254682501MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ObjRef318414488.h"
#include "mscorlib_System_Runtime_Remoting_Identity3647548000MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Identity3647548000.h"
#include "mscorlib_System_Runtime_Remoting_ObjRef318414488MethodDeclarations.h"
#include "mscorlib_System_WeakReference1077405567.h"
#include "mscorlib_System_WeakReference1077405567MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_ConfigHandler2180714860.h"
#include "mscorlib_System_Runtime_Remoting_ConfigHandler2180714860MethodDeclarations.h"
#include "mscorlib_System_Globalization_CultureInfo3500843524MethodDeclarations.h"
#include "mscorlib_System_Globalization_CompareInfo2310920157.h"
#include "mscorlib_System_Globalization_CultureInfo3500843524.h"
#include "mscorlib_System_Globalization_CompareInfo2310920157MethodDeclarations.h"
#include "mscorlib_System_Globalization_CompareOptions2829943955.h"
#include "mscorlib_Mono_Xml_SmallXmlParser3549787957.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_g3986656710MethodDeclarations.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_g3986656710.h"
#include "mscorlib_System_Collections_Stack1043988394.h"
#include "mscorlib_System_Collections_Stack1043988394MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_Lifetime2939669377MethodDeclarations.h"
#include "mscorlib_System_TimeSpan3430258949.h"
#include "mscorlib_System_Double4078015681MethodDeclarations.h"
#include "mscorlib_System_TimeSpan3430258949MethodDeclarations.h"
#include "mscorlib_System_Double4078015681.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E1486305137.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E1486305137MethodDeclarations.h"
#include "mscorlib_U3CPrivateImplementationDetailsU3E_U24Arr1957337327.h"
#include "mscorlib_System_Runtime_Remoting_FormatterData12176916MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_FormatterData12176916.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownClientTy3314744170MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownClientTy3314744170.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownServiceT1712728956MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownObjectMo2630225581.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownServiceT1712728956.h"
#include "mscorlib_System_Runtime_Remoting_SoapServices3397513225MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Context502196753MethodDeclarations.h"
#include "mscorlib_System_AppDomain2719102437MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP2282532998MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP2282532998.h"
#include "mscorlib_System_ContextBoundObject4264702438.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_RealProxy298428346MethodDeclarations.h"
#include "mscorlib_System_MarshalByRefObject1285298191MethodDeclarations.h"
#include "mscorlib_System_ArgumentException3259014390MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_RealProxy298428346.h"
#include "mscorlib_System_ArgumentException3259014390.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ClientC3236389774.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ServerC1054294306MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ServerC1054294306.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ClientC3236389774MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_StackBu1613771438MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ServerO4261369100MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseSin3007073869MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_StackBu1613771438.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ServerO4261369100.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseSin3007073869.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_EnvoyTe3043186997.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_EnvoyTe3043186997MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCont754146990.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextC3978189709MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextC3978189709.h"
#include "mscorlib_System_LocalDataStoreSlot486331200.h"
#include "mscorlib_System_LocalDataStoreSlot486331200MethodDeclarations.h"
#include "mscorlib_System_Array3829468939MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextAt197102333.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_ContextAt197102333MethodDeclarations.h"
#include "mscorlib_System_ContextBoundObject4264702438MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_CrossCont754146990MethodDeclarations.h"
#include "mscorlib_System_AsyncCallback163412349.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP1839195831MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_DynamicP1839195831.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3073724998.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3073724998MethodDeclarations.h"
#include "mscorlib_System_Threading_Mutex297030111MethodDeclarations.h"
#include "mscorlib_System_Threading_Mutex297030111.h"
#include "mscorlib_System_Threading_WaitHandle677569169MethodDeclarations.h"
#include "mscorlib_System_Threading_WaitHandle677569169.h"
#include "mscorlib_System_Threading_Thread241561612.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3779986825MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchron3779986825.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchroni462987365MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Contexts_Synchroni462987365.h"
#include "mscorlib_System_Runtime_Remoting_EnvoyInfo815109115.h"
#include "mscorlib_System_Runtime_Remoting_EnvoyInfo815109115MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_InternalRemotingS3953136710.h"
#include "mscorlib_System_Runtime_Remoting_InternalRemotingS3953136710MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapAttr1982224933.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapType3444503085MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapFiel3073759685MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapMeth2381910676MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapPara2780084514MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapType3444503085.h"
#include "mscorlib_System_Reflection_FieldInfo255040150.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapFiel3073759685.h"
#include "mscorlib_System_Reflection_MethodBase904190842.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapMeth2381910676.h"
#include "mscorlib_System_Reflection_ParameterInfo2249040075.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapPara2780084514.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapAttr1982224933MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseMan1025868639.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_LeaseMan1025868639MethodDeclarations.h"
#include "mscorlib_System_Threading_Timer791717973MethodDeclarations.h"
#include "mscorlib_System_Threading_Timer791717973.h"
#include "mscorlib_System_Runtime_Remoting_Lifetime_Lifetime2939669377.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo688271106.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo688271106MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo3252846202.h"
#include "mscorlib_System_Reflection_ParameterInfo2249040075MethodDeclarations.h"
#include "mscorlib_System_Reflection_MethodBase904190842MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ArgInfo3252846202MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_AsyncRe2232356043.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_AsyncRe2232356043MethodDeclarations.h"
#include "mscorlib_System_Threading_ManualResetEvent926074657MethodDeclarations.h"
#include "mscorlib_System_Threading_ManualResetEvent926074657.h"
#include "mscorlib_System_Threading_EventWaitHandle2091316307MethodDeclarations.h"
#include "mscorlib_System_AsyncCallback163412349MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MonoMeth771543475.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_CallCon2648008188.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_CallCon2648008188MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC2461541281MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru2993650247MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodD1742974787MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Constru2993650247.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC2461541281.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodD1742974787.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Header2756440555.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Header2756440555MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_HeaderHa324204131.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_HeaderHa324204131MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_LogicalC725724420.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_LogicalC725724420MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_Serialization589103770MethodDeclarations.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio3485203212.h"
#include "mscorlib_System_Runtime_Serialization_Serialization589103770.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio3485203212MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC1516131009MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodC1516131009.h"
#include "mscorlib_System_Reflection_MethodInfo3330546337MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodDi492828146MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodDi492828146.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodRe981009581.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MethodRe981009581MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_MonoMeth771543475MethodDeclarations.h"
#include "mscorlib_System_Reflection_MonoMethod116053496.h"
#include "mscorlib_System_Reflection_MonoMethod116053496MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ObjRefS3912784830.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ObjRefS3912784830MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Remotin3248446683.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Remotin3248446683MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Remotin2821375126.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_Remotin2821375126MethodDeclarations.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ReturnM3411975905.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_ReturnM3411975905MethodDeclarations.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor()
extern "C"  void CompilerGeneratedAttribute__ctor_m3017743394 (CompilerGeneratedAttribute_t497097752 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.DecimalConstantAttribute::.ctor(System.Byte,System.Byte,System.UInt32,System.UInt32,System.UInt32)
extern Il2CppClass* Convert_t2607082565_il2cpp_TypeInfo_var;
extern const uint32_t DecimalConstantAttribute__ctor_m71487003_MetadataUsageId;
extern "C"  void DecimalConstantAttribute__ctor_m71487003 (DecimalConstantAttribute_t569828555 * __this, uint8_t ___scale0, uint8_t ___sign1, uint32_t ___hi2, uint32_t ___mid3, uint32_t ___low4, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DecimalConstantAttribute__ctor_m71487003_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		uint8_t L_0 = ___scale0;
		__this->set_scale_0(L_0);
		uint8_t L_1 = ___sign1;
		IL2CPP_RUNTIME_CLASS_INIT(Convert_t2607082565_il2cpp_TypeInfo_var);
		bool L_2 = Convert_ToBoolean_m2032547942(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		__this->set_sign_1(L_2);
		uint32_t L_3 = ___hi2;
		__this->set_hi_2(L_3);
		uint32_t L_4 = ___mid3;
		__this->set_mid_3(L_4);
		uint32_t L_5 = ___low4;
		__this->set_low_4(L_5);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.DefaultDependencyAttribute::.ctor(System.Runtime.CompilerServices.LoadHint)
extern "C"  void DefaultDependencyAttribute__ctor_m107693037 (DefaultDependencyAttribute_t3858269114 * __this, int32_t ___loadHintArgument0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___loadHintArgument0;
		__this->set_hint_0(L_0);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.InternalsVisibleToAttribute::.ctor(System.String)
extern "C"  void InternalsVisibleToAttribute__ctor_m573685517 (InternalsVisibleToAttribute_t1037732567 * __this, String_t* ___assemblyName0, const MethodInfo* method)
{
	{
		__this->set_all_visible_1((bool)1);
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___assemblyName0;
		__this->set_assemblyName_0(L_0);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor()
extern "C"  void RuntimeCompatibilityAttribute__ctor_m1331212510 (RuntimeCompatibilityAttribute_t2430705542 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::set_WrapNonExceptionThrows(System.Boolean)
extern "C"  void RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351 (RuntimeCompatibilityAttribute_t2430705542 * __this, bool ___value0, const MethodInfo* method)
{
	{
		bool L_0 = ___value0;
		__this->set_wrap_non_exception_throws_0(L_0);
		return;
	}
}
// System.Void System.Runtime.CompilerServices.RuntimeHelpers::InitializeArray(System.Array,System.IntPtr)
extern "C"  void RuntimeHelpers_InitializeArray_m2578109054 (Il2CppObject * __this /* static, unused */, Il2CppArray * ___array0, IntPtr_t ___fldHandle1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*RuntimeHelpers_InitializeArray_m2578109054_ftn) (Il2CppArray *, IntPtr_t);
	 ((RuntimeHelpers_InitializeArray_m2578109054_ftn)mscorlib::System::Runtime::CompilerServices::RuntimeHelpers::InitializeArray) (___array0, ___fldHandle1);
}
// System.Void System.Runtime.CompilerServices.RuntimeHelpers::InitializeArray(System.Array,System.RuntimeFieldHandle)
extern Il2CppClass* IntPtr_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern const uint32_t RuntimeHelpers_InitializeArray_m3920580167_MetadataUsageId;
extern "C"  void RuntimeHelpers_InitializeArray_m3920580167 (Il2CppObject * __this /* static, unused */, Il2CppArray * ___array0, RuntimeFieldHandle_t2331729674  ___fldHandle1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (RuntimeHelpers_InitializeArray_m3920580167_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppArray * L_0 = ___array0;
		if (!L_0)
		{
			goto IL_001c;
		}
	}
	{
		IntPtr_t L_1 = RuntimeFieldHandle_get_Value_m3963757144((&___fldHandle1), /*hidden argument*/NULL);
		IntPtr_t L_2 = ((IntPtr_t_StaticFields*)IntPtr_t_il2cpp_TypeInfo_var->static_fields)->get_Zero_1();
		bool L_3 = IntPtr_op_Equality_m1573482188(NULL /*static, unused*/, L_1, L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_0022;
		}
	}

IL_001c:
	{
		ArgumentNullException_t628810857 * L_4 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m911049464(L_4, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_0022:
	{
		Il2CppArray * L_5 = ___array0;
		IntPtr_t L_6 = RuntimeFieldHandle_get_Value_m3963757144((&___fldHandle1), /*hidden argument*/NULL);
		RuntimeHelpers_InitializeArray_m2578109054(NULL /*static, unused*/, L_5, L_6, /*hidden argument*/NULL);
		return;
	}
}
// System.Int32 System.Runtime.CompilerServices.RuntimeHelpers::get_OffsetToStringData()
extern "C"  int32_t RuntimeHelpers_get_OffsetToStringData_m2323796287 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef int32_t (*RuntimeHelpers_get_OffsetToStringData_m2323796287_ftn) ();
	return  ((RuntimeHelpers_get_OffsetToStringData_m2323796287_ftn)mscorlib::System::Runtime::CompilerServices::RuntimeHelpers::get_OffsetToStringData) ();
}
// System.Void System.Runtime.CompilerServices.StringFreezingAttribute::.ctor()
extern "C"  void StringFreezingAttribute__ctor_m2135695937 (StringFreezingAttribute_t2691375565 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.ConstrainedExecution.CriticalFinalizerObject::.ctor()
extern "C"  void CriticalFinalizerObject__ctor_m229488711 (CriticalFinalizerObject_t1920899984 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.ConstrainedExecution.CriticalFinalizerObject::Finalize()
extern "C"  void CriticalFinalizerObject_Finalize_m2361345429 (CriticalFinalizerObject_t1920899984 * __this, const MethodInfo* method)
{
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		IL2CPP_LEAVE(0xC, FINALLY_0005);
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0005;
	}

FINALLY_0005:
	{ // begin finally (depth: 1)
		Object_Finalize_m4087144328(__this, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(5)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(5)
	{
		IL2CPP_JUMP_TBL(0xC, IL_000c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_000c:
	{
		return;
	}
}
// System.Void System.Runtime.ConstrainedExecution.ReliabilityContractAttribute::.ctor(System.Runtime.ConstrainedExecution.Consistency,System.Runtime.ConstrainedExecution.Cer)
extern "C"  void ReliabilityContractAttribute__ctor_m1496374289 (ReliabilityContractAttribute_t1625655220 * __this, int32_t ___consistencyGuarantee0, int32_t ___cer1, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___consistencyGuarantee0;
		__this->set_consistency_0(L_0);
		int32_t L_1 = ___cer1;
		__this->set_cer_1(L_1);
		return;
	}
}
// System.Void System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(System.Runtime.InteropServices.ClassInterfaceType)
extern "C"  void ClassInterfaceAttribute__ctor_m177247154 (ClassInterfaceAttribute_t910653559 * __this, int32_t ___classInterfaceType0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___classInterfaceType0;
		__this->set_ciType_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.ComDefaultInterfaceAttribute::.ctor(System.Type)
extern "C"  void ComDefaultInterfaceAttribute__ctor_m254275202 (ComDefaultInterfaceAttribute_t347642415 * __this, Type_t * ___defaultInterface0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___defaultInterface0;
		__this->set__type_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.COMException::.ctor()
extern "C"  void COMException__ctor_m488488930 (COMException_t1790481504 * __this, const MethodInfo* method)
{
	{
		ExternalException__ctor_m1618796018(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.COMException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void COMException__ctor_m3964879267 (COMException_t1790481504 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		ExternalException__ctor_m4181288867(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.String System.Runtime.InteropServices.COMException::ToString()
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1113469814;
extern const uint32_t COMException_ToString_m2763629127_MetadataUsageId;
extern "C"  String_t* COMException_ToString_m2763629127 (COMException_t1790481504 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (COMException_ToString_m2763629127_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t G_B2_0 = 0;
	ObjectU5BU5D_t3614634134* G_B2_1 = NULL;
	ObjectU5BU5D_t3614634134* G_B2_2 = NULL;
	String_t* G_B2_3 = NULL;
	int32_t G_B1_0 = 0;
	ObjectU5BU5D_t3614634134* G_B1_1 = NULL;
	ObjectU5BU5D_t3614634134* G_B1_2 = NULL;
	String_t* G_B1_3 = NULL;
	String_t* G_B3_0 = NULL;
	int32_t G_B3_1 = 0;
	ObjectU5BU5D_t3614634134* G_B3_2 = NULL;
	ObjectU5BU5D_t3614634134* G_B3_3 = NULL;
	String_t* G_B3_4 = NULL;
	int32_t G_B5_0 = 0;
	ObjectU5BU5D_t3614634134* G_B5_1 = NULL;
	ObjectU5BU5D_t3614634134* G_B5_2 = NULL;
	String_t* G_B5_3 = NULL;
	int32_t G_B4_0 = 0;
	ObjectU5BU5D_t3614634134* G_B4_1 = NULL;
	ObjectU5BU5D_t3614634134* G_B4_2 = NULL;
	String_t* G_B4_3 = NULL;
	String_t* G_B6_0 = NULL;
	int32_t G_B6_1 = 0;
	ObjectU5BU5D_t3614634134* G_B6_2 = NULL;
	ObjectU5BU5D_t3614634134* G_B6_3 = NULL;
	String_t* G_B6_4 = NULL;
	{
		ObjectU5BU5D_t3614634134* L_0 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)6));
		Type_t * L_1 = Exception_GetType_m3898489832(__this, /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_0, L_1);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_1);
		ObjectU5BU5D_t3614634134* L_2 = L_0;
		int32_t L_3 = Exception_get_HResult_m19783860(__this, /*hidden argument*/NULL);
		int32_t L_4 = L_3;
		Il2CppObject * L_5 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_4);
		ArrayElementTypeCheck (L_2, L_5);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_5);
		ObjectU5BU5D_t3614634134* L_6 = L_2;
		String_t* L_7 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Exception::get_Message() */, __this);
		ArrayElementTypeCheck (L_6, L_7);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)L_7);
		ObjectU5BU5D_t3614634134* L_8 = L_6;
		Exception_t1927440687 * L_9 = Exception_get_InnerException_m3722561235(__this, /*hidden argument*/NULL);
		G_B1_0 = 3;
		G_B1_1 = L_8;
		G_B1_2 = L_8;
		G_B1_3 = _stringLiteral1113469814;
		if (L_9)
		{
			G_B2_0 = 3;
			G_B2_1 = L_8;
			G_B2_2 = L_8;
			G_B2_3 = _stringLiteral1113469814;
			goto IL_0042;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_10 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		G_B3_0 = L_10;
		G_B3_1 = G_B1_0;
		G_B3_2 = G_B1_1;
		G_B3_3 = G_B1_2;
		G_B3_4 = G_B1_3;
		goto IL_004d;
	}

IL_0042:
	{
		Exception_t1927440687 * L_11 = Exception_get_InnerException_m3722561235(__this, /*hidden argument*/NULL);
		String_t* L_12 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Exception::ToString() */, L_11);
		G_B3_0 = L_12;
		G_B3_1 = G_B2_0;
		G_B3_2 = G_B2_1;
		G_B3_3 = G_B2_2;
		G_B3_4 = G_B2_3;
	}

IL_004d:
	{
		ArrayElementTypeCheck (G_B3_2, G_B3_0);
		(G_B3_2)->SetAt(static_cast<il2cpp_array_size_t>(G_B3_1), (Il2CppObject *)G_B3_0);
		ObjectU5BU5D_t3614634134* L_13 = G_B3_3;
		String_t* L_14 = Environment_get_NewLine_m266316410(NULL /*static, unused*/, /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_13, L_14);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(4), (Il2CppObject *)L_14);
		ObjectU5BU5D_t3614634134* L_15 = L_13;
		String_t* L_16 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Exception::get_StackTrace() */, __this);
		G_B4_0 = 5;
		G_B4_1 = L_15;
		G_B4_2 = L_15;
		G_B4_3 = G_B3_4;
		if (!L_16)
		{
			G_B5_0 = 5;
			G_B5_1 = L_15;
			G_B5_2 = L_15;
			G_B5_3 = G_B3_4;
			goto IL_006e;
		}
	}
	{
		String_t* L_17 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Exception::get_StackTrace() */, __this);
		G_B6_0 = L_17;
		G_B6_1 = G_B4_0;
		G_B6_2 = G_B4_1;
		G_B6_3 = G_B4_2;
		G_B6_4 = G_B4_3;
		goto IL_0073;
	}

IL_006e:
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_18 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		G_B6_0 = L_18;
		G_B6_1 = G_B5_0;
		G_B6_2 = G_B5_1;
		G_B6_3 = G_B5_2;
		G_B6_4 = G_B5_3;
	}

IL_0073:
	{
		ArrayElementTypeCheck (G_B6_2, G_B6_0);
		(G_B6_2)->SetAt(static_cast<il2cpp_array_size_t>(G_B6_1), (Il2CppObject *)G_B6_0);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_19 = String_Format_m1263743648(NULL /*static, unused*/, G_B6_4, G_B6_3, /*hidden argument*/NULL);
		return L_19;
	}
}
// System.Void System.Runtime.InteropServices.ComImportAttribute::.ctor()
extern "C"  void ComImportAttribute__ctor_m935406192 (ComImportAttribute_t468083054 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.ComVisibleAttribute::.ctor(System.Boolean)
extern "C"  void ComVisibleAttribute__ctor_m1789587486 (ComVisibleAttribute_t2245573759 * __this, bool ___visibility0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		bool L_0 = ___visibility0;
		__this->set_Visible_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.DispIdAttribute::.ctor(System.Int32)
extern "C"  void DispIdAttribute__ctor_m997729106 (DispIdAttribute_t607560947 * __this, int32_t ___dispId0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___dispId0;
		__this->set_id_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.DllImportAttribute::.ctor(System.String)
extern "C"  void DllImportAttribute__ctor_m1165454237 (DllImportAttribute_t3000813225 * __this, String_t* ___dllName0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___dllName0;
		__this->set_Dll_2(L_0);
		return;
	}
}
// System.String System.Runtime.InteropServices.DllImportAttribute::get_Value()
extern "C"  String_t* DllImportAttribute_get_Value_m787616594 (DllImportAttribute_t3000813225 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_Dll_2();
		return L_0;
	}
}
// System.Void System.Runtime.InteropServices.ExternalException::.ctor()
extern Il2CppCodeGenString* _stringLiteral3620656248;
extern const uint32_t ExternalException__ctor_m1618796018_MetadataUsageId;
extern "C"  void ExternalException__ctor_m1618796018 (ExternalException_t1252662682 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ExternalException__ctor_m1618796018_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral3620656248, /*hidden argument*/NULL);
		SystemException__ctor_m4001391027(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2147467259), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.ExternalException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void ExternalException__ctor_m4181288867 (ExternalException_t1252662682 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		SystemException__ctor_m2688248668(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.FieldOffsetAttribute::.ctor(System.Int32)
extern "C"  void FieldOffsetAttribute__ctor_m3347191262 (FieldOffsetAttribute_t1553145711 * __this, int32_t ___offset0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___offset0;
		__this->set_val_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.GCHandle::.ctor(System.Object,System.Runtime.InteropServices.GCHandleType)
extern "C"  void GCHandle__ctor_m2952050298 (GCHandle_t3409268066 * __this, Il2CppObject * ___value0, int32_t ___type1, const MethodInfo* method)
{
	{
		int32_t L_0 = ___type1;
		if ((((int32_t)L_0) < ((int32_t)0)))
		{
			goto IL_000e;
		}
	}
	{
		int32_t L_1 = ___type1;
		if ((((int32_t)L_1) <= ((int32_t)3)))
		{
			goto IL_0011;
		}
	}

IL_000e:
	{
		___type1 = 2;
	}

IL_0011:
	{
		Il2CppObject * L_2 = ___value0;
		int32_t L_3 = ___type1;
		int32_t L_4 = GCHandle_GetTargetHandle_m3810891574(NULL /*static, unused*/, L_2, 0, L_3, /*hidden argument*/NULL);
		__this->set_handle_0(L_4);
		return;
	}
}
extern "C"  void GCHandle__ctor_m2952050298_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___value0, int32_t ___type1, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	GCHandle__ctor_m2952050298(_thisAdjusted, ___value0, ___type1, method);
}
// System.Boolean System.Runtime.InteropServices.GCHandle::get_IsAllocated()
extern "C"  bool GCHandle_get_IsAllocated_m2246567034 (GCHandle_t3409268066 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_handle_0();
		return (bool)((((int32_t)((((int32_t)L_0) == ((int32_t)0))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
extern "C"  bool GCHandle_get_IsAllocated_m2246567034_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	return GCHandle_get_IsAllocated_m2246567034(_thisAdjusted, method);
}
// System.Object System.Runtime.InteropServices.GCHandle::get_Target()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2100846476;
extern const uint32_t GCHandle_get_Target_m2327042781_MetadataUsageId;
extern "C"  Il2CppObject * GCHandle_get_Target_m2327042781 (GCHandle_t3409268066 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (GCHandle_get_Target_m2327042781_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		bool L_0 = GCHandle_get_IsAllocated_m2246567034(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_001b;
		}
	}
	{
		String_t* L_1 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral2100846476, /*hidden argument*/NULL);
		InvalidOperationException_t721527559 * L_2 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_2, L_1, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2);
	}

IL_001b:
	{
		int32_t L_3 = __this->get_handle_0();
		Il2CppObject * L_4 = GCHandle_GetTarget_m2056570211(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
extern "C"  Il2CppObject * GCHandle_get_Target_m2327042781_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	return GCHandle_get_Target_m2327042781(_thisAdjusted, method);
}
// System.Runtime.InteropServices.GCHandle System.Runtime.InteropServices.GCHandle::Alloc(System.Object,System.Runtime.InteropServices.GCHandleType)
extern "C"  GCHandle_t3409268066  GCHandle_Alloc_m1063472408 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___value0, int32_t ___type1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___value0;
		int32_t L_1 = ___type1;
		GCHandle_t3409268066  L_2;
		memset(&L_2, 0, sizeof(L_2));
		GCHandle__ctor_m2952050298(&L_2, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Runtime.InteropServices.GCHandle::Free()
extern "C"  void GCHandle_Free_m1639542352 (GCHandle_t3409268066 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_handle_0();
		GCHandle_FreeHandle_m2466807271(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		__this->set_handle_0(0);
		return;
	}
}
extern "C"  void GCHandle_Free_m1639542352_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	GCHandle_Free_m1639542352(_thisAdjusted, method);
}
// System.Object System.Runtime.InteropServices.GCHandle::GetTarget(System.Int32)
extern "C"  Il2CppObject * GCHandle_GetTarget_m2056570211 (Il2CppObject * __this /* static, unused */, int32_t ___handle0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Il2CppObject * (*GCHandle_GetTarget_m2056570211_ftn) (int32_t);
	return  ((GCHandle_GetTarget_m2056570211_ftn)mscorlib::System::Runtime::InteropServices::GCHandle::GetTarget) (___handle0);
}
// System.Int32 System.Runtime.InteropServices.GCHandle::GetTargetHandle(System.Object,System.Int32,System.Runtime.InteropServices.GCHandleType)
extern "C"  int32_t GCHandle_GetTargetHandle_m3810891574 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___obj0, int32_t ___handle1, int32_t ___type2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef int32_t (*GCHandle_GetTargetHandle_m3810891574_ftn) (Il2CppObject *, int32_t, int32_t);
	return  ((GCHandle_GetTargetHandle_m3810891574_ftn)mscorlib::System::Runtime::InteropServices::GCHandle::GetTargetHandle) (___obj0, ___handle1, ___type2);
}
// System.Void System.Runtime.InteropServices.GCHandle::FreeHandle(System.Int32)
extern "C"  void GCHandle_FreeHandle_m2466807271 (Il2CppObject * __this /* static, unused */, int32_t ___handle0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*GCHandle_FreeHandle_m2466807271_ftn) (int32_t);
	 ((GCHandle_FreeHandle_m2466807271_ftn)mscorlib::System::Runtime::InteropServices::GCHandle::FreeHandle) (___handle0);
}
// System.Boolean System.Runtime.InteropServices.GCHandle::Equals(System.Object)
extern Il2CppClass* GCHandle_t3409268066_il2cpp_TypeInfo_var;
extern const uint32_t GCHandle_Equals_m170815541_MetadataUsageId;
extern "C"  bool GCHandle_Equals_m170815541 (GCHandle_t3409268066 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (GCHandle_Equals_m170815541_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	GCHandle_t3409268066  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		Il2CppObject * L_0 = ___o0;
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		Il2CppObject * L_1 = ___o0;
		if (((Il2CppObject *)IsInstSealed(L_1, GCHandle_t3409268066_il2cpp_TypeInfo_var)))
		{
			goto IL_0013;
		}
	}

IL_0011:
	{
		return (bool)0;
	}

IL_0013:
	{
		int32_t L_2 = __this->get_handle_0();
		Il2CppObject * L_3 = ___o0;
		V_0 = ((*(GCHandle_t3409268066 *)((GCHandle_t3409268066 *)UnBox (L_3, GCHandle_t3409268066_il2cpp_TypeInfo_var))));
		int32_t L_4 = (&V_0)->get_handle_0();
		return (bool)((((int32_t)L_2) == ((int32_t)L_4))? 1 : 0);
	}
}
extern "C"  bool GCHandle_Equals_m170815541_AdjustorThunk (Il2CppObject * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	return GCHandle_Equals_m170815541(_thisAdjusted, ___o0, method);
}
// System.Int32 System.Runtime.InteropServices.GCHandle::GetHashCode()
extern "C"  int32_t GCHandle_GetHashCode_m1664905595 (GCHandle_t3409268066 * __this, const MethodInfo* method)
{
	{
		int32_t* L_0 = __this->get_address_of_handle_0();
		int32_t L_1 = Int32_GetHashCode_m1381647448(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  int32_t GCHandle_GetHashCode_m1664905595_AdjustorThunk (Il2CppObject * __this, const MethodInfo* method)
{
	GCHandle_t3409268066 * _thisAdjusted = reinterpret_cast<GCHandle_t3409268066 *>(__this + 1);
	return GCHandle_GetHashCode_m1664905595(_thisAdjusted, method);
}
// Conversion methods for marshalling of: System.Runtime.InteropServices.GCHandle
extern "C" void GCHandle_t3409268066_marshal_pinvoke(const GCHandle_t3409268066& unmarshaled, GCHandle_t3409268066_marshaled_pinvoke& marshaled)
{
	marshaled.___handle_0 = unmarshaled.get_handle_0();
}
extern "C" void GCHandle_t3409268066_marshal_pinvoke_back(const GCHandle_t3409268066_marshaled_pinvoke& marshaled, GCHandle_t3409268066& unmarshaled)
{
	int32_t unmarshaled_handle_temp_0 = 0;
	unmarshaled_handle_temp_0 = marshaled.___handle_0;
	unmarshaled.set_handle_0(unmarshaled_handle_temp_0);
}
// Conversion method for clean up from marshalling of: System.Runtime.InteropServices.GCHandle
extern "C" void GCHandle_t3409268066_marshal_pinvoke_cleanup(GCHandle_t3409268066_marshaled_pinvoke& marshaled)
{
}
// Conversion methods for marshalling of: System.Runtime.InteropServices.GCHandle
extern "C" void GCHandle_t3409268066_marshal_com(const GCHandle_t3409268066& unmarshaled, GCHandle_t3409268066_marshaled_com& marshaled)
{
	marshaled.___handle_0 = unmarshaled.get_handle_0();
}
extern "C" void GCHandle_t3409268066_marshal_com_back(const GCHandle_t3409268066_marshaled_com& marshaled, GCHandle_t3409268066& unmarshaled)
{
	int32_t unmarshaled_handle_temp_0 = 0;
	unmarshaled_handle_temp_0 = marshaled.___handle_0;
	unmarshaled.set_handle_0(unmarshaled_handle_temp_0);
}
// Conversion method for clean up from marshalling of: System.Runtime.InteropServices.GCHandle
extern "C" void GCHandle_t3409268066_marshal_com_cleanup(GCHandle_t3409268066_marshaled_com& marshaled)
{
}
// System.Void System.Runtime.InteropServices.GuidAttribute::.ctor(System.String)
extern "C"  void GuidAttribute__ctor_m1099153635 (GuidAttribute_t222072359 * __this, String_t* ___guid0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___guid0;
		__this->set_guidValue_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.InAttribute::.ctor()
extern "C"  void InAttribute__ctor_m1401060713 (InAttribute_t1394050551 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(System.Runtime.InteropServices.ComInterfaceType)
extern "C"  void InterfaceTypeAttribute__ctor_m1747686341 (InterfaceTypeAttribute_t4113096249 * __this, int32_t ___interfaceType0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___interfaceType0;
		__this->set_intType_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.Marshal::.cctor()
extern Il2CppClass* Marshal_t785896760_il2cpp_TypeInfo_var;
extern const uint32_t Marshal__cctor_m802981325_MetadataUsageId;
extern "C"  void Marshal__cctor_m802981325 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Marshal__cctor_m802981325_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t G_B3_0 = 0;
	{
		((Marshal_t785896760_StaticFields*)Marshal_t785896760_il2cpp_TypeInfo_var->static_fields)->set_SystemMaxDBCSCharSize_0(2);
		OperatingSystem_t290860502 * L_0 = Environment_get_OSVersion_m1247315981(NULL /*static, unused*/, /*hidden argument*/NULL);
		int32_t L_1 = OperatingSystem_get_Platform_m2260343279(L_0, /*hidden argument*/NULL);
		if ((!(((uint32_t)L_1) == ((uint32_t)2))))
		{
			goto IL_001c;
		}
	}
	{
		G_B3_0 = 2;
		goto IL_001d;
	}

IL_001c:
	{
		G_B3_0 = 1;
	}

IL_001d:
	{
		((Marshal_t785896760_StaticFields*)Marshal_t785896760_il2cpp_TypeInfo_var->static_fields)->set_SystemDefaultCharSize_1(G_B3_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.Marshal::copy_from_unmanaged(System.IntPtr,System.Int32,System.Array,System.Int32)
extern "C"  void Marshal_copy_from_unmanaged_m98320635 (Il2CppObject * __this /* static, unused */, IntPtr_t ___source0, int32_t ___startIndex1, Il2CppArray * ___destination2, int32_t ___length3, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*Marshal_copy_from_unmanaged_m98320635_ftn) (IntPtr_t, int32_t, Il2CppArray *, int32_t);
	 ((Marshal_copy_from_unmanaged_m98320635_ftn)mscorlib::System::Runtime::InteropServices::Marshal::copy_from_unmanaged) (___source0, ___startIndex1, ___destination2, ___length3);
}
// System.Void System.Runtime.InteropServices.Marshal::Copy(System.IntPtr,System.Byte[],System.Int32,System.Int32)
extern Il2CppClass* Marshal_t785896760_il2cpp_TypeInfo_var;
extern const uint32_t Marshal_Copy_m1683535972_MetadataUsageId;
extern "C"  void Marshal_Copy_m1683535972 (Il2CppObject * __this /* static, unused */, IntPtr_t ___source0, ByteU5BU5D_t3397334013* ___destination1, int32_t ___startIndex2, int32_t ___length3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Marshal_Copy_m1683535972_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		IntPtr_t L_0 = ___source0;
		int32_t L_1 = ___startIndex2;
		ByteU5BU5D_t3397334013* L_2 = ___destination1;
		int32_t L_3 = ___length3;
		IL2CPP_RUNTIME_CLASS_INIT(Marshal_t785896760_il2cpp_TypeInfo_var);
		Marshal_copy_from_unmanaged_m98320635(NULL /*static, unused*/, L_0, L_1, (Il2CppArray *)(Il2CppArray *)L_2, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.Marshal::Copy(System.IntPtr,System.Char[],System.Int32,System.Int32)
extern Il2CppClass* Marshal_t785896760_il2cpp_TypeInfo_var;
extern const uint32_t Marshal_Copy_m275157126_MetadataUsageId;
extern "C"  void Marshal_Copy_m275157126 (Il2CppObject * __this /* static, unused */, IntPtr_t ___source0, CharU5BU5D_t1328083999* ___destination1, int32_t ___startIndex2, int32_t ___length3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Marshal_Copy_m275157126_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		IntPtr_t L_0 = ___source0;
		int32_t L_1 = ___startIndex2;
		CharU5BU5D_t1328083999* L_2 = ___destination1;
		int32_t L_3 = ___length3;
		IL2CPP_RUNTIME_CLASS_INIT(Marshal_t785896760_il2cpp_TypeInfo_var);
		Marshal_copy_from_unmanaged_m98320635(NULL /*static, unused*/, L_0, L_1, (Il2CppArray *)(Il2CppArray *)L_2, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Byte System.Runtime.InteropServices.Marshal::ReadByte(System.IntPtr,System.Int32)
extern "C"  uint8_t Marshal_ReadByte_m536122811 (Il2CppObject * __this /* static, unused */, IntPtr_t ___ptr0, int32_t ___ofs1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef uint8_t (*Marshal_ReadByte_m536122811_ftn) (IntPtr_t, int32_t);
	return  ((Marshal_ReadByte_m536122811_ftn)mscorlib::System::Runtime::InteropServices::Marshal::ReadByte) (___ptr0, ___ofs1);
}
// System.Void System.Runtime.InteropServices.Marshal::WriteByte(System.IntPtr,System.Int32,System.Byte)
extern "C"  void Marshal_WriteByte_m2971909611 (Il2CppObject * __this /* static, unused */, IntPtr_t ___ptr0, int32_t ___ofs1, uint8_t ___val2, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*Marshal_WriteByte_m2971909611_ftn) (IntPtr_t, int32_t, uint8_t);
	 ((Marshal_WriteByte_m2971909611_ftn)mscorlib::System::Runtime::InteropServices::Marshal::WriteByte) (___ptr0, ___ofs1, ___val2);
}
// System.Void System.Runtime.InteropServices.MarshalAsAttribute::.ctor(System.Runtime.InteropServices.UnmanagedType)
extern "C"  void MarshalAsAttribute__ctor_m1892084128 (MarshalAsAttribute_t2900773360 * __this, int32_t ___unmanagedType0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___unmanagedType0;
		__this->set_utype_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.MarshalDirectiveException::.ctor()
extern Il2CppCodeGenString* _stringLiteral3441815621;
extern const uint32_t MarshalDirectiveException__ctor_m3894820706_MetadataUsageId;
extern "C"  void MarshalDirectiveException__ctor_m3894820706 (MarshalDirectiveException_t1326890414 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MarshalDirectiveException__ctor_m3894820706_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		String_t* L_0 = Locale_GetText_m1954433032(NULL /*static, unused*/, _stringLiteral3441815621, /*hidden argument*/NULL);
		SystemException__ctor_m4001391027(__this, L_0, /*hidden argument*/NULL);
		Exception_set_HResult_m2376998645(__this, ((int32_t)-2146233035), /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.MarshalDirectiveException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MarshalDirectiveException__ctor_m1606841389 (MarshalDirectiveException_t1326890414 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		SystemException__ctor_m2688248668(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.OptionalAttribute::.ctor()
extern "C"  void OptionalAttribute__ctor_m1739107582 (OptionalAttribute_t827982902 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.OutAttribute::.ctor()
extern "C"  void OutAttribute__ctor_m1447235100 (OutAttribute_t1539424546 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.PreserveSigAttribute::.ctor()
extern "C"  void PreserveSigAttribute__ctor_m3423226067 (PreserveSigAttribute_t1564965109 * __this, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::.ctor(System.IntPtr,System.Boolean)
extern "C"  void SafeHandle__ctor_m1890452380 (SafeHandle_t2733794115 * __this, IntPtr_t ___invalidHandleValue0, bool ___ownsHandle1, const MethodInfo* method)
{
	{
		CriticalFinalizerObject__ctor_m229488711(__this, /*hidden argument*/NULL);
		IntPtr_t L_0 = ___invalidHandleValue0;
		__this->set_invalid_handle_value_1(L_0);
		bool L_1 = ___ownsHandle1;
		__this->set_owns_handle_3(L_1);
		__this->set_refcount_2(1);
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::Close()
extern Il2CppClass* ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var;
extern const uint32_t SafeHandle_Close_m1146946803_MetadataUsageId;
extern "C"  void SafeHandle_Close_m1146946803 (SafeHandle_t2733794115 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SafeHandle_Close_m1146946803_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->get_refcount_2();
		if (L_0)
		{
			goto IL_001c;
		}
	}
	{
		Type_t * L_1 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_1);
		ObjectDisposedException_t2695136451 * L_3 = (ObjectDisposedException_t2695136451 *)il2cpp_codegen_object_new(ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var);
		ObjectDisposedException__ctor_m3156784572(L_3, L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_001c:
	{
		int32_t L_4 = __this->get_refcount_2();
		V_1 = L_4;
		int32_t L_5 = V_1;
		V_0 = ((int32_t)((int32_t)L_5-(int32_t)1));
		int32_t* L_6 = __this->get_address_of_refcount_2();
		int32_t L_7 = V_0;
		int32_t L_8 = V_1;
		int32_t L_9 = Interlocked_CompareExchange_m3339239614(NULL /*static, unused*/, L_6, L_7, L_8, /*hidden argument*/NULL);
		int32_t L_10 = V_1;
		if ((!(((uint32_t)L_9) == ((uint32_t)L_10))))
		{
			goto IL_001c;
		}
	}
	{
		int32_t L_11 = V_0;
		if (L_11)
		{
			goto IL_0070;
		}
	}
	{
		bool L_12 = __this->get_owns_handle_3();
		if (!L_12)
		{
			goto IL_0070;
		}
	}
	{
		bool L_13 = VirtFuncInvoker0< bool >::Invoke(7 /* System.Boolean System.Runtime.InteropServices.SafeHandle::get_IsInvalid() */, __this);
		if (L_13)
		{
			goto IL_0070;
		}
	}
	{
		VirtFuncInvoker0< bool >::Invoke(6 /* System.Boolean System.Runtime.InteropServices.SafeHandle::ReleaseHandle() */, __this);
		IntPtr_t L_14 = __this->get_invalid_handle_value_1();
		__this->set_handle_0(L_14);
		__this->set_refcount_2((-1));
	}

IL_0070:
	{
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::DangerousAddRef(System.Boolean&)
extern Il2CppClass* ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var;
extern const uint32_t SafeHandle_DangerousAddRef_m3138941540_MetadataUsageId;
extern "C"  void SafeHandle_DangerousAddRef_m3138941540 (SafeHandle_t2733794115 * __this, bool* ___success0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SafeHandle_DangerousAddRef_m3138941540_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->get_refcount_2();
		if ((((int32_t)L_0) > ((int32_t)0)))
		{
			goto IL_001d;
		}
	}
	{
		Type_t * L_1 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_1);
		ObjectDisposedException_t2695136451 * L_3 = (ObjectDisposedException_t2695136451 *)il2cpp_codegen_object_new(ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var);
		ObjectDisposedException__ctor_m3156784572(L_3, L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_001d:
	{
		int32_t L_4 = __this->get_refcount_2();
		V_1 = L_4;
		int32_t L_5 = V_1;
		V_0 = ((int32_t)((int32_t)L_5+(int32_t)1));
		int32_t L_6 = V_1;
		if ((((int32_t)L_6) > ((int32_t)0)))
		{
			goto IL_0040;
		}
	}
	{
		Type_t * L_7 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		String_t* L_8 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_7);
		ObjectDisposedException_t2695136451 * L_9 = (ObjectDisposedException_t2695136451 *)il2cpp_codegen_object_new(ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var);
		ObjectDisposedException__ctor_m3156784572(L_9, L_8, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9);
	}

IL_0040:
	{
		int32_t* L_10 = __this->get_address_of_refcount_2();
		int32_t L_11 = V_0;
		int32_t L_12 = V_1;
		int32_t L_13 = Interlocked_CompareExchange_m3339239614(NULL /*static, unused*/, L_10, L_11, L_12, /*hidden argument*/NULL);
		int32_t L_14 = V_1;
		if ((!(((uint32_t)L_13) == ((uint32_t)L_14))))
		{
			goto IL_001d;
		}
	}
	{
		bool* L_15 = ___success0;
		*((int8_t*)(L_15)) = (int8_t)1;
		return;
	}
}
// System.IntPtr System.Runtime.InteropServices.SafeHandle::DangerousGetHandle()
extern Il2CppClass* ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var;
extern const uint32_t SafeHandle_DangerousGetHandle_m1328172664_MetadataUsageId;
extern "C"  IntPtr_t SafeHandle_DangerousGetHandle_m1328172664 (SafeHandle_t2733794115 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SafeHandle_DangerousGetHandle_m1328172664_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		int32_t L_0 = __this->get_refcount_2();
		if ((((int32_t)L_0) > ((int32_t)0)))
		{
			goto IL_001d;
		}
	}
	{
		Type_t * L_1 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_1);
		ObjectDisposedException_t2695136451 * L_3 = (ObjectDisposedException_t2695136451 *)il2cpp_codegen_object_new(ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var);
		ObjectDisposedException__ctor_m3156784572(L_3, L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_001d:
	{
		IntPtr_t L_4 = __this->get_handle_0();
		return L_4;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::DangerousRelease()
extern Il2CppClass* ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var;
extern const uint32_t SafeHandle_DangerousRelease_m2167699172_MetadataUsageId;
extern "C"  void SafeHandle_DangerousRelease_m2167699172 (SafeHandle_t2733794115 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SafeHandle_DangerousRelease_m2167699172_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->get_refcount_2();
		if ((((int32_t)L_0) > ((int32_t)0)))
		{
			goto IL_001d;
		}
	}
	{
		Type_t * L_1 = Object_GetType_m191970594(__this, /*hidden argument*/NULL);
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_1);
		ObjectDisposedException_t2695136451 * L_3 = (ObjectDisposedException_t2695136451 *)il2cpp_codegen_object_new(ObjectDisposedException_t2695136451_il2cpp_TypeInfo_var);
		ObjectDisposedException__ctor_m3156784572(L_3, L_2, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_001d:
	{
		int32_t L_4 = __this->get_refcount_2();
		V_1 = L_4;
		int32_t L_5 = V_1;
		V_0 = ((int32_t)((int32_t)L_5-(int32_t)1));
		int32_t* L_6 = __this->get_address_of_refcount_2();
		int32_t L_7 = V_0;
		int32_t L_8 = V_1;
		int32_t L_9 = Interlocked_CompareExchange_m3339239614(NULL /*static, unused*/, L_6, L_7, L_8, /*hidden argument*/NULL);
		int32_t L_10 = V_1;
		if ((!(((uint32_t)L_9) == ((uint32_t)L_10))))
		{
			goto IL_001d;
		}
	}
	{
		int32_t L_11 = V_0;
		if (L_11)
		{
			goto IL_006a;
		}
	}
	{
		bool L_12 = __this->get_owns_handle_3();
		if (!L_12)
		{
			goto IL_006a;
		}
	}
	{
		bool L_13 = VirtFuncInvoker0< bool >::Invoke(7 /* System.Boolean System.Runtime.InteropServices.SafeHandle::get_IsInvalid() */, __this);
		if (L_13)
		{
			goto IL_006a;
		}
	}
	{
		VirtFuncInvoker0< bool >::Invoke(6 /* System.Boolean System.Runtime.InteropServices.SafeHandle::ReleaseHandle() */, __this);
		IntPtr_t L_14 = __this->get_invalid_handle_value_1();
		__this->set_handle_0(L_14);
	}

IL_006a:
	{
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::Dispose()
extern "C"  void SafeHandle_Dispose_m1233016688 (SafeHandle_t2733794115 * __this, const MethodInfo* method)
{
	{
		VirtActionInvoker1< bool >::Invoke(5 /* System.Void System.Runtime.InteropServices.SafeHandle::Dispose(System.Boolean) */, __this, (bool)1);
		GC_SuppressFinalize_m953228702(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::Dispose(System.Boolean)
extern "C"  void SafeHandle_Dispose_m3871883741 (SafeHandle_t2733794115 * __this, bool ___disposing0, const MethodInfo* method)
{
	{
		bool L_0 = ___disposing0;
		if (!L_0)
		{
			goto IL_0011;
		}
	}
	{
		SafeHandle_Close_m1146946803(__this, /*hidden argument*/NULL);
		goto IL_0011;
	}

IL_0011:
	{
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::SetHandle(System.IntPtr)
extern "C"  void SafeHandle_SetHandle_m1980208835 (SafeHandle_t2733794115 * __this, IntPtr_t ___handle0, const MethodInfo* method)
{
	{
		IntPtr_t L_0 = ___handle0;
		__this->set_handle_0(L_0);
		return;
	}
}
// System.Void System.Runtime.InteropServices.SafeHandle::Finalize()
extern "C"  void SafeHandle_Finalize_m1839546519 (SafeHandle_t2733794115 * __this, const MethodInfo* method)
{
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		{
			bool L_0 = __this->get_owns_handle_3();
			if (!L_0)
			{
				goto IL_0029;
			}
		}

IL_000b:
		{
			bool L_1 = VirtFuncInvoker0< bool >::Invoke(7 /* System.Boolean System.Runtime.InteropServices.SafeHandle::get_IsInvalid() */, __this);
			if (L_1)
			{
				goto IL_0029;
			}
		}

IL_0016:
		{
			VirtFuncInvoker0< bool >::Invoke(6 /* System.Boolean System.Runtime.InteropServices.SafeHandle::ReleaseHandle() */, __this);
			IntPtr_t L_2 = __this->get_invalid_handle_value_1();
			__this->set_handle_0(L_2);
		}

IL_0029:
		{
			IL2CPP_LEAVE(0x35, FINALLY_002e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_002e;
	}

FINALLY_002e:
	{ // begin finally (depth: 1)
		CriticalFinalizerObject_Finalize_m2361345429(__this, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(46)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(46)
	{
		IL2CPP_JUMP_TBL(0x35, IL_0035)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0035:
	{
		return;
	}
}
// System.Void System.Runtime.InteropServices.TypeLibImportClassAttribute::.ctor(System.Type)
extern "C"  void TypeLibImportClassAttribute__ctor_m658319193 (TypeLibImportClassAttribute_t2390314680 * __this, Type_t * ___importClass0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___importClass0;
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_0);
		__this->set__importClass_0(L_1);
		return;
	}
}
// System.Void System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(System.Int32,System.Int32)
extern "C"  void TypeLibVersionAttribute__ctor_m2430654495 (TypeLibVersionAttribute_t3346496961 * __this, int32_t ___major0, int32_t ___minor1, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___major0;
		__this->set_major_0(L_0);
		int32_t L_1 = ___minor1;
		__this->set_minor_1(L_1);
		return;
	}
}
// System.Void System.Runtime.Remoting.ActivatedClientTypeEntry::.ctor(System.String,System.String,System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral7703353;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern const uint32_t ActivatedClientTypeEntry__ctor_m2437890002_MetadataUsageId;
extern "C"  void ActivatedClientTypeEntry__ctor_m2437890002 (ActivatedClientTypeEntry_t4060499430 * __this, String_t* ___typeName0, String_t* ___assemblyName1, String_t* ___appUrl2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivatedClientTypeEntry__ctor_m2437890002_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Assembly_t4268412390 * V_0 = NULL;
	{
		TypeEntry__ctor_m1756617362(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___assemblyName1;
		TypeEntry_set_AssemblyName_m1108082984(__this, L_0, /*hidden argument*/NULL);
		String_t* L_1 = ___typeName0;
		TypeEntry_set_TypeName_m254935696(__this, L_1, /*hidden argument*/NULL);
		String_t* L_2 = ___appUrl2;
		__this->set_applicationUrl_2(L_2);
		String_t* L_3 = ___assemblyName1;
		Assembly_t4268412390 * L_4 = Assembly_Load_m902205655(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		Assembly_t4268412390 * L_5 = V_0;
		String_t* L_6 = ___typeName0;
		Type_t * L_7 = VirtFuncInvoker1< Type_t *, String_t* >::Invoke(13 /* System.Type System.Reflection.Assembly::GetType(System.String) */, L_5, L_6);
		__this->set_obj_type_3(L_7);
		Type_t * L_8 = __this->get_obj_type_3();
		if (L_8)
		{
			goto IL_0051;
		}
	}
	{
		String_t* L_9 = ___typeName0;
		String_t* L_10 = ___assemblyName1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral7703353, L_9, _stringLiteral811305474, L_10, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_12 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_12, L_11, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12);
	}

IL_0051:
	{
		return;
	}
}
// System.String System.Runtime.Remoting.ActivatedClientTypeEntry::get_ApplicationUrl()
extern "C"  String_t* ActivatedClientTypeEntry_get_ApplicationUrl_m444137483 (ActivatedClientTypeEntry_t4060499430 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_applicationUrl_2();
		return L_0;
	}
}
// System.Runtime.Remoting.Contexts.IContextAttribute[] System.Runtime.Remoting.ActivatedClientTypeEntry::get_ContextAttributes()
extern "C"  IContextAttributeU5BU5D_t435398453* ActivatedClientTypeEntry_get_ContextAttributes_m53051138 (ActivatedClientTypeEntry_t4060499430 * __this, const MethodInfo* method)
{
	{
		return (IContextAttributeU5BU5D_t435398453*)NULL;
	}
}
// System.Type System.Runtime.Remoting.ActivatedClientTypeEntry::get_ObjectType()
extern "C"  Type_t * ActivatedClientTypeEntry_get_ObjectType_m1284334298 (ActivatedClientTypeEntry_t4060499430 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_obj_type_3();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.ActivatedClientTypeEntry::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t ActivatedClientTypeEntry_ToString_m1505819693_MetadataUsageId;
extern "C"  String_t* ActivatedClientTypeEntry_ToString_m1505819693 (ActivatedClientTypeEntry_t4060499430 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivatedClientTypeEntry_ToString_m1505819693_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		String_t* L_0 = TypeEntry_get_TypeName_m3830387829(__this, /*hidden argument*/NULL);
		String_t* L_1 = TypeEntry_get_AssemblyName_m1762285107(__this, /*hidden argument*/NULL);
		String_t* L_2 = ActivatedClientTypeEntry_get_ApplicationUrl_m444137483(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m612901809(NULL /*static, unused*/, L_0, L_1, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Void System.Runtime.Remoting.ActivatedServiceTypeEntry::.ctor(System.String,System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral7703353;
extern Il2CppCodeGenString* _stringLiteral811305474;
extern const uint32_t ActivatedServiceTypeEntry__ctor_m2853895798_MetadataUsageId;
extern "C"  void ActivatedServiceTypeEntry__ctor_m2853895798 (ActivatedServiceTypeEntry_t3934090848 * __this, String_t* ___typeName0, String_t* ___assemblyName1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivatedServiceTypeEntry__ctor_m2853895798_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Assembly_t4268412390 * V_0 = NULL;
	{
		TypeEntry__ctor_m1756617362(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___assemblyName1;
		TypeEntry_set_AssemblyName_m1108082984(__this, L_0, /*hidden argument*/NULL);
		String_t* L_1 = ___typeName0;
		TypeEntry_set_TypeName_m254935696(__this, L_1, /*hidden argument*/NULL);
		String_t* L_2 = ___assemblyName1;
		Assembly_t4268412390 * L_3 = Assembly_Load_m902205655(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		Assembly_t4268412390 * L_4 = V_0;
		String_t* L_5 = ___typeName0;
		Type_t * L_6 = VirtFuncInvoker1< Type_t *, String_t* >::Invoke(13 /* System.Type System.Reflection.Assembly::GetType(System.String) */, L_4, L_5);
		__this->set_obj_type_2(L_6);
		Type_t * L_7 = __this->get_obj_type_2();
		if (L_7)
		{
			goto IL_004a;
		}
	}
	{
		String_t* L_8 = ___typeName0;
		String_t* L_9 = ___assemblyName1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_10 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral7703353, L_8, _stringLiteral811305474, L_9, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_11 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_11, L_10, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_11);
	}

IL_004a:
	{
		return;
	}
}
// System.Type System.Runtime.Remoting.ActivatedServiceTypeEntry::get_ObjectType()
extern "C"  Type_t * ActivatedServiceTypeEntry_get_ObjectType_m2302167886 (ActivatedServiceTypeEntry_t3934090848 * __this, const MethodInfo* method)
{
	{
		Type_t * L_0 = __this->get_obj_type_2();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.ActivatedServiceTypeEntry::ToString()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t ActivatedServiceTypeEntry_ToString_m2295845925_MetadataUsageId;
extern "C"  String_t* ActivatedServiceTypeEntry_ToString_m2295845925 (ActivatedServiceTypeEntry_t3934090848 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivatedServiceTypeEntry_ToString_m2295845925_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		String_t* L_0 = TypeEntry_get_AssemblyName_m1762285107(__this, /*hidden argument*/NULL);
		String_t* L_1 = TypeEntry_get_TypeName_m3830387829(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = String_Concat_m2596409543(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Runtime.Remoting.Activation.IActivator System.Runtime.Remoting.Activation.ActivationServices::get_ConstructionActivator()
extern Il2CppClass* ActivationServices_t1532663650_il2cpp_TypeInfo_var;
extern Il2CppClass* ConstructionLevelActivator_t2284932402_il2cpp_TypeInfo_var;
extern const uint32_t ActivationServices_get_ConstructionActivator_m1726426854_MetadataUsageId;
extern "C"  Il2CppObject * ActivationServices_get_ConstructionActivator_m1726426854 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivationServices_get_ConstructionActivator_m1726426854_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ((ActivationServices_t1532663650_StaticFields*)ActivationServices_t1532663650_il2cpp_TypeInfo_var->static_fields)->get__constructionActivator_0();
		if (L_0)
		{
			goto IL_0014;
		}
	}
	{
		ConstructionLevelActivator_t2284932402 * L_1 = (ConstructionLevelActivator_t2284932402 *)il2cpp_codegen_object_new(ConstructionLevelActivator_t2284932402_il2cpp_TypeInfo_var);
		ConstructionLevelActivator__ctor_m3475277508(L_1, /*hidden argument*/NULL);
		((ActivationServices_t1532663650_StaticFields*)ActivationServices_t1532663650_il2cpp_TypeInfo_var->static_fields)->set__constructionActivator_0(L_1);
	}

IL_0014:
	{
		Il2CppObject * L_2 = ((ActivationServices_t1532663650_StaticFields*)ActivationServices_t1532663650_il2cpp_TypeInfo_var->static_fields)->get__constructionActivator_0();
		return L_2;
	}
}
// System.Object System.Runtime.Remoting.Activation.ActivationServices::CreateProxyFromAttributes(System.Type,System.Object[])
extern Il2CppClass* IContextAttribute_t2439121372_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* UrlAttribute_t1544437301_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingServices_t2399536837_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1579094409;
extern const uint32_t ActivationServices_CreateProxyFromAttributes_m3900446685_MetadataUsageId;
extern "C"  Il2CppObject * ActivationServices_CreateProxyFromAttributes_m3900446685 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, ObjectU5BU5D_t3614634134* ___activationAttributes1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivationServices_CreateProxyFromAttributes_m3900446685_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	ObjectU5BU5D_t3614634134* V_2 = NULL;
	int32_t V_3 = 0;
	ActivatedClientTypeEntry_t4060499430 * V_4 = NULL;
	{
		V_0 = (String_t*)NULL;
		ObjectU5BU5D_t3614634134* L_0 = ___activationAttributes1;
		V_2 = L_0;
		V_3 = 0;
		goto IL_0040;
	}

IL_000b:
	{
		ObjectU5BU5D_t3614634134* L_1 = V_2;
		int32_t L_2 = V_3;
		int32_t L_3 = L_2;
		Il2CppObject * L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		V_1 = L_4;
		Il2CppObject * L_5 = V_1;
		if (((Il2CppObject *)IsInst(L_5, IContextAttribute_t2439121372_il2cpp_TypeInfo_var)))
		{
			goto IL_0025;
		}
	}
	{
		RemotingException_t109604560 * L_6 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_6, _stringLiteral1579094409, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6);
	}

IL_0025:
	{
		Il2CppObject * L_7 = V_1;
		if (!((UrlAttribute_t1544437301 *)IsInstSealed(L_7, UrlAttribute_t1544437301_il2cpp_TypeInfo_var)))
		{
			goto IL_003c;
		}
	}
	{
		Il2CppObject * L_8 = V_1;
		String_t* L_9 = UrlAttribute_get_UrlValue_m3448699483(((UrlAttribute_t1544437301 *)CastclassSealed(L_8, UrlAttribute_t1544437301_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		V_0 = L_9;
	}

IL_003c:
	{
		int32_t L_10 = V_3;
		V_3 = ((int32_t)((int32_t)L_10+(int32_t)1));
	}

IL_0040:
	{
		int32_t L_11 = V_3;
		ObjectU5BU5D_t3614634134* L_12 = V_2;
		if ((((int32_t)L_11) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_12)->max_length)))))))
		{
			goto IL_000b;
		}
	}
	{
		String_t* L_13 = V_0;
		if (!L_13)
		{
			goto IL_0058;
		}
	}
	{
		Type_t * L_14 = ___type0;
		String_t* L_15 = V_0;
		ObjectU5BU5D_t3614634134* L_16 = ___activationAttributes1;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		Il2CppObject * L_17 = RemotingServices_CreateClientProxy_m768660530(NULL /*static, unused*/, L_14, L_15, L_16, /*hidden argument*/NULL);
		return L_17;
	}

IL_0058:
	{
		Type_t * L_18 = ___type0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		ActivatedClientTypeEntry_t4060499430 * L_19 = RemotingConfiguration_IsRemotelyActivatedClientType_m4274128612(NULL /*static, unused*/, L_18, /*hidden argument*/NULL);
		V_4 = L_19;
		ActivatedClientTypeEntry_t4060499430 * L_20 = V_4;
		if (!L_20)
		{
			goto IL_0070;
		}
	}
	{
		ActivatedClientTypeEntry_t4060499430 * L_21 = V_4;
		ObjectU5BU5D_t3614634134* L_22 = ___activationAttributes1;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		Il2CppObject * L_23 = RemotingServices_CreateClientProxy_m1631035355(NULL /*static, unused*/, L_21, L_22, /*hidden argument*/NULL);
		return L_23;
	}

IL_0070:
	{
		Type_t * L_24 = ___type0;
		bool L_25 = Type_get_IsContextful_m1542685486(L_24, /*hidden argument*/NULL);
		if (!L_25)
		{
			goto IL_0083;
		}
	}
	{
		Type_t * L_26 = ___type0;
		ObjectU5BU5D_t3614634134* L_27 = ___activationAttributes1;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		Il2CppObject * L_28 = RemotingServices_CreateClientProxyForContextBound_m634461568(NULL /*static, unused*/, L_26, L_27, /*hidden argument*/NULL);
		return L_28;
	}

IL_0083:
	{
		return NULL;
	}
}
// System.Runtime.Remoting.Messaging.ConstructionCall System.Runtime.Remoting.Activation.ActivationServices::CreateConstructionCall(System.Type,System.String,System.Object[])
extern Il2CppClass* ConstructionCall_t1254994451_il2cpp_TypeInfo_var;
extern Il2CppClass* AppDomainLevelActivator_t834876328_il2cpp_TypeInfo_var;
extern Il2CppClass* ContextLevelActivator_t1784331636_il2cpp_TypeInfo_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextAttribute_t2439121372_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t ActivationServices_CreateConstructionCall_m1173385010_MetadataUsageId;
extern "C"  ConstructionCall_t1254994451 * ActivationServices_CreateConstructionCall_m1173385010 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, String_t* ___activationUrl1, ObjectU5BU5D_t3614634134* ___activationAttributes2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ActivationServices_CreateConstructionCall_m1173385010_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ConstructionCall_t1254994451 * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	ArrayList_t4252133567 * V_2 = NULL;
	bool V_3 = false;
	Context_t502196753 * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	ObjectU5BU5D_t3614634134* V_7 = NULL;
	Il2CppObject * V_8 = NULL;
	ObjectU5BU5D_t3614634134* V_9 = NULL;
	int32_t V_10 = 0;
	Il2CppObject * V_11 = NULL;
	Il2CppObject * V_12 = NULL;
	Il2CppObject * V_13 = NULL;
	Il2CppObject * V_14 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	int32_t G_B19_0 = 0;
	{
		Type_t * L_0 = ___type0;
		ConstructionCall_t1254994451 * L_1 = (ConstructionCall_t1254994451 *)il2cpp_codegen_object_new(ConstructionCall_t1254994451_il2cpp_TypeInfo_var);
		ConstructionCall__ctor_m1143766850(L_1, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		Type_t * L_2 = ___type0;
		bool L_3 = Type_get_IsContextful_m1542685486(L_2, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_002c;
		}
	}
	{
		ConstructionCall_t1254994451 * L_4 = V_0;
		String_t* L_5 = ___activationUrl1;
		Il2CppObject * L_6 = ActivationServices_get_ConstructionActivator_m1726426854(NULL /*static, unused*/, /*hidden argument*/NULL);
		AppDomainLevelActivator_t834876328 * L_7 = (AppDomainLevelActivator_t834876328 *)il2cpp_codegen_object_new(AppDomainLevelActivator_t834876328_il2cpp_TypeInfo_var);
		AppDomainLevelActivator__ctor_m230071814(L_7, L_5, L_6, /*hidden argument*/NULL);
		ConstructionCall_set_Activator_m305409617(L_4, L_7, /*hidden argument*/NULL);
		ConstructionCall_t1254994451 * L_8 = V_0;
		ConstructionCall_set_IsContextOk_m90795526(L_8, (bool)0, /*hidden argument*/NULL);
		ConstructionCall_t1254994451 * L_9 = V_0;
		return L_9;
	}

IL_002c:
	{
		Il2CppObject * L_10 = ActivationServices_get_ConstructionActivator_m1726426854(NULL /*static, unused*/, /*hidden argument*/NULL);
		V_1 = L_10;
		Il2CppObject * L_11 = V_1;
		ContextLevelActivator_t1784331636 * L_12 = (ContextLevelActivator_t1784331636 *)il2cpp_codegen_object_new(ContextLevelActivator_t1784331636_il2cpp_TypeInfo_var);
		ContextLevelActivator__ctor_m1688403950(L_12, L_11, /*hidden argument*/NULL);
		V_1 = L_12;
		ArrayList_t4252133567 * L_13 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_13, /*hidden argument*/NULL);
		V_2 = L_13;
		ObjectU5BU5D_t3614634134* L_14 = ___activationAttributes2;
		if (!L_14)
		{
			goto IL_004c;
		}
	}
	{
		ArrayList_t4252133567 * L_15 = V_2;
		ObjectU5BU5D_t3614634134* L_16 = ___activationAttributes2;
		VirtActionInvoker1< Il2CppObject * >::Invoke(44 /* System.Void System.Collections.ArrayList::AddRange(System.Collections.ICollection) */, L_15, (Il2CppObject *)(Il2CppObject *)L_16);
	}

IL_004c:
	{
		String_t* L_17 = ___activationUrl1;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		String_t* L_18 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_CrossContextUrl_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_19 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_17, L_18, /*hidden argument*/NULL);
		V_3 = L_19;
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_20 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		V_4 = L_20;
		bool L_21 = V_3;
		if (!L_21)
		{
			goto IL_00bd;
		}
	}
	{
		ArrayList_t4252133567 * L_22 = V_2;
		Il2CppObject * L_23 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_22);
		V_6 = L_23;
	}

IL_006d:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0096;
		}

IL_0072:
		{
			Il2CppObject * L_24 = V_6;
			Il2CppObject * L_25 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_24);
			V_5 = ((Il2CppObject *)Castclass(L_25, IContextAttribute_t2439121372_il2cpp_TypeInfo_var));
			Il2CppObject * L_26 = V_5;
			Context_t502196753 * L_27 = V_4;
			ConstructionCall_t1254994451 * L_28 = V_0;
			bool L_29 = InterfaceFuncInvoker2< bool, Context_t502196753 *, Il2CppObject * >::Invoke(1 /* System.Boolean System.Runtime.Remoting.Contexts.IContextAttribute::IsContextOK(System.Runtime.Remoting.Contexts.Context,System.Runtime.Remoting.Activation.IConstructionCallMessage) */, IContextAttribute_t2439121372_il2cpp_TypeInfo_var, L_26, L_27, L_28);
			if (L_29)
			{
				goto IL_0096;
			}
		}

IL_008f:
		{
			V_3 = (bool)0;
			goto IL_00a2;
		}

IL_0096:
		{
			Il2CppObject * L_30 = V_6;
			bool L_31 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_30);
			if (L_31)
			{
				goto IL_0072;
			}
		}

IL_00a2:
		{
			IL2CPP_LEAVE(0xBD, FINALLY_00a7);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00a7;
	}

FINALLY_00a7:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_32 = V_6;
			V_13 = ((Il2CppObject *)IsInst(L_32, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_33 = V_13;
			if (L_33)
			{
				goto IL_00b5;
			}
		}

IL_00b4:
		{
			IL2CPP_END_FINALLY(167)
		}

IL_00b5:
		{
			Il2CppObject * L_34 = V_13;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_34);
			IL2CPP_END_FINALLY(167)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(167)
	{
		IL2CPP_JUMP_TBL(0xBD, IL_00bd)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00bd:
	{
		Type_t * L_35 = ___type0;
		ObjectU5BU5D_t3614634134* L_36 = VirtFuncInvoker1< ObjectU5BU5D_t3614634134*, bool >::Invoke(12 /* System.Object[] System.Reflection.MemberInfo::GetCustomAttributes(System.Boolean) */, L_35, (bool)1);
		V_7 = L_36;
		ObjectU5BU5D_t3614634134* L_37 = V_7;
		V_9 = L_37;
		V_10 = 0;
		goto IL_010d;
	}

IL_00d2:
	{
		ObjectU5BU5D_t3614634134* L_38 = V_9;
		int32_t L_39 = V_10;
		int32_t L_40 = L_39;
		Il2CppObject * L_41 = (L_38)->GetAt(static_cast<il2cpp_array_size_t>(L_40));
		V_8 = L_41;
		Il2CppObject * L_42 = V_8;
		if (!((Il2CppObject *)IsInst(L_42, IContextAttribute_t2439121372_il2cpp_TypeInfo_var)))
		{
			goto IL_0107;
		}
	}
	{
		bool L_43 = V_3;
		if (!L_43)
		{
			goto IL_00fc;
		}
	}
	{
		Il2CppObject * L_44 = V_8;
		Context_t502196753 * L_45 = V_4;
		ConstructionCall_t1254994451 * L_46 = V_0;
		bool L_47 = InterfaceFuncInvoker2< bool, Context_t502196753 *, Il2CppObject * >::Invoke(1 /* System.Boolean System.Runtime.Remoting.Contexts.IContextAttribute::IsContextOK(System.Runtime.Remoting.Contexts.Context,System.Runtime.Remoting.Activation.IConstructionCallMessage) */, IContextAttribute_t2439121372_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_44, IContextAttribute_t2439121372_il2cpp_TypeInfo_var)), L_45, L_46);
		G_B19_0 = ((int32_t)(L_47));
		goto IL_00fd;
	}

IL_00fc:
	{
		G_B19_0 = 0;
	}

IL_00fd:
	{
		V_3 = (bool)G_B19_0;
		ArrayList_t4252133567 * L_48 = V_2;
		Il2CppObject * L_49 = V_8;
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_48, L_49);
	}

IL_0107:
	{
		int32_t L_50 = V_10;
		V_10 = ((int32_t)((int32_t)L_50+(int32_t)1));
	}

IL_010d:
	{
		int32_t L_51 = V_10;
		ObjectU5BU5D_t3614634134* L_52 = V_9;
		if ((((int32_t)L_51) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_52)->max_length)))))))
		{
			goto IL_00d2;
		}
	}
	{
		bool L_53 = V_3;
		if (L_53)
		{
			goto IL_0174;
		}
	}
	{
		ConstructionCall_t1254994451 * L_54 = V_0;
		ArrayList_t4252133567 * L_55 = V_2;
		ObjectU5BU5D_t3614634134* L_56 = VirtFuncInvoker0< ObjectU5BU5D_t3614634134* >::Invoke(47 /* System.Object[] System.Collections.ArrayList::ToArray() */, L_55);
		ConstructionCall_SetActivationAttributes_m1878298372(L_54, L_56, /*hidden argument*/NULL);
		ArrayList_t4252133567 * L_57 = V_2;
		Il2CppObject * L_58 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_57);
		V_12 = L_58;
	}

IL_0132:
	try
	{ // begin try (depth: 1)
		{
			goto IL_014d;
		}

IL_0137:
		{
			Il2CppObject * L_59 = V_12;
			Il2CppObject * L_60 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_59);
			V_11 = ((Il2CppObject *)Castclass(L_60, IContextAttribute_t2439121372_il2cpp_TypeInfo_var));
			Il2CppObject * L_61 = V_11;
			ConstructionCall_t1254994451 * L_62 = V_0;
			InterfaceActionInvoker1< Il2CppObject * >::Invoke(0 /* System.Void System.Runtime.Remoting.Contexts.IContextAttribute::GetPropertiesForNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage) */, IContextAttribute_t2439121372_il2cpp_TypeInfo_var, L_61, L_62);
		}

IL_014d:
		{
			Il2CppObject * L_63 = V_12;
			bool L_64 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_63);
			if (L_64)
			{
				goto IL_0137;
			}
		}

IL_0159:
		{
			IL2CPP_LEAVE(0x174, FINALLY_015e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_015e;
	}

FINALLY_015e:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_65 = V_12;
			V_14 = ((Il2CppObject *)IsInst(L_65, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_66 = V_14;
			if (L_66)
			{
				goto IL_016c;
			}
		}

IL_016b:
		{
			IL2CPP_END_FINALLY(350)
		}

IL_016c:
		{
			Il2CppObject * L_67 = V_14;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_67);
			IL2CPP_END_FINALLY(350)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(350)
	{
		IL2CPP_JUMP_TBL(0x174, IL_0174)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0174:
	{
		String_t* L_68 = ___activationUrl1;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		String_t* L_69 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_CrossContextUrl_3();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_70 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_68, L_69, /*hidden argument*/NULL);
		if (!L_70)
		{
			goto IL_018c;
		}
	}
	{
		String_t* L_71 = ___activationUrl1;
		Il2CppObject * L_72 = V_1;
		AppDomainLevelActivator_t834876328 * L_73 = (AppDomainLevelActivator_t834876328 *)il2cpp_codegen_object_new(AppDomainLevelActivator_t834876328_il2cpp_TypeInfo_var);
		AppDomainLevelActivator__ctor_m230071814(L_73, L_71, L_72, /*hidden argument*/NULL);
		V_1 = L_73;
	}

IL_018c:
	{
		ConstructionCall_t1254994451 * L_74 = V_0;
		Il2CppObject * L_75 = V_1;
		ConstructionCall_set_Activator_m305409617(L_74, L_75, /*hidden argument*/NULL);
		ConstructionCall_t1254994451 * L_76 = V_0;
		bool L_77 = V_3;
		ConstructionCall_set_IsContextOk_m90795526(L_76, L_77, /*hidden argument*/NULL);
		ConstructionCall_t1254994451 * L_78 = V_0;
		return L_78;
	}
}
// System.Object System.Runtime.Remoting.Activation.ActivationServices::AllocateUninitializedClassInstance(System.Type)
extern "C"  Il2CppObject * ActivationServices_AllocateUninitializedClassInstance_m3410698501 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef Il2CppObject * (*ActivationServices_AllocateUninitializedClassInstance_m3410698501_ftn) (Type_t *);
	return  ((ActivationServices_AllocateUninitializedClassInstance_m3410698501_ftn)mscorlib::System::Runtime::Remoting::Activation::ActivationServices::AllocateUninitializedClassInstance) (___type0);
}
// System.Void System.Runtime.Remoting.Activation.ActivationServices::EnableProxyActivation(System.Type,System.Boolean)
extern "C"  void ActivationServices_EnableProxyActivation_m2876788411 (Il2CppObject * __this /* static, unused */, Type_t * ___type0, bool ___enable1, const MethodInfo* method)
{
	using namespace il2cpp::icalls;
	typedef void (*ActivationServices_EnableProxyActivation_m2876788411_ftn) (Type_t *, bool);
	 ((ActivationServices_EnableProxyActivation_m2876788411_ftn)mscorlib::System::Runtime::Remoting::Activation::ActivationServices::EnableProxyActivation) (___type0, ___enable1);
}
// System.Void System.Runtime.Remoting.Activation.AppDomainLevelActivator::.ctor(System.String,System.Runtime.Remoting.Activation.IActivator)
extern "C"  void AppDomainLevelActivator__ctor_m230071814 (AppDomainLevelActivator_t834876328 * __this, String_t* ___activationUrl0, Il2CppObject * ___next1, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___activationUrl0;
		__this->set__activationUrl_0(L_0);
		Il2CppObject * L_1 = ___next1;
		__this->set__next_1(L_1);
		return;
	}
}
// System.Void System.Runtime.Remoting.Activation.ConstructionLevelActivator::.ctor()
extern "C"  void ConstructionLevelActivator__ctor_m3475277508 (ConstructionLevelActivator_t2284932402 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Activation.ContextLevelActivator::.ctor(System.Runtime.Remoting.Activation.IActivator)
extern "C"  void ContextLevelActivator__ctor_m1688403950 (ContextLevelActivator_t1784331636 * __this, Il2CppObject * ___next0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Il2CppObject * L_0 = ___next0;
		__this->set_m_NextActivator_0(L_0);
		return;
	}
}
// System.String System.Runtime.Remoting.Activation.UrlAttribute::get_UrlValue()
extern "C"  String_t* UrlAttribute_get_UrlValue_m3448699483 (UrlAttribute_t1544437301 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_url_1();
		return L_0;
	}
}
// System.Boolean System.Runtime.Remoting.Activation.UrlAttribute::Equals(System.Object)
extern Il2CppClass* UrlAttribute_t1544437301_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t UrlAttribute_Equals_m1587451932_MetadataUsageId;
extern "C"  bool UrlAttribute_Equals_m1587451932 (UrlAttribute_t1544437301 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (UrlAttribute_Equals_m1587451932_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___o0;
		if (((UrlAttribute_t1544437301 *)IsInstSealed(L_0, UrlAttribute_t1544437301_il2cpp_TypeInfo_var)))
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		Il2CppObject * L_1 = ___o0;
		String_t* L_2 = UrlAttribute_get_UrlValue_m3448699483(((UrlAttribute_t1544437301 *)CastclassSealed(L_1, UrlAttribute_t1544437301_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		String_t* L_3 = __this->get_url_1();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_4 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}
}
// System.Int32 System.Runtime.Remoting.Activation.UrlAttribute::GetHashCode()
extern "C"  int32_t UrlAttribute_GetHashCode_m4258586704 (UrlAttribute_t1544437301 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_url_1();
		int32_t L_1 = String_GetHashCode_m931956593(L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void System.Runtime.Remoting.Activation.UrlAttribute::GetPropertiesForNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern "C"  void UrlAttribute_GetPropertiesForNewContext_m1831666581 (UrlAttribute_t1544437301 * __this, Il2CppObject * ___ctorMsg0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Boolean System.Runtime.Remoting.Activation.UrlAttribute::IsContextOK(System.Runtime.Remoting.Contexts.Context,System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern "C"  bool UrlAttribute_IsContextOK_m3121915198 (UrlAttribute_t1544437301 * __this, Context_t502196753 * ___ctx0, Il2CppObject * ___msg1, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Void System.Runtime.Remoting.ChannelData::.ctor()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern const uint32_t ChannelData__ctor_m2081039517_MetadataUsageId;
extern "C"  void ChannelData__ctor_m2081039517 (ChannelData_t1489610737 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelData__ctor_m2081039517_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		__this->set__serverProviders_4(L_0);
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set__clientProviders_5(L_1);
		Hashtable_t909839986 * L_2 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_2, /*hidden argument*/NULL);
		__this->set__customProperties_6(L_2);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Collections.ArrayList System.Runtime.Remoting.ChannelData::get_ServerProviders()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t ChannelData_get_ServerProviders_m237896543_MetadataUsageId;
extern "C"  ArrayList_t4252133567 * ChannelData_get_ServerProviders_m237896543 (ChannelData_t1489610737 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelData_get_ServerProviders_m237896543_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = __this->get__serverProviders_4();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set__serverProviders_4(L_1);
	}

IL_0016:
	{
		ArrayList_t4252133567 * L_2 = __this->get__serverProviders_4();
		return L_2;
	}
}
// System.Collections.ArrayList System.Runtime.Remoting.ChannelData::get_ClientProviders()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t ChannelData_get_ClientProviders_m648877347_MetadataUsageId;
extern "C"  ArrayList_t4252133567 * ChannelData_get_ClientProviders_m648877347 (ChannelData_t1489610737 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelData_get_ClientProviders_m648877347_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = __this->get__clientProviders_5();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set__clientProviders_5(L_1);
	}

IL_0016:
	{
		ArrayList_t4252133567 * L_2 = __this->get__clientProviders_5();
		return L_2;
	}
}
// System.Collections.Hashtable System.Runtime.Remoting.ChannelData::get_CustomProperties()
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern const uint32_t ChannelData_get_CustomProperties_m1470957369_MetadataUsageId;
extern "C"  Hashtable_t909839986 * ChannelData_get_CustomProperties_m1470957369 (ChannelData_t1489610737 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelData_get_CustomProperties_m1470957369_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = __this->get__customProperties_6();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		Hashtable_t909839986 * L_1 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_1, /*hidden argument*/NULL);
		__this->set__customProperties_6(L_1);
	}

IL_0016:
	{
		Hashtable_t909839986 * L_2 = __this->get__customProperties_6();
		return L_2;
	}
}
// System.Void System.Runtime.Remoting.ChannelData::CopyFrom(System.Runtime.Remoting.ChannelData)
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DictionaryEntry_t3048875398_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern Il2CppClass* ProviderData_t2518653487_il2cpp_TypeInfo_var;
extern const uint32_t ChannelData_CopyFrom_m4049054607_MetadataUsageId;
extern "C"  void ChannelData_CopyFrom_m4049054607 (ChannelData_t1489610737 * __this, ChannelData_t1489610737 * ___other0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelData_CopyFrom_m4049054607_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Il2CppObject * V_1 = NULL;
	ProviderData_t2518653487 * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	ProviderData_t2518653487 * V_4 = NULL;
	ProviderData_t2518653487 * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	ProviderData_t2518653487 * V_7 = NULL;
	Il2CppObject * V_8 = NULL;
	Il2CppObject * V_9 = NULL;
	Il2CppObject * V_10 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		String_t* L_0 = __this->get_Ref_0();
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		ChannelData_t1489610737 * L_1 = ___other0;
		String_t* L_2 = L_1->get_Ref_0();
		__this->set_Ref_0(L_2);
	}

IL_0017:
	{
		String_t* L_3 = __this->get_Id_2();
		if (L_3)
		{
			goto IL_002e;
		}
	}
	{
		ChannelData_t1489610737 * L_4 = ___other0;
		String_t* L_5 = L_4->get_Id_2();
		__this->set_Id_2(L_5);
	}

IL_002e:
	{
		String_t* L_6 = __this->get_Type_1();
		if (L_6)
		{
			goto IL_0045;
		}
	}
	{
		ChannelData_t1489610737 * L_7 = ___other0;
		String_t* L_8 = L_7->get_Type_1();
		__this->set_Type_1(L_8);
	}

IL_0045:
	{
		String_t* L_9 = __this->get_DelayLoadAsClientChannel_3();
		if (L_9)
		{
			goto IL_005c;
		}
	}
	{
		ChannelData_t1489610737 * L_10 = ___other0;
		String_t* L_11 = L_10->get_DelayLoadAsClientChannel_3();
		__this->set_DelayLoadAsClientChannel_3(L_11);
	}

IL_005c:
	{
		ChannelData_t1489610737 * L_12 = ___other0;
		Hashtable_t909839986 * L_13 = L_12->get__customProperties_6();
		if (!L_13)
		{
			goto IL_00d9;
		}
	}
	{
		ChannelData_t1489610737 * L_14 = ___other0;
		Hashtable_t909839986 * L_15 = L_14->get__customProperties_6();
		Il2CppObject * L_16 = VirtFuncInvoker0< Il2CppObject * >::Invoke(28 /* System.Collections.IDictionaryEnumerator System.Collections.Hashtable::GetEnumerator() */, L_15);
		V_1 = L_16;
	}

IL_0073:
	try
	{ // begin try (depth: 1)
		{
			goto IL_00b4;
		}

IL_0078:
		{
			Il2CppObject * L_17 = V_1;
			Il2CppObject * L_18 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_17);
			V_0 = ((*(DictionaryEntry_t3048875398 *)((DictionaryEntry_t3048875398 *)UnBox (L_18, DictionaryEntry_t3048875398_il2cpp_TypeInfo_var))));
			Hashtable_t909839986 * L_19 = ChannelData_get_CustomProperties_m1470957369(__this, /*hidden argument*/NULL);
			Il2CppObject * L_20 = DictionaryEntry_get_Key_m3623293571((&V_0), /*hidden argument*/NULL);
			bool L_21 = VirtFuncInvoker1< bool, Il2CppObject * >::Invoke(30 /* System.Boolean System.Collections.Hashtable::ContainsKey(System.Object) */, L_19, L_20);
			if (L_21)
			{
				goto IL_00b4;
			}
		}

IL_009b:
		{
			Hashtable_t909839986 * L_22 = ChannelData_get_CustomProperties_m1470957369(__this, /*hidden argument*/NULL);
			Il2CppObject * L_23 = DictionaryEntry_get_Key_m3623293571((&V_0), /*hidden argument*/NULL);
			Il2CppObject * L_24 = DictionaryEntry_get_Value_m2812883243((&V_0), /*hidden argument*/NULL);
			VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(23 /* System.Void System.Collections.Hashtable::set_Item(System.Object,System.Object) */, L_22, L_23, L_24);
		}

IL_00b4:
		{
			Il2CppObject * L_25 = V_1;
			bool L_26 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_25);
			if (L_26)
			{
				goto IL_0078;
			}
		}

IL_00bf:
		{
			IL2CPP_LEAVE(0xD9, FINALLY_00c4);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00c4;
	}

FINALLY_00c4:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_27 = V_1;
			V_8 = ((Il2CppObject *)IsInst(L_27, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_28 = V_8;
			if (L_28)
			{
				goto IL_00d1;
			}
		}

IL_00d0:
		{
			IL2CPP_END_FINALLY(196)
		}

IL_00d1:
		{
			Il2CppObject * L_29 = V_8;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_29);
			IL2CPP_END_FINALLY(196)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(196)
	{
		IL2CPP_JUMP_TBL(0xD9, IL_00d9)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00d9:
	{
		ArrayList_t4252133567 * L_30 = __this->get__serverProviders_4();
		if (L_30)
		{
			goto IL_014e;
		}
	}
	{
		ChannelData_t1489610737 * L_31 = ___other0;
		ArrayList_t4252133567 * L_32 = L_31->get__serverProviders_4();
		if (!L_32)
		{
			goto IL_014e;
		}
	}
	{
		ChannelData_t1489610737 * L_33 = ___other0;
		ArrayList_t4252133567 * L_34 = L_33->get__serverProviders_4();
		Il2CppObject * L_35 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_34);
		V_3 = L_35;
	}

IL_00fb:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0129;
		}

IL_0100:
		{
			Il2CppObject * L_36 = V_3;
			Il2CppObject * L_37 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_36);
			V_2 = ((ProviderData_t2518653487 *)CastclassClass(L_37, ProviderData_t2518653487_il2cpp_TypeInfo_var));
			ProviderData_t2518653487 * L_38 = (ProviderData_t2518653487 *)il2cpp_codegen_object_new(ProviderData_t2518653487_il2cpp_TypeInfo_var);
			ProviderData__ctor_m1260387831(L_38, /*hidden argument*/NULL);
			V_4 = L_38;
			ProviderData_t2518653487 * L_39 = V_4;
			ProviderData_t2518653487 * L_40 = V_2;
			ProviderData_CopyFrom_m431414335(L_39, L_40, /*hidden argument*/NULL);
			ArrayList_t4252133567 * L_41 = ChannelData_get_ServerProviders_m237896543(__this, /*hidden argument*/NULL);
			ProviderData_t2518653487 * L_42 = V_4;
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_41, L_42);
		}

IL_0129:
		{
			Il2CppObject * L_43 = V_3;
			bool L_44 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_43);
			if (L_44)
			{
				goto IL_0100;
			}
		}

IL_0134:
		{
			IL2CPP_LEAVE(0x14E, FINALLY_0139);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0139;
	}

FINALLY_0139:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_45 = V_3;
			V_9 = ((Il2CppObject *)IsInst(L_45, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_46 = V_9;
			if (L_46)
			{
				goto IL_0146;
			}
		}

IL_0145:
		{
			IL2CPP_END_FINALLY(313)
		}

IL_0146:
		{
			Il2CppObject * L_47 = V_9;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_47);
			IL2CPP_END_FINALLY(313)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(313)
	{
		IL2CPP_JUMP_TBL(0x14E, IL_014e)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_014e:
	{
		ArrayList_t4252133567 * L_48 = __this->get__clientProviders_5();
		if (L_48)
		{
			goto IL_01c9;
		}
	}
	{
		ChannelData_t1489610737 * L_49 = ___other0;
		ArrayList_t4252133567 * L_50 = L_49->get__clientProviders_5();
		if (!L_50)
		{
			goto IL_01c9;
		}
	}
	{
		ChannelData_t1489610737 * L_51 = ___other0;
		ArrayList_t4252133567 * L_52 = L_51->get__clientProviders_5();
		Il2CppObject * L_53 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_52);
		V_6 = L_53;
	}

IL_0171:
	try
	{ // begin try (depth: 1)
		{
			goto IL_01a2;
		}

IL_0176:
		{
			Il2CppObject * L_54 = V_6;
			Il2CppObject * L_55 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_54);
			V_5 = ((ProviderData_t2518653487 *)CastclassClass(L_55, ProviderData_t2518653487_il2cpp_TypeInfo_var));
			ProviderData_t2518653487 * L_56 = (ProviderData_t2518653487 *)il2cpp_codegen_object_new(ProviderData_t2518653487_il2cpp_TypeInfo_var);
			ProviderData__ctor_m1260387831(L_56, /*hidden argument*/NULL);
			V_7 = L_56;
			ProviderData_t2518653487 * L_57 = V_7;
			ProviderData_t2518653487 * L_58 = V_5;
			ProviderData_CopyFrom_m431414335(L_57, L_58, /*hidden argument*/NULL);
			ArrayList_t4252133567 * L_59 = ChannelData_get_ClientProviders_m648877347(__this, /*hidden argument*/NULL);
			ProviderData_t2518653487 * L_60 = V_7;
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_59, L_60);
		}

IL_01a2:
		{
			Il2CppObject * L_61 = V_6;
			bool L_62 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_61);
			if (L_62)
			{
				goto IL_0176;
			}
		}

IL_01ae:
		{
			IL2CPP_LEAVE(0x1C9, FINALLY_01b3);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_01b3;
	}

FINALLY_01b3:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_63 = V_6;
			V_10 = ((Il2CppObject *)IsInst(L_63, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_64 = V_10;
			if (L_64)
			{
				goto IL_01c1;
			}
		}

IL_01c0:
		{
			IL2CPP_END_FINALLY(435)
		}

IL_01c1:
		{
			Il2CppObject * L_65 = V_10;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_65);
			IL2CPP_END_FINALLY(435)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(435)
	{
		IL2CPP_JUMP_TBL(0x1C9, IL_01c9)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_01c9:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ChannelInfo::.ctor()
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern const uint32_t ChannelInfo__ctor_m2502026239_MetadataUsageId;
extern "C"  void ChannelInfo__ctor_m2502026239 (ChannelInfo_t709892715 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelInfo__ctor_m2502026239_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ObjectU5BU5D_t3614634134* L_0 = ChannelServices_GetCurrentChannelInfo_m4080942430(NULL /*static, unused*/, /*hidden argument*/NULL);
		__this->set_channelData_0(L_0);
		return;
	}
}
// System.Object[] System.Runtime.Remoting.ChannelInfo::get_ChannelData()
extern "C"  ObjectU5BU5D_t3614634134* ChannelInfo_get_ChannelData_m2401378984 (ChannelInfo_t709892715 * __this, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get_channelData_0();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Channels.ChannelServices::.cctor()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* CrossContextChannel_t2302426108_il2cpp_TypeInfo_var;
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1455329609;
extern Il2CppCodeGenString* _stringLiteral3336560767;
extern Il2CppCodeGenString* _stringLiteral60050698;
extern const uint32_t ChannelServices__cctor_m3534779830_MetadataUsageId;
extern "C"  void ChannelServices__cctor_m3534779830 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices__cctor_m3534779830_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->set_registeredChannels_0(L_0);
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->set_delayedClientChannels_1(L_1);
		CrossContextChannel_t2302426108 * L_2 = (CrossContextChannel_t2302426108 *)il2cpp_codegen_object_new(CrossContextChannel_t2302426108_il2cpp_TypeInfo_var);
		CrossContextChannel__ctor_m2991342036(L_2, /*hidden argument*/NULL);
		((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->set__crossContextSink_2(L_2);
		((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->set_CrossContextUrl_3(_stringLiteral1455329609);
		StringU5BU5D_t1642385972* L_3 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_3, _stringLiteral3336560767);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3336560767);
		StringU5BU5D_t1642385972* L_4 = L_3;
		ArrayElementTypeCheck (L_4, _stringLiteral60050698);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral60050698);
		((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->set_oldStartModeTypes_4((Il2CppObject *)L_4);
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.ChannelServices::CreateClientChannelSinkChain(System.String,System.Object,System.String&)
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannel_t321318132_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannelSender_t714647579_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern const uint32_t ChannelServices_CreateClientChannelSinkChain_m629385345_MetadataUsageId;
extern "C"  Il2CppObject * ChannelServices_CreateClientChannelSinkChain_m629385345 (Il2CppObject * __this /* static, unused */, String_t* ___url0, Il2CppObject * ___remoteChannelData1, String_t** ___objectUri2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_CreateClientChannelSinkChain_m629385345_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ObjectU5BU5D_t3614634134* V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	Il2CppObject * V_7 = NULL;
	Il2CppObject * V_8 = NULL;
	Il2CppObject * V_9 = NULL;
	Il2CppObject * V_10 = NULL;
	Il2CppObject * V_11 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Il2CppObject * L_0 = ___remoteChannelData1;
		V_0 = ((ObjectU5BU5D_t3614634134*)Castclass(L_0, ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var));
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ArrayList_t4252133567 * L_1 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
		Il2CppObject * L_2 = VirtFuncInvoker0< Il2CppObject * >::Invoke(29 /* System.Object System.Collections.ArrayList::get_SyncRoot() */, L_1);
		V_1 = L_2;
		Il2CppObject * L_3 = V_1;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
	}

IL_0018:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_4 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			Il2CppObject * L_5 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_4);
			V_3 = L_5;
		}

IL_0023:
		try
		{ // begin try (depth: 2)
			{
				goto IL_0064;
			}

IL_0028:
			{
				Il2CppObject * L_6 = V_3;
				Il2CppObject * L_7 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_6);
				V_2 = ((Il2CppObject *)Castclass(L_7, IChannel_t321318132_il2cpp_TypeInfo_var));
				Il2CppObject * L_8 = V_2;
				V_4 = ((Il2CppObject *)IsInst(L_8, IChannelSender_t714647579_il2cpp_TypeInfo_var));
				Il2CppObject * L_9 = V_4;
				if (L_9)
				{
					goto IL_0048;
				}
			}

IL_0043:
			{
				goto IL_0064;
			}

IL_0048:
			{
				Il2CppObject * L_10 = V_4;
				String_t* L_11 = ___url0;
				ObjectU5BU5D_t3614634134* L_12 = V_0;
				String_t** L_13 = ___objectUri2;
				IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
				Il2CppObject * L_14 = ChannelServices_CreateClientChannelSinkChain_m4271702352(NULL /*static, unused*/, L_10, L_11, L_12, L_13, /*hidden argument*/NULL);
				V_5 = L_14;
				Il2CppObject * L_15 = V_5;
				if (!L_15)
				{
					goto IL_0064;
				}
			}

IL_005b:
			{
				Il2CppObject * L_16 = V_5;
				V_9 = L_16;
				IL2CPP_LEAVE(0x114, FINALLY_0074);
			}

IL_0064:
			{
				Il2CppObject * L_17 = V_3;
				bool L_18 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_17);
				if (L_18)
				{
					goto IL_0028;
				}
			}

IL_006f:
			{
				IL2CPP_LEAVE(0x89, FINALLY_0074);
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
			goto FINALLY_0074;
		}

FINALLY_0074:
		{ // begin finally (depth: 2)
			{
				Il2CppObject * L_19 = V_3;
				V_10 = ((Il2CppObject *)IsInst(L_19, IDisposable_t2427283555_il2cpp_TypeInfo_var));
				Il2CppObject * L_20 = V_10;
				if (L_20)
				{
					goto IL_0081;
				}
			}

IL_0080:
			{
				IL2CPP_END_FINALLY(116)
			}

IL_0081:
			{
				Il2CppObject * L_21 = V_10;
				InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_21);
				IL2CPP_END_FINALLY(116)
			}
		} // end finally (depth: 2)
		IL2CPP_CLEANUP(116)
		{
			IL2CPP_END_CLEANUP(0x114, FINALLY_0108);
			IL2CPP_JUMP_TBL(0x89, IL_0089)
			IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
		}

IL_0089:
		{
			IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
			RemotingConfiguration_LoadDefaultDelayedChannels_m3702110176(NULL /*static, unused*/, /*hidden argument*/NULL);
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_22 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_delayedClientChannels_1();
			Il2CppObject * L_23 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_22);
			V_7 = L_23;
		}

IL_009a:
		try
		{ // begin try (depth: 2)
			{
				goto IL_00dc;
			}

IL_009f:
			{
				Il2CppObject * L_24 = V_7;
				Il2CppObject * L_25 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_24);
				V_6 = ((Il2CppObject *)Castclass(L_25, IChannelSender_t714647579_il2cpp_TypeInfo_var));
				Il2CppObject * L_26 = V_6;
				String_t* L_27 = ___url0;
				ObjectU5BU5D_t3614634134* L_28 = V_0;
				String_t** L_29 = ___objectUri2;
				IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
				Il2CppObject * L_30 = ChannelServices_CreateClientChannelSinkChain_m4271702352(NULL /*static, unused*/, L_26, L_27, L_28, L_29, /*hidden argument*/NULL);
				V_8 = L_30;
				Il2CppObject * L_31 = V_8;
				if (!L_31)
				{
					goto IL_00dc;
				}
			}

IL_00c0:
			{
				IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
				ArrayList_t4252133567 * L_32 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_delayedClientChannels_1();
				Il2CppObject * L_33 = V_6;
				VirtActionInvoker1< Il2CppObject * >::Invoke(38 /* System.Void System.Collections.ArrayList::Remove(System.Object) */, L_32, L_33);
				Il2CppObject * L_34 = V_6;
				ChannelServices_RegisterChannel_m3832858065(NULL /*static, unused*/, L_34, /*hidden argument*/NULL);
				Il2CppObject * L_35 = V_8;
				V_9 = L_35;
				IL2CPP_LEAVE(0x114, FINALLY_00ed);
			}

IL_00dc:
			{
				Il2CppObject * L_36 = V_7;
				bool L_37 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_36);
				if (L_37)
				{
					goto IL_009f;
				}
			}

IL_00e8:
			{
				IL2CPP_LEAVE(0x103, FINALLY_00ed);
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
			goto FINALLY_00ed;
		}

FINALLY_00ed:
		{ // begin finally (depth: 2)
			{
				Il2CppObject * L_38 = V_7;
				V_11 = ((Il2CppObject *)IsInst(L_38, IDisposable_t2427283555_il2cpp_TypeInfo_var));
				Il2CppObject * L_39 = V_11;
				if (L_39)
				{
					goto IL_00fb;
				}
			}

IL_00fa:
			{
				IL2CPP_END_FINALLY(237)
			}

IL_00fb:
			{
				Il2CppObject * L_40 = V_11;
				InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_40);
				IL2CPP_END_FINALLY(237)
			}
		} // end finally (depth: 2)
		IL2CPP_CLEANUP(237)
		{
			IL2CPP_END_CLEANUP(0x114, FINALLY_0108);
			IL2CPP_JUMP_TBL(0x103, IL_0103)
			IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
		}

IL_0103:
		{
			IL2CPP_LEAVE(0x10F, FINALLY_0108);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0108;
	}

FINALLY_0108:
	{ // begin finally (depth: 1)
		Il2CppObject * L_41 = V_1;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_41, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(264)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(264)
	{
		IL2CPP_JUMP_TBL(0x114, IL_0114)
		IL2CPP_JUMP_TBL(0x10F, IL_010f)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_010f:
	{
		String_t** L_42 = ___objectUri2;
		*((Il2CppObject **)(L_42)) = (Il2CppObject *)NULL;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_42), (Il2CppObject *)NULL);
		return (Il2CppObject *)NULL;
	}

IL_0114:
	{
		Il2CppObject * L_43 = V_9;
		return L_43;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.ChannelServices::CreateClientChannelSinkChain(System.Runtime.Remoting.Channels.IChannelSender,System.String,System.Object[],System.String&)
extern Il2CppClass* IChannelSender_t714647579_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannelDataStore_t1307999835_il2cpp_TypeInfo_var;
extern const uint32_t ChannelServices_CreateClientChannelSinkChain_m4271702352_MetadataUsageId;
extern "C"  Il2CppObject * ChannelServices_CreateClientChannelSinkChain_m4271702352 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___sender0, String_t* ___url1, ObjectU5BU5D_t3614634134* ___channelDataArray2, String_t** ___objectUri3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_CreateClientChannelSinkChain_m4271702352_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	ObjectU5BU5D_t3614634134* V_1 = NULL;
	int32_t V_2 = 0;
	Il2CppObject * V_3 = NULL;
	{
		String_t** L_0 = ___objectUri3;
		*((Il2CppObject **)(L_0)) = (Il2CppObject *)NULL;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_0), (Il2CppObject *)NULL);
		ObjectU5BU5D_t3614634134* L_1 = ___channelDataArray2;
		if (L_1)
		{
			goto IL_0013;
		}
	}
	{
		Il2CppObject * L_2 = ___sender0;
		String_t* L_3 = ___url1;
		String_t** L_4 = ___objectUri3;
		Il2CppObject * L_5 = InterfaceFuncInvoker3< Il2CppObject *, String_t*, Il2CppObject *, String_t** >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.IChannelSender::CreateMessageSink(System.String,System.Object,System.String&) */, IChannelSender_t714647579_il2cpp_TypeInfo_var, L_2, L_3, NULL, L_4);
		return L_5;
	}

IL_0013:
	{
		ObjectU5BU5D_t3614634134* L_6 = ___channelDataArray2;
		V_1 = L_6;
		V_2 = 0;
		goto IL_0050;
	}

IL_001c:
	{
		ObjectU5BU5D_t3614634134* L_7 = V_1;
		int32_t L_8 = V_2;
		int32_t L_9 = L_8;
		Il2CppObject * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_0 = L_10;
		Il2CppObject * L_11 = V_0;
		if (!((Il2CppObject *)IsInst(L_11, IChannelDataStore_t1307999835_il2cpp_TypeInfo_var)))
		{
			goto IL_003a;
		}
	}
	{
		Il2CppObject * L_12 = ___sender0;
		Il2CppObject * L_13 = V_0;
		String_t** L_14 = ___objectUri3;
		Il2CppObject * L_15 = InterfaceFuncInvoker3< Il2CppObject *, String_t*, Il2CppObject *, String_t** >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.IChannelSender::CreateMessageSink(System.String,System.Object,System.String&) */, IChannelSender_t714647579_il2cpp_TypeInfo_var, L_12, (String_t*)NULL, L_13, L_14);
		V_3 = L_15;
		goto IL_0044;
	}

IL_003a:
	{
		Il2CppObject * L_16 = ___sender0;
		String_t* L_17 = ___url1;
		Il2CppObject * L_18 = V_0;
		String_t** L_19 = ___objectUri3;
		Il2CppObject * L_20 = InterfaceFuncInvoker3< Il2CppObject *, String_t*, Il2CppObject *, String_t** >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.IChannelSender::CreateMessageSink(System.String,System.Object,System.String&) */, IChannelSender_t714647579_il2cpp_TypeInfo_var, L_16, L_17, L_18, L_19);
		V_3 = L_20;
	}

IL_0044:
	{
		Il2CppObject * L_21 = V_3;
		if (!L_21)
		{
			goto IL_004c;
		}
	}
	{
		Il2CppObject * L_22 = V_3;
		return L_22;
	}

IL_004c:
	{
		int32_t L_23 = V_2;
		V_2 = ((int32_t)((int32_t)L_23+(int32_t)1));
	}

IL_0050:
	{
		int32_t L_24 = V_2;
		ObjectU5BU5D_t3614634134* L_25 = V_1;
		if ((((int32_t)L_24) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_25)->max_length)))))))
		{
			goto IL_001c;
		}
	}
	{
		return (Il2CppObject *)NULL;
	}
}
// System.Void System.Runtime.Remoting.Channels.ChannelServices::RegisterChannel(System.Runtime.Remoting.Channels.IChannel)
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern const uint32_t ChannelServices_RegisterChannel_m3832858065_MetadataUsageId;
extern "C"  void ChannelServices_RegisterChannel_m3832858065 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___chnl0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_RegisterChannel_m3832858065_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___chnl0;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ChannelServices_RegisterChannel_m557784146(NULL /*static, unused*/, L_0, (bool)0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Channels.ChannelServices::RegisterChannel(System.Runtime.Remoting.Channels.IChannel,System.Boolean)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* ISecurableChannel_t3007777596_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannel_t321318132_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannelReceiver_t2788889625_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_t3321498491_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral943703373;
extern Il2CppCodeGenString* _stringLiteral3586371101;
extern Il2CppCodeGenString* _stringLiteral255528003;
extern Il2CppCodeGenString* _stringLiteral2140043342;
extern const uint32_t ChannelServices_RegisterChannel_m557784146_MetadataUsageId;
extern "C"  void ChannelServices_RegisterChannel_m557784146 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___chnl0, bool ___ensureSecurity1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_RegisterChannel_m557784146_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	Il2CppObject * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Il2CppObject * L_0 = ___chnl0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral943703373, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		bool L_2 = ___ensureSecurity1;
		if (!L_2)
		{
			goto IL_0041;
		}
	}
	{
		Il2CppObject * L_3 = ___chnl0;
		V_1 = ((Il2CppObject *)IsInst(L_3, ISecurableChannel_t3007777596_il2cpp_TypeInfo_var));
		Il2CppObject * L_4 = V_1;
		if (L_4)
		{
			goto IL_003a;
		}
	}
	{
		Il2CppObject * L_5 = ___chnl0;
		String_t* L_6 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Channels.IChannel::get_ChannelName() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_5);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_7 = String_Format_m2024975688(NULL /*static, unused*/, _stringLiteral3586371101, L_6, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_8 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_8, L_7, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_8);
	}

IL_003a:
	{
		Il2CppObject * L_9 = V_1;
		InterfaceActionInvoker1< bool >::Invoke(0 /* System.Void System.Runtime.Remoting.Channels.ISecurableChannel::set_IsSecured(System.Boolean) */, ISecurableChannel_t3007777596_il2cpp_TypeInfo_var, L_9, (bool)1);
	}

IL_0041:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ArrayList_t4252133567 * L_10 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
		Il2CppObject * L_11 = VirtFuncInvoker0< Il2CppObject * >::Invoke(29 /* System.Object System.Collections.ArrayList::get_SyncRoot() */, L_10);
		V_0 = L_11;
		Il2CppObject * L_12 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_12, /*hidden argument*/NULL);
	}

IL_0052:
	try
	{ // begin try (depth: 1)
		{
			V_2 = (-1);
			V_3 = 0;
			goto IL_00d4;
		}

IL_005b:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_13 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			int32_t L_14 = V_3;
			Il2CppObject * L_15 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_13, L_14);
			V_4 = ((Il2CppObject *)Castclass(L_15, IChannel_t321318132_il2cpp_TypeInfo_var));
			Il2CppObject * L_16 = V_4;
			String_t* L_17 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Channels.IChannel::get_ChannelName() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_16);
			Il2CppObject * L_18 = ___chnl0;
			String_t* L_19 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Channels.IChannel::get_ChannelName() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_18);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			bool L_20 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_17, L_19, /*hidden argument*/NULL);
			if (!L_20)
			{
				goto IL_00b5;
			}
		}

IL_0084:
		{
			Il2CppObject * L_21 = ___chnl0;
			String_t* L_22 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Channels.IChannel::get_ChannelName() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_21);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_23 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
			bool L_24 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_22, L_23, /*hidden argument*/NULL);
			if (!L_24)
			{
				goto IL_00b5;
			}
		}

IL_0099:
		{
			Il2CppObject * L_25 = V_4;
			String_t* L_26 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Channels.IChannel::get_ChannelName() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_25);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_27 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral255528003, L_26, _stringLiteral2140043342, /*hidden argument*/NULL);
			RemotingException_t109604560 * L_28 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3568495070(L_28, L_27, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_28);
		}

IL_00b5:
		{
			Il2CppObject * L_29 = V_4;
			int32_t L_30 = InterfaceFuncInvoker0< int32_t >::Invoke(1 /* System.Int32 System.Runtime.Remoting.Channels.IChannel::get_ChannelPriority() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_29);
			Il2CppObject * L_31 = ___chnl0;
			int32_t L_32 = InterfaceFuncInvoker0< int32_t >::Invoke(1 /* System.Int32 System.Runtime.Remoting.Channels.IChannel::get_ChannelPriority() */, IChannel_t321318132_il2cpp_TypeInfo_var, L_31);
			if ((((int32_t)L_30) >= ((int32_t)L_32)))
			{
				goto IL_00d0;
			}
		}

IL_00c7:
		{
			int32_t L_33 = V_2;
			if ((!(((uint32_t)L_33) == ((uint32_t)(-1)))))
			{
				goto IL_00d0;
			}
		}

IL_00ce:
		{
			int32_t L_34 = V_3;
			V_2 = L_34;
		}

IL_00d0:
		{
			int32_t L_35 = V_3;
			V_3 = ((int32_t)((int32_t)L_35+(int32_t)1));
		}

IL_00d4:
		{
			int32_t L_36 = V_3;
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_37 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			int32_t L_38 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_37);
			if ((((int32_t)L_36) < ((int32_t)L_38)))
			{
				goto IL_005b;
			}
		}

IL_00e4:
		{
			int32_t L_39 = V_2;
			if ((((int32_t)L_39) == ((int32_t)(-1))))
			{
				goto IL_00fc;
			}
		}

IL_00eb:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_40 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			int32_t L_41 = V_2;
			Il2CppObject * L_42 = ___chnl0;
			VirtActionInvoker2< int32_t, Il2CppObject * >::Invoke(36 /* System.Void System.Collections.ArrayList::Insert(System.Int32,System.Object) */, L_40, L_41, L_42);
			goto IL_0108;
		}

IL_00fc:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_43 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			Il2CppObject * L_44 = ___chnl0;
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_43, L_44);
		}

IL_0108:
		{
			Il2CppObject * L_45 = ___chnl0;
			V_5 = ((Il2CppObject *)IsInst(L_45, IChannelReceiver_t2788889625_il2cpp_TypeInfo_var));
			Il2CppObject * L_46 = V_5;
			if (!L_46)
			{
				goto IL_0139;
			}
		}

IL_0117:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			Il2CppObject * L_47 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_oldStartModeTypes_4();
			Il2CppObject * L_48 = ___chnl0;
			Type_t * L_49 = Object_GetType_m191970594(L_48, /*hidden argument*/NULL);
			String_t* L_50 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Type::ToString() */, L_49);
			bool L_51 = InterfaceFuncInvoker1< bool, Il2CppObject * >::Invoke(6 /* System.Boolean System.Collections.IList::Contains(System.Object) */, IList_t3321498491_il2cpp_TypeInfo_var, L_47, L_50);
			if (!L_51)
			{
				goto IL_0139;
			}
		}

IL_0131:
		{
			Il2CppObject * L_52 = V_5;
			InterfaceActionInvoker1< Il2CppObject * >::Invoke(1 /* System.Void System.Runtime.Remoting.Channels.IChannelReceiver::StartListening(System.Object) */, IChannelReceiver_t2788889625_il2cpp_TypeInfo_var, L_52, NULL);
		}

IL_0139:
		{
			IL2CPP_LEAVE(0x145, FINALLY_013e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_013e;
	}

FINALLY_013e:
	{ // begin finally (depth: 1)
		Il2CppObject * L_53 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_53, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(318)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(318)
	{
		IL2CPP_JUMP_TBL(0x145, IL_0145)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0145:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Channels.ChannelServices::RegisterChannelConfig(System.Runtime.Remoting.ChannelData)
extern const Il2CppType* IChannelSender_t714647579_0_0_0_var;
extern const Il2CppType* IChannelReceiver_t2788889625_0_0_0_var;
extern const Il2CppType* IDictionary_t596158605_0_0_0_var;
extern const Il2CppType* IClientChannelSinkProvider_t2522474175_0_0_0_var;
extern const Il2CppType* IServerChannelSinkProvider_t2060956099_0_0_0_var;
extern Il2CppClass* ProviderData_t2518653487_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* IServerChannelSinkProvider_t2060956099_il2cpp_TypeInfo_var;
extern Il2CppClass* IClientChannelSinkProvider_t2522474175_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannel_t321318132_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetInvocationException_t4098620458_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannelReceiver_t2788889625_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1763939415;
extern Il2CppCodeGenString* _stringLiteral3813883430;
extern Il2CppCodeGenString* _stringLiteral4091618523;
extern Il2CppCodeGenString* _stringLiteral2038899257;
extern Il2CppCodeGenString* _stringLiteral3323263070;
extern const uint32_t ChannelServices_RegisterChannelConfig_m4091185772_MetadataUsageId;
extern "C"  void ChannelServices_RegisterChannelConfig_m4091185772 (Il2CppObject * __this /* static, unused */, ChannelData_t1489610737 * ___channel0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_RegisterChannelConfig_m4091185772_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	int32_t V_2 = 0;
	ProviderData_t2518653487 * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	int32_t V_5 = 0;
	ProviderData_t2518653487 * V_6 = NULL;
	Il2CppObject * V_7 = NULL;
	Type_t * V_8 = NULL;
	ObjectU5BU5D_t3614634134* V_9 = NULL;
	TypeU5BU5D_t1664964607* V_10 = NULL;
	bool V_11 = false;
	bool V_12 = false;
	ConstructorInfo_t2851816542 * V_13 = NULL;
	Il2CppObject * V_14 = NULL;
	Il2CppObject * V_15 = NULL;
	TargetInvocationException_t4098620458 * V_16 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = (Il2CppObject *)NULL;
		V_1 = (Il2CppObject *)NULL;
		ChannelData_t1489610737 * L_0 = ___channel0;
		ArrayList_t4252133567 * L_1 = ChannelData_get_ServerProviders_m237896543(L_0, /*hidden argument*/NULL);
		int32_t L_2 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_1);
		V_2 = ((int32_t)((int32_t)L_2-(int32_t)1));
		goto IL_0045;
	}

IL_0017:
	{
		ChannelData_t1489610737 * L_3 = ___channel0;
		ArrayList_t4252133567 * L_4 = ChannelData_get_ServerProviders_m237896543(L_3, /*hidden argument*/NULL);
		int32_t L_5 = V_2;
		Il2CppObject * L_6 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_4, L_5);
		V_3 = ((ProviderData_t2518653487 *)IsInstClass(L_6, ProviderData_t2518653487_il2cpp_TypeInfo_var));
		ProviderData_t2518653487 * L_7 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		Il2CppObject * L_8 = ChannelServices_CreateProvider_m2046737802(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
		V_4 = ((Il2CppObject *)Castclass(L_8, IServerChannelSinkProvider_t2060956099_il2cpp_TypeInfo_var));
		Il2CppObject * L_9 = V_4;
		Il2CppObject * L_10 = V_0;
		InterfaceActionInvoker1< Il2CppObject * >::Invoke(0 /* System.Void System.Runtime.Remoting.Channels.IServerChannelSinkProvider::set_Next(System.Runtime.Remoting.Channels.IServerChannelSinkProvider) */, IServerChannelSinkProvider_t2060956099_il2cpp_TypeInfo_var, L_9, L_10);
		Il2CppObject * L_11 = V_4;
		V_0 = L_11;
		int32_t L_12 = V_2;
		V_2 = ((int32_t)((int32_t)L_12-(int32_t)1));
	}

IL_0045:
	{
		int32_t L_13 = V_2;
		if ((((int32_t)L_13) >= ((int32_t)0)))
		{
			goto IL_0017;
		}
	}
	{
		ChannelData_t1489610737 * L_14 = ___channel0;
		ArrayList_t4252133567 * L_15 = ChannelData_get_ClientProviders_m648877347(L_14, /*hidden argument*/NULL);
		int32_t L_16 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_15);
		V_5 = ((int32_t)((int32_t)L_16-(int32_t)1));
		goto IL_0093;
	}

IL_0060:
	{
		ChannelData_t1489610737 * L_17 = ___channel0;
		ArrayList_t4252133567 * L_18 = ChannelData_get_ClientProviders_m648877347(L_17, /*hidden argument*/NULL);
		int32_t L_19 = V_5;
		Il2CppObject * L_20 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_18, L_19);
		V_6 = ((ProviderData_t2518653487 *)IsInstClass(L_20, ProviderData_t2518653487_il2cpp_TypeInfo_var));
		ProviderData_t2518653487 * L_21 = V_6;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		Il2CppObject * L_22 = ChannelServices_CreateProvider_m2046737802(NULL /*static, unused*/, L_21, /*hidden argument*/NULL);
		V_7 = ((Il2CppObject *)Castclass(L_22, IClientChannelSinkProvider_t2522474175_il2cpp_TypeInfo_var));
		Il2CppObject * L_23 = V_7;
		Il2CppObject * L_24 = V_1;
		InterfaceActionInvoker1< Il2CppObject * >::Invoke(0 /* System.Void System.Runtime.Remoting.Channels.IClientChannelSinkProvider::set_Next(System.Runtime.Remoting.Channels.IClientChannelSinkProvider) */, IClientChannelSinkProvider_t2522474175_il2cpp_TypeInfo_var, L_23, L_24);
		Il2CppObject * L_25 = V_7;
		V_1 = L_25;
		int32_t L_26 = V_5;
		V_5 = ((int32_t)((int32_t)L_26-(int32_t)1));
	}

IL_0093:
	{
		int32_t L_27 = V_5;
		if ((((int32_t)L_27) >= ((int32_t)0)))
		{
			goto IL_0060;
		}
	}
	{
		ChannelData_t1489610737 * L_28 = ___channel0;
		String_t* L_29 = L_28->get_Type_1();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_30 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m773255995, L_29, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		V_8 = L_30;
		Type_t * L_31 = V_8;
		if (L_31)
		{
			goto IL_00ca;
		}
	}
	{
		ChannelData_t1489610737 * L_32 = ___channel0;
		String_t* L_33 = L_32->get_Type_1();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_34 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral1763939415, L_33, _stringLiteral3813883430, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_35 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_35, L_34, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_35);
	}

IL_00ca:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_36 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IChannelSender_t714647579_0_0_0_var), /*hidden argument*/NULL);
		Type_t * L_37 = V_8;
		bool L_38 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_36, L_37);
		V_11 = L_38;
		Type_t * L_39 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IChannelReceiver_t2788889625_0_0_0_var), /*hidden argument*/NULL);
		Type_t * L_40 = V_8;
		bool L_41 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_39, L_40);
		V_12 = L_41;
		bool L_42 = V_11;
		if (!L_42)
		{
			goto IL_014b;
		}
	}
	{
		bool L_43 = V_12;
		if (!L_43)
		{
			goto IL_014b;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_44 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)3));
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_45 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IDictionary_t596158605_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_44, L_45);
		(L_44)->SetAt(static_cast<il2cpp_array_size_t>(0), (Type_t *)L_45);
		TypeU5BU5D_t1664964607* L_46 = L_44;
		Type_t * L_47 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IClientChannelSinkProvider_t2522474175_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_46, L_47);
		(L_46)->SetAt(static_cast<il2cpp_array_size_t>(1), (Type_t *)L_47);
		TypeU5BU5D_t1664964607* L_48 = L_46;
		Type_t * L_49 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IServerChannelSinkProvider_t2060956099_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_48, L_49);
		(L_48)->SetAt(static_cast<il2cpp_array_size_t>(2), (Type_t *)L_49);
		V_10 = L_48;
		ObjectU5BU5D_t3614634134* L_50 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)3));
		ChannelData_t1489610737 * L_51 = ___channel0;
		Hashtable_t909839986 * L_52 = ChannelData_get_CustomProperties_m1470957369(L_51, /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_50, L_52);
		(L_50)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_52);
		ObjectU5BU5D_t3614634134* L_53 = L_50;
		Il2CppObject * L_54 = V_1;
		ArrayElementTypeCheck (L_53, L_54);
		(L_53)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_54);
		ObjectU5BU5D_t3614634134* L_55 = L_53;
		Il2CppObject * L_56 = V_0;
		ArrayElementTypeCheck (L_55, L_56);
		(L_55)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)L_56);
		V_9 = L_55;
		goto IL_01e3;
	}

IL_014b:
	{
		bool L_57 = V_11;
		if (!L_57)
		{
			goto IL_018e;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_58 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)2));
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_59 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IDictionary_t596158605_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_58, L_59);
		(L_58)->SetAt(static_cast<il2cpp_array_size_t>(0), (Type_t *)L_59);
		TypeU5BU5D_t1664964607* L_60 = L_58;
		Type_t * L_61 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IClientChannelSinkProvider_t2522474175_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_60, L_61);
		(L_60)->SetAt(static_cast<il2cpp_array_size_t>(1), (Type_t *)L_61);
		V_10 = L_60;
		ObjectU5BU5D_t3614634134* L_62 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)2));
		ChannelData_t1489610737 * L_63 = ___channel0;
		Hashtable_t909839986 * L_64 = ChannelData_get_CustomProperties_m1470957369(L_63, /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_62, L_64);
		(L_62)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_64);
		ObjectU5BU5D_t3614634134* L_65 = L_62;
		Il2CppObject * L_66 = V_1;
		ArrayElementTypeCheck (L_65, L_66);
		(L_65)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_66);
		V_9 = L_65;
		goto IL_01e3;
	}

IL_018e:
	{
		bool L_67 = V_12;
		if (!L_67)
		{
			goto IL_01d1;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_68 = ((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)2));
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_69 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IDictionary_t596158605_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_68, L_69);
		(L_68)->SetAt(static_cast<il2cpp_array_size_t>(0), (Type_t *)L_69);
		TypeU5BU5D_t1664964607* L_70 = L_68;
		Type_t * L_71 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IServerChannelSinkProvider_t2060956099_0_0_0_var), /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_70, L_71);
		(L_70)->SetAt(static_cast<il2cpp_array_size_t>(1), (Type_t *)L_71);
		V_10 = L_70;
		ObjectU5BU5D_t3614634134* L_72 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)2));
		ChannelData_t1489610737 * L_73 = ___channel0;
		Hashtable_t909839986 * L_74 = ChannelData_get_CustomProperties_m1470957369(L_73, /*hidden argument*/NULL);
		ArrayElementTypeCheck (L_72, L_74);
		(L_72)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_74);
		ObjectU5BU5D_t3614634134* L_75 = L_72;
		Il2CppObject * L_76 = V_0;
		ArrayElementTypeCheck (L_75, L_76);
		(L_75)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_76);
		V_9 = L_75;
		goto IL_01e3;
	}

IL_01d1:
	{
		Type_t * L_77 = V_8;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_78 = String_Concat_m56707527(NULL /*static, unused*/, L_77, _stringLiteral4091618523, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_79 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_79, L_78, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_79);
	}

IL_01e3:
	{
		Type_t * L_80 = V_8;
		TypeU5BU5D_t1664964607* L_81 = V_10;
		ConstructorInfo_t2851816542 * L_82 = Type_GetConstructor_m132234455(L_80, L_81, /*hidden argument*/NULL);
		V_13 = L_82;
		ConstructorInfo_t2851816542 * L_83 = V_13;
		if (L_83)
		{
			goto IL_0207;
		}
	}
	{
		Type_t * L_84 = V_8;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_85 = String_Concat_m56707527(NULL /*static, unused*/, L_84, _stringLiteral2038899257, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_86 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_86, L_85, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_86);
	}

IL_0207:
	try
	{ // begin try (depth: 1)
		ConstructorInfo_t2851816542 * L_87 = V_13;
		ObjectU5BU5D_t3614634134* L_88 = V_9;
		Il2CppObject * L_89 = ConstructorInfo_Invoke_m2144827141(L_87, L_88, /*hidden argument*/NULL);
		V_14 = ((Il2CppObject *)Castclass(L_89, IChannel_t321318132_il2cpp_TypeInfo_var));
		goto IL_022b;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (TargetInvocationException_t4098620458_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_021c;
		throw e;
	}

CATCH_021c:
	{ // begin catch(System.Reflection.TargetInvocationException)
		{
			V_16 = ((TargetInvocationException_t4098620458 *)__exception_local);
			TargetInvocationException_t4098620458 * L_90 = V_16;
			Exception_t1927440687 * L_91 = Exception_get_InnerException_m3722561235(L_90, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_91);
		}

IL_0226:
		{
			goto IL_022b;
		}
	} // end catch (depth: 1)

IL_022b:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ArrayList_t4252133567 * L_92 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
		Il2CppObject * L_93 = VirtFuncInvoker0< Il2CppObject * >::Invoke(29 /* System.Object System.Collections.ArrayList::get_SyncRoot() */, L_92);
		V_15 = L_93;
		Il2CppObject * L_94 = V_15;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_94, /*hidden argument*/NULL);
	}

IL_023e:
	try
	{ // begin try (depth: 1)
		{
			ChannelData_t1489610737 * L_95 = ___channel0;
			String_t* L_96 = L_95->get_DelayLoadAsClientChannel_3();
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			bool L_97 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_96, _stringLiteral3323263070, /*hidden argument*/NULL);
			if (!L_97)
			{
				goto IL_0271;
			}
		}

IL_0253:
		{
			Il2CppObject * L_98 = V_14;
			if (((Il2CppObject *)IsInst(L_98, IChannelReceiver_t2788889625_il2cpp_TypeInfo_var)))
			{
				goto IL_0271;
			}
		}

IL_025f:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_99 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_delayedClientChannels_1();
			Il2CppObject * L_100 = V_14;
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_99, L_100);
			goto IL_0278;
		}

IL_0271:
		{
			Il2CppObject * L_101 = V_14;
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ChannelServices_RegisterChannel_m3832858065(NULL /*static, unused*/, L_101, /*hidden argument*/NULL);
		}

IL_0278:
		{
			IL2CPP_LEAVE(0x285, FINALLY_027d);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_027d;
	}

FINALLY_027d:
	{ // begin finally (depth: 1)
		Il2CppObject * L_102 = V_15;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_102, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(637)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(637)
	{
		IL2CPP_JUMP_TBL(0x285, IL_0285)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0285:
	{
		return;
	}
}
// System.Object System.Runtime.Remoting.Channels.ChannelServices::CreateProvider(System.Runtime.Remoting.ProviderData)
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* TargetInvocationException_t4098620458_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1763939415;
extern Il2CppCodeGenString* _stringLiteral3813883430;
extern Il2CppCodeGenString* _stringLiteral552753709;
extern Il2CppCodeGenString* _stringLiteral2448216006;
extern const uint32_t ChannelServices_CreateProvider_m2046737802_MetadataUsageId;
extern "C"  Il2CppObject * ChannelServices_CreateProvider_m2046737802 (Il2CppObject * __this /* static, unused */, ProviderData_t2518653487 * ___prov0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_CreateProvider_m2046737802_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Type_t * V_0 = NULL;
	ObjectU5BU5D_t3614634134* V_1 = NULL;
	Exception_t1927440687 * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ProviderData_t2518653487 * L_0 = ___prov0;
		String_t* L_1 = L_0->get_Type_1();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m773255995, L_1, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		V_0 = L_2;
		Type_t * L_3 = V_0;
		if (L_3)
		{
			goto IL_002d;
		}
	}
	{
		ProviderData_t2518653487 * L_4 = ___prov0;
		String_t* L_5 = L_4->get_Type_1();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_6 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral1763939415, L_5, _stringLiteral3813883430, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_7 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_7, L_6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_002d:
	{
		ObjectU5BU5D_t3614634134* L_8 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)2));
		ProviderData_t2518653487 * L_9 = ___prov0;
		Hashtable_t909839986 * L_10 = L_9->get_CustomProperties_3();
		ArrayElementTypeCheck (L_8, L_10);
		(L_8)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)L_10);
		ObjectU5BU5D_t3614634134* L_11 = L_8;
		ProviderData_t2518653487 * L_12 = ___prov0;
		Il2CppObject * L_13 = L_12->get_CustomData_4();
		ArrayElementTypeCheck (L_11, L_13);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_13);
		V_1 = L_11;
	}

IL_0046:
	try
	{ // begin try (depth: 1)
		{
			Type_t * L_14 = V_0;
			ObjectU5BU5D_t3614634134* L_15 = V_1;
			Il2CppObject * L_16 = Activator_CreateInstance_m1465989661(NULL /*static, unused*/, L_14, L_15, /*hidden argument*/NULL);
			V_3 = L_16;
			goto IL_00a3;
		}

IL_0053:
		{
			; // IL_0053: leave IL_00a3
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0058;
		throw e;
	}

CATCH_0058:
	{ // begin catch(System.Exception)
		{
			V_2 = ((Exception_t1927440687 *)__exception_local);
			Exception_t1927440687 * L_17 = V_2;
			if (!((TargetInvocationException_t4098620458 *)IsInstSealed(L_17, TargetInvocationException_t4098620458_il2cpp_TypeInfo_var)))
			{
				goto IL_0070;
			}
		}

IL_0064:
		{
			Exception_t1927440687 * L_18 = V_2;
			Exception_t1927440687 * L_19 = Exception_get_InnerException_m3722561235(((TargetInvocationException_t4098620458 *)CastclassSealed(L_18, TargetInvocationException_t4098620458_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
			V_2 = L_19;
		}

IL_0070:
		{
			ObjectU5BU5D_t3614634134* L_20 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)4));
			ArrayElementTypeCheck (L_20, _stringLiteral552753709);
			(L_20)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral552753709);
			ObjectU5BU5D_t3614634134* L_21 = L_20;
			Type_t * L_22 = V_0;
			ArrayElementTypeCheck (L_21, L_22);
			(L_21)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_22);
			ObjectU5BU5D_t3614634134* L_23 = L_21;
			ArrayElementTypeCheck (L_23, _stringLiteral2448216006);
			(L_23)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral2448216006);
			ObjectU5BU5D_t3614634134* L_24 = L_23;
			Exception_t1927440687 * L_25 = V_2;
			String_t* L_26 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Exception::get_Message() */, L_25);
			ArrayElementTypeCheck (L_24, L_26);
			(L_24)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_26);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_27 = String_Concat_m3881798623(NULL /*static, unused*/, L_24, /*hidden argument*/NULL);
			RemotingException_t109604560 * L_28 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3568495070(L_28, L_27, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_28);
		}

IL_009e:
		{
			goto IL_00a3;
		}
	} // end catch (depth: 1)

IL_00a3:
	{
		Il2CppObject * L_29 = V_3;
		return L_29;
	}
}
// System.Object[] System.Runtime.Remoting.Channels.ChannelServices::GetCurrentChannelInfo()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IChannelReceiver_t2788889625_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t ChannelServices_GetCurrentChannelInfo_m4080942430_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ChannelServices_GetCurrentChannelInfo_m4080942430 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ChannelServices_GetCurrentChannelInfo_m4080942430_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ArrayList_t4252133567 * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ArrayList_t4252133567 * L_1 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
		Il2CppObject * L_2 = VirtFuncInvoker0< Il2CppObject * >::Invoke(29 /* System.Object System.Collections.ArrayList::get_SyncRoot() */, L_1);
		V_1 = L_2;
		Il2CppObject * L_3 = V_1;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
	}

IL_0017:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
			ArrayList_t4252133567 * L_4 = ((ChannelServices_t2007814595_StaticFields*)ChannelServices_t2007814595_il2cpp_TypeInfo_var->static_fields)->get_registeredChannels_0();
			Il2CppObject * L_5 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_4);
			V_3 = L_5;
		}

IL_0022:
		try
		{ // begin try (depth: 2)
			{
				goto IL_0056;
			}

IL_0027:
			{
				Il2CppObject * L_6 = V_3;
				Il2CppObject * L_7 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_6);
				V_2 = L_7;
				Il2CppObject * L_8 = V_2;
				V_4 = ((Il2CppObject *)IsInst(L_8, IChannelReceiver_t2788889625_il2cpp_TypeInfo_var));
				Il2CppObject * L_9 = V_4;
				if (!L_9)
				{
					goto IL_0056;
				}
			}

IL_003d:
			{
				Il2CppObject * L_10 = V_4;
				Il2CppObject * L_11 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Runtime.Remoting.Channels.IChannelReceiver::get_ChannelData() */, IChannelReceiver_t2788889625_il2cpp_TypeInfo_var, L_10);
				V_5 = L_11;
				Il2CppObject * L_12 = V_5;
				if (!L_12)
				{
					goto IL_0056;
				}
			}

IL_004d:
			{
				ArrayList_t4252133567 * L_13 = V_0;
				Il2CppObject * L_14 = V_5;
				VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_13, L_14);
			}

IL_0056:
			{
				Il2CppObject * L_15 = V_3;
				bool L_16 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_15);
				if (L_16)
				{
					goto IL_0027;
				}
			}

IL_0061:
			{
				IL2CPP_LEAVE(0x7B, FINALLY_0066);
			}
		} // end try (depth: 2)
		catch(Il2CppExceptionWrapper& e)
		{
			__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
			goto FINALLY_0066;
		}

FINALLY_0066:
		{ // begin finally (depth: 2)
			{
				Il2CppObject * L_17 = V_3;
				V_6 = ((Il2CppObject *)IsInst(L_17, IDisposable_t2427283555_il2cpp_TypeInfo_var));
				Il2CppObject * L_18 = V_6;
				if (L_18)
				{
					goto IL_0073;
				}
			}

IL_0072:
			{
				IL2CPP_END_FINALLY(102)
			}

IL_0073:
			{
				Il2CppObject * L_19 = V_6;
				InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_19);
				IL2CPP_END_FINALLY(102)
			}
		} // end finally (depth: 2)
		IL2CPP_CLEANUP(102)
		{
			IL2CPP_JUMP_TBL(0x7B, IL_007b)
			IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
		}

IL_007b:
		{
			IL2CPP_LEAVE(0x87, FINALLY_0080);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0080;
	}

FINALLY_0080:
	{ // begin finally (depth: 1)
		Il2CppObject * L_20 = V_1;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_20, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(128)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(128)
	{
		IL2CPP_JUMP_TBL(0x87, IL_0087)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0087:
	{
		ArrayList_t4252133567 * L_21 = V_0;
		ObjectU5BU5D_t3614634134* L_22 = VirtFuncInvoker0< ObjectU5BU5D_t3614634134* >::Invoke(47 /* System.Object[] System.Collections.ArrayList::ToArray() */, L_21);
		return L_22;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainChannel::.ctor()
extern "C"  void CrossAppDomainChannel__ctor_m1339843788 (CrossAppDomainChannel_t2471623380 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainChannel::.cctor()
extern Il2CppClass* Il2CppObject_il2cpp_TypeInfo_var;
extern Il2CppClass* CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var;
extern const uint32_t CrossAppDomainChannel__cctor_m719086939_MetadataUsageId;
extern "C"  void CrossAppDomainChannel__cctor_m719086939 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainChannel__cctor_m719086939_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = (Il2CppObject *)il2cpp_codegen_object_new(Il2CppObject_il2cpp_TypeInfo_var);
		Object__ctor_m2551263788(L_0, /*hidden argument*/NULL);
		((CrossAppDomainChannel_t2471623380_StaticFields*)CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var->static_fields)->set_s_lock_0(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainChannel::RegisterCrossAppDomainChannel()
extern Il2CppClass* CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var;
extern Il2CppClass* ChannelServices_t2007814595_il2cpp_TypeInfo_var;
extern const uint32_t CrossAppDomainChannel_RegisterCrossAppDomainChannel_m43456045_MetadataUsageId;
extern "C"  void CrossAppDomainChannel_RegisterCrossAppDomainChannel_m43456045 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainChannel_RegisterCrossAppDomainChannel_m43456045_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	CrossAppDomainChannel_t2471623380 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var);
		Il2CppObject * L_0 = ((CrossAppDomainChannel_t2471623380_StaticFields*)CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var->static_fields)->get_s_lock_0();
		V_0 = L_0;
		Il2CppObject * L_1 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		CrossAppDomainChannel_t2471623380 * L_2 = (CrossAppDomainChannel_t2471623380 *)il2cpp_codegen_object_new(CrossAppDomainChannel_t2471623380_il2cpp_TypeInfo_var);
		CrossAppDomainChannel__ctor_m1339843788(L_2, /*hidden argument*/NULL);
		V_1 = L_2;
		CrossAppDomainChannel_t2471623380 * L_3 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(ChannelServices_t2007814595_il2cpp_TypeInfo_var);
		ChannelServices_RegisterChannel_m3832858065(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		IL2CPP_LEAVE(0x24, FINALLY_001d);
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_001d;
	}

FINALLY_001d:
	{ // begin finally (depth: 1)
		Il2CppObject * L_4 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_4, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(29)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(29)
	{
		IL2CPP_JUMP_TBL(0x24, IL_0024)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0024:
	{
		return;
	}
}
// System.String System.Runtime.Remoting.Channels.CrossAppDomainChannel::get_ChannelName()
extern Il2CppCodeGenString* _stringLiteral2604733013;
extern const uint32_t CrossAppDomainChannel_get_ChannelName_m3211498928_MetadataUsageId;
extern "C"  String_t* CrossAppDomainChannel_get_ChannelName_m3211498928 (CrossAppDomainChannel_t2471623380 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainChannel_get_ChannelName_m3211498928_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		return _stringLiteral2604733013;
	}
}
// System.Int32 System.Runtime.Remoting.Channels.CrossAppDomainChannel::get_ChannelPriority()
extern "C"  int32_t CrossAppDomainChannel_get_ChannelPriority_m3276663196 (CrossAppDomainChannel_t2471623380 * __this, const MethodInfo* method)
{
	{
		return ((int32_t)100);
	}
}
// System.Object System.Runtime.Remoting.Channels.CrossAppDomainChannel::get_ChannelData()
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* CrossAppDomainData_t816071813_il2cpp_TypeInfo_var;
extern const uint32_t CrossAppDomainChannel_get_ChannelData_m2208828775_MetadataUsageId;
extern "C"  Il2CppObject * CrossAppDomainChannel_get_ChannelData_m2208828775 (CrossAppDomainChannel_t2471623380 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainChannel_get_ChannelData_m2208828775_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		int32_t L_0 = Thread_GetDomainID_m21918982(NULL /*static, unused*/, /*hidden argument*/NULL);
		CrossAppDomainData_t816071813 * L_1 = (CrossAppDomainData_t816071813 *)il2cpp_codegen_object_new(CrossAppDomainData_t816071813_il2cpp_TypeInfo_var);
		CrossAppDomainData__ctor_m899931420(L_1, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainChannel::StartListening(System.Object)
extern "C"  void CrossAppDomainChannel_StartListening_m3076788403 (CrossAppDomainChannel_t2471623380 * __this, Il2CppObject * ___data0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Channels.CrossAppDomainChannel::CreateMessageSink(System.String,System.Object,System.String&)
extern Il2CppClass* CrossAppDomainData_t816071813_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var;
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2604733013;
extern Il2CppCodeGenString* _stringLiteral1269728551;
extern const uint32_t CrossAppDomainChannel_CreateMessageSink_m387874432_MetadataUsageId;
extern "C"  Il2CppObject * CrossAppDomainChannel_CreateMessageSink_m387874432 (CrossAppDomainChannel_t2471623380 * __this, String_t* ___url0, Il2CppObject * ___data1, String_t** ___uri2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainChannel_CreateMessageSink_m387874432_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	CrossAppDomainData_t816071813 * V_0 = NULL;
	{
		String_t** L_0 = ___uri2;
		*((Il2CppObject **)(L_0)) = (Il2CppObject *)NULL;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_0), (Il2CppObject *)NULL);
		Il2CppObject * L_1 = ___data1;
		if (!L_1)
		{
			goto IL_0037;
		}
	}
	{
		Il2CppObject * L_2 = ___data1;
		V_0 = ((CrossAppDomainData_t816071813 *)IsInstClass(L_2, CrossAppDomainData_t816071813_il2cpp_TypeInfo_var));
		CrossAppDomainData_t816071813 * L_3 = V_0;
		if (!L_3)
		{
			goto IL_0037;
		}
	}
	{
		CrossAppDomainData_t816071813 * L_4 = V_0;
		String_t* L_5 = CrossAppDomainData_get_ProcessID_m2865289777(L_4, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		String_t* L_6 = RemotingConfiguration_get_ProcessId_m3870172209(NULL /*static, unused*/, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_7 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_5, L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0037;
		}
	}
	{
		CrossAppDomainData_t816071813 * L_8 = V_0;
		int32_t L_9 = CrossAppDomainData_get_DomainID_m2128092389(L_8, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
		CrossAppDomainSink_t2368859578 * L_10 = CrossAppDomainSink_GetSink_m357206043(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		return L_10;
	}

IL_0037:
	{
		String_t* L_11 = ___url0;
		if (!L_11)
		{
			goto IL_0058;
		}
	}
	{
		String_t* L_12 = ___url0;
		bool L_13 = String_StartsWith_m1841920685(L_12, _stringLiteral2604733013, /*hidden argument*/NULL);
		if (!L_13)
		{
			goto IL_0058;
		}
	}
	{
		NotSupportedException_t1793819818 * L_14 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_14, _stringLiteral1269728551, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_14);
	}

IL_0058:
	{
		return (Il2CppObject *)NULL;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainData::.ctor(System.Int32)
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern const uint32_t CrossAppDomainData__ctor_m899931420_MetadataUsageId;
extern "C"  void CrossAppDomainData__ctor_m899931420 (CrossAppDomainData_t816071813 * __this, int32_t ___domainId0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainData__ctor_m899931420_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		int32_t L_0 = 0;
		Il2CppObject * L_1 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_0);
		__this->set__ContextID_0(L_1);
		int32_t L_2 = ___domainId0;
		__this->set__DomainID_1(L_2);
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		String_t* L_3 = RemotingConfiguration_get_ProcessId_m3870172209(NULL /*static, unused*/, /*hidden argument*/NULL);
		__this->set__processGuid_2(L_3);
		return;
	}
}
// System.Int32 System.Runtime.Remoting.Channels.CrossAppDomainData::get_DomainID()
extern "C"  int32_t CrossAppDomainData_get_DomainID_m2128092389 (CrossAppDomainData_t816071813 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get__DomainID_1();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.Channels.CrossAppDomainData::get_ProcessID()
extern "C"  String_t* CrossAppDomainData_get_ProcessID_m2865289777 (CrossAppDomainData_t816071813 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__processGuid_2();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainSink::.ctor(System.Int32)
extern "C"  void CrossAppDomainSink__ctor_m3413812769 (CrossAppDomainSink_t2368859578 * __this, int32_t ___domainID0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___domainID0;
		__this->set__domainID_2(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Channels.CrossAppDomainSink::.cctor()
extern const Il2CppType* CrossAppDomainSink_t2368859578_0_0_0_var;
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern Il2CppClass* CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral510458675;
extern const uint32_t CrossAppDomainSink__cctor_m1547233779_MetadataUsageId;
extern "C"  void CrossAppDomainSink__cctor_m1547233779 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainSink__cctor_m1547233779_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_0, /*hidden argument*/NULL);
		((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->set_s_sinks_0(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_1 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(CrossAppDomainSink_t2368859578_0_0_0_var), /*hidden argument*/NULL);
		MethodInfo_t * L_2 = Type_GetMethod_m475234662(L_1, _stringLiteral510458675, ((int32_t)40), /*hidden argument*/NULL);
		((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->set_processMessageMethod_1(L_2);
		return;
	}
}
// System.Runtime.Remoting.Channels.CrossAppDomainSink System.Runtime.Remoting.Channels.CrossAppDomainSink::GetSink(System.Int32)
extern Il2CppClass* CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern const uint32_t CrossAppDomainSink_GetSink_m357206043_MetadataUsageId;
extern "C"  CrossAppDomainSink_t2368859578 * CrossAppDomainSink_GetSink_m357206043 (Il2CppObject * __this /* static, unused */, int32_t ___domainID0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CrossAppDomainSink_GetSink_m357206043_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	CrossAppDomainSink_t2368859578 * V_1 = NULL;
	CrossAppDomainSink_t2368859578 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_0 = ((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->get_s_sinks_0();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(19 /* System.Object System.Collections.Hashtable::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0011:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_3 = ((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->get_s_sinks_0();
			int32_t L_4 = ___domainID0;
			int32_t L_5 = L_4;
			Il2CppObject * L_6 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_5);
			bool L_7 = VirtFuncInvoker1< bool, Il2CppObject * >::Invoke(30 /* System.Boolean System.Collections.Hashtable::ContainsKey(System.Object) */, L_3, L_6);
			if (!L_7)
			{
				goto IL_0041;
			}
		}

IL_0026:
		{
			IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_8 = ((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->get_s_sinks_0();
			int32_t L_9 = ___domainID0;
			int32_t L_10 = L_9;
			Il2CppObject * L_11 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_10);
			Il2CppObject * L_12 = VirtFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(22 /* System.Object System.Collections.Hashtable::get_Item(System.Object) */, L_8, L_11);
			V_2 = ((CrossAppDomainSink_t2368859578 *)CastclassClass(L_12, CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var));
			IL2CPP_LEAVE(0x6C, FINALLY_0065);
		}

IL_0041:
		{
			int32_t L_13 = ___domainID0;
			CrossAppDomainSink_t2368859578 * L_14 = (CrossAppDomainSink_t2368859578 *)il2cpp_codegen_object_new(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
			CrossAppDomainSink__ctor_m3413812769(L_14, L_13, /*hidden argument*/NULL);
			V_1 = L_14;
			IL2CPP_RUNTIME_CLASS_INIT(CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_15 = ((CrossAppDomainSink_t2368859578_StaticFields*)CrossAppDomainSink_t2368859578_il2cpp_TypeInfo_var->static_fields)->get_s_sinks_0();
			int32_t L_16 = ___domainID0;
			int32_t L_17 = L_16;
			Il2CppObject * L_18 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_17);
			CrossAppDomainSink_t2368859578 * L_19 = V_1;
			VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(23 /* System.Void System.Collections.Hashtable::set_Item(System.Object,System.Object) */, L_15, L_18, L_19);
			CrossAppDomainSink_t2368859578 * L_20 = V_1;
			V_2 = L_20;
			IL2CPP_LEAVE(0x6C, FINALLY_0065);
		}

IL_0060:
		{
			; // IL_0060: leave IL_006c
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0065;
	}

FINALLY_0065:
	{ // begin finally (depth: 1)
		Il2CppObject * L_21 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_21, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(101)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(101)
	{
		IL2CPP_JUMP_TBL(0x6C, IL_006c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_006c:
	{
		CrossAppDomainSink_t2368859578 * L_22 = V_2;
		return L_22;
	}
}
// System.Int32 System.Runtime.Remoting.Channels.CrossAppDomainSink::get_TargetDomainId()
extern "C"  int32_t CrossAppDomainSink_get_TargetDomainId_m775204051 (CrossAppDomainSink_t2368859578 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get__domainID_2();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Channels.SinkProviderData::.ctor(System.String)
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern const uint32_t SinkProviderData__ctor_m1828480392_MetadataUsageId;
extern "C"  void SinkProviderData__ctor_m1828480392 (SinkProviderData_t2645445792 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SinkProviderData__ctor_m1828480392_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___name0;
		__this->set_sinkName_0(L_0);
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set_children_1(L_1);
		Hashtable_t909839986 * L_2 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_2, /*hidden argument*/NULL);
		__this->set_properties_2(L_2);
		return;
	}
}
// System.Collections.IList System.Runtime.Remoting.Channels.SinkProviderData::get_Children()
extern "C"  Il2CppObject * SinkProviderData_get_Children_m100594762 (SinkProviderData_t2645445792 * __this, const MethodInfo* method)
{
	{
		ArrayList_t4252133567 * L_0 = __this->get_children_1();
		return L_0;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Channels.SinkProviderData::get_Properties()
extern "C"  Il2CppObject * SinkProviderData_get_Properties_m536484876 (SinkProviderData_t2645445792 * __this, const MethodInfo* method)
{
	{
		Hashtable_t909839986 * L_0 = __this->get_properties_2();
		return L_0;
	}
}
// System.MarshalByRefObject System.Runtime.Remoting.ClientActivatedIdentity::GetServerObject()
extern "C"  MarshalByRefObject_t1285298191 * ClientActivatedIdentity_GetServerObject_m3122151757 (ClientActivatedIdentity_t1467784146 * __this, const MethodInfo* method)
{
	{
		MarshalByRefObject_t1285298191 * L_0 = ((ServerIdentity_t1656058977 *)__this)->get__serverObject_8();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.ClientIdentity::.ctor(System.String,System.Runtime.Remoting.ObjRef)
extern Il2CppClass* IEnvoyInfo_t503256512_il2cpp_TypeInfo_var;
extern const uint32_t ClientIdentity__ctor_m1342022863_MetadataUsageId;
extern "C"  void ClientIdentity__ctor_m1342022863 (ClientIdentity_t2254682501 * __this, String_t* ___objectUri0, ObjRef_t318414488 * ___objRef1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ClientIdentity__ctor_m1342022863_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	ClientIdentity_t2254682501 * G_B2_0 = NULL;
	ClientIdentity_t2254682501 * G_B1_0 = NULL;
	Il2CppObject * G_B3_0 = NULL;
	ClientIdentity_t2254682501 * G_B3_1 = NULL;
	{
		String_t* L_0 = ___objectUri0;
		Identity__ctor_m3398266716(__this, L_0, /*hidden argument*/NULL);
		ObjRef_t318414488 * L_1 = ___objRef1;
		((Identity_t3647548000 *)__this)->set__objRef_5(L_1);
		ObjRef_t318414488 * L_2 = ((Identity_t3647548000 *)__this)->get__objRef_5();
		Il2CppObject * L_3 = VirtFuncInvoker0< Il2CppObject * >::Invoke(7 /* System.Runtime.Remoting.IEnvoyInfo System.Runtime.Remoting.ObjRef::get_EnvoyInfo() */, L_2);
		G_B1_0 = __this;
		if (!L_3)
		{
			G_B2_0 = __this;
			goto IL_0036;
		}
	}
	{
		ObjRef_t318414488 * L_4 = ((Identity_t3647548000 *)__this)->get__objRef_5();
		Il2CppObject * L_5 = VirtFuncInvoker0< Il2CppObject * >::Invoke(7 /* System.Runtime.Remoting.IEnvoyInfo System.Runtime.Remoting.ObjRef::get_EnvoyInfo() */, L_4);
		Il2CppObject * L_6 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.IEnvoyInfo::get_EnvoySinks() */, IEnvoyInfo_t503256512_il2cpp_TypeInfo_var, L_5);
		V_0 = L_6;
		Il2CppObject * L_7 = V_0;
		G_B3_0 = L_7;
		G_B3_1 = G_B1_0;
		goto IL_0037;
	}

IL_0036:
	{
		G_B3_0 = ((Il2CppObject *)(NULL));
		G_B3_1 = G_B2_0;
	}

IL_0037:
	{
		((Identity_t3647548000 *)G_B3_1)->set__envoySink_2(G_B3_0);
		return;
	}
}
// System.MarshalByRefObject System.Runtime.Remoting.ClientIdentity::get_ClientProxy()
extern Il2CppClass* MarshalByRefObject_t1285298191_il2cpp_TypeInfo_var;
extern const uint32_t ClientIdentity_get_ClientProxy_m4052942792_MetadataUsageId;
extern "C"  MarshalByRefObject_t1285298191 * ClientIdentity_get_ClientProxy_m4052942792 (ClientIdentity_t2254682501 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ClientIdentity_get_ClientProxy_m4052942792_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		WeakReference_t1077405567 * L_0 = __this->get__proxyReference_7();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Object System.WeakReference::get_Target() */, L_0);
		return ((MarshalByRefObject_t1285298191 *)CastclassClass(L_1, MarshalByRefObject_t1285298191_il2cpp_TypeInfo_var));
	}
}
// System.Void System.Runtime.Remoting.ClientIdentity::set_ClientProxy(System.MarshalByRefObject)
extern Il2CppClass* WeakReference_t1077405567_il2cpp_TypeInfo_var;
extern const uint32_t ClientIdentity_set_ClientProxy_m3932647473_MetadataUsageId;
extern "C"  void ClientIdentity_set_ClientProxy_m3932647473 (ClientIdentity_t2254682501 * __this, MarshalByRefObject_t1285298191 * ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ClientIdentity_set_ClientProxy_m3932647473_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		MarshalByRefObject_t1285298191 * L_0 = ___value0;
		WeakReference_t1077405567 * L_1 = (WeakReference_t1077405567 *)il2cpp_codegen_object_new(WeakReference_t1077405567_il2cpp_TypeInfo_var);
		WeakReference__ctor_m1761774950(L_1, L_0, /*hidden argument*/NULL);
		__this->set__proxyReference_7(L_1);
		return;
	}
}
// System.Runtime.Remoting.ObjRef System.Runtime.Remoting.ClientIdentity::CreateObjRef(System.Type)
extern "C"  ObjRef_t318414488 * ClientIdentity_CreateObjRef_m3625915063 (ClientIdentity_t2254682501 * __this, Type_t * ___requestedType0, const MethodInfo* method)
{
	{
		ObjRef_t318414488 * L_0 = ((Identity_t3647548000 *)__this)->get__objRef_5();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.ClientIdentity::get_TargetUri()
extern "C"  String_t* ClientIdentity_get_TargetUri_m1801235322 (ClientIdentity_t2254682501 * __this, const MethodInfo* method)
{
	{
		ObjRef_t318414488 * L_0 = ((Identity_t3647548000 *)__this)->get__objRef_5();
		String_t* L_1 = VirtFuncInvoker0< String_t* >::Invoke(11 /* System.String System.Runtime.Remoting.ObjRef::get_URI() */, L_0);
		return L_1;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::.ctor(System.Boolean)
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t ConfigHandler__ctor_m3798700643_MetadataUsageId;
extern "C"  void ConfigHandler__ctor_m3798700643 (ConfigHandler_t2180714860 * __this, bool ___onlyDelayedChannels0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler__ctor_m3798700643_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		__this->set_typeEntries_0(L_0);
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set_channelInstances_1(L_1);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_2 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		__this->set_currentXmlPath_6(L_2);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		bool L_3 = ___onlyDelayedChannels0;
		__this->set_onlyDelayedChannels_7(L_3);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ValidatePath(System.String,System.String[])
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1660381862;
extern Il2CppCodeGenString* _stringLiteral2704069319;
extern const uint32_t ConfigHandler_ValidatePath_m3188987489_MetadataUsageId;
extern "C"  void ConfigHandler_ValidatePath_m3188987489 (ConfigHandler_t2180714860 * __this, String_t* ___element0, StringU5BU5D_t1642385972* ___paths1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ValidatePath_m3188987489_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	StringU5BU5D_t1642385972* V_1 = NULL;
	int32_t V_2 = 0;
	{
		StringU5BU5D_t1642385972* L_0 = ___paths1;
		V_1 = L_0;
		V_2 = 0;
		goto IL_001e;
	}

IL_0009:
	{
		StringU5BU5D_t1642385972* L_1 = V_1;
		int32_t L_2 = V_2;
		int32_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		V_0 = L_4;
		String_t* L_5 = V_0;
		bool L_6 = ConfigHandler_CheckPath_m2296459741(__this, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_001a;
		}
	}
	{
		return;
	}

IL_001a:
	{
		int32_t L_7 = V_2;
		V_2 = ((int32_t)((int32_t)L_7+(int32_t)1));
	}

IL_001e:
	{
		int32_t L_8 = V_2;
		StringU5BU5D_t1642385972* L_9 = V_1;
		if ((((int32_t)L_8) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length)))))))
		{
			goto IL_0009;
		}
	}
	{
		String_t* L_10 = ___element0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_11 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral1660381862, L_10, _stringLiteral2704069319, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_12 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_12, L_11, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_12);
	}
}
// System.Boolean System.Runtime.Remoting.ConfigHandler::CheckPath(System.String)
extern Il2CppClass* CultureInfo_t3500843524_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral372029315;
extern const uint32_t ConfigHandler_CheckPath_m2296459741_MetadataUsageId;
extern "C"  bool ConfigHandler_CheckPath_m2296459741 (ConfigHandler_t2180714860 * __this, String_t* ___path0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_CheckPath_m2296459741_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	CompareInfo_t2310920157 * V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(CultureInfo_t3500843524_il2cpp_TypeInfo_var);
		CultureInfo_t3500843524 * L_0 = CultureInfo_get_InvariantCulture_m398972276(NULL /*static, unused*/, /*hidden argument*/NULL);
		CompareInfo_t2310920157 * L_1 = VirtFuncInvoker0< CompareInfo_t2310920157 * >::Invoke(11 /* System.Globalization.CompareInfo System.Globalization.CultureInfo::get_CompareInfo() */, L_0);
		V_0 = L_1;
		CompareInfo_t2310920157 * L_2 = V_0;
		String_t* L_3 = ___path0;
		bool L_4 = VirtFuncInvoker3< bool, String_t*, String_t*, int32_t >::Invoke(11 /* System.Boolean System.Globalization.CompareInfo::IsPrefix(System.String,System.String,System.Globalization.CompareOptions) */, L_2, L_3, _stringLiteral372029315, ((int32_t)1073741824));
		if (!L_4)
		{
			goto IL_002e;
		}
	}
	{
		String_t* L_5 = ___path0;
		String_t* L_6 = __this->get_currentXmlPath_6();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_7 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_5, L_6, /*hidden argument*/NULL);
		return L_7;
	}

IL_002e:
	{
		CompareInfo_t2310920157 * L_8 = V_0;
		String_t* L_9 = __this->get_currentXmlPath_6();
		String_t* L_10 = ___path0;
		bool L_11 = VirtFuncInvoker3< bool, String_t*, String_t*, int32_t >::Invoke(12 /* System.Boolean System.Globalization.CompareInfo::IsSuffix(System.String,System.String,System.Globalization.CompareOptions) */, L_8, L_9, L_10, ((int32_t)1073741824));
		return L_11;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnStartParsing(Mono.Xml.SmallXmlParser)
extern "C"  void ConfigHandler_OnStartParsing_m2298792064 (ConfigHandler_t2180714860 * __this, SmallXmlParser_t3549787957 * ___parser0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnProcessingInstruction(System.String,System.String)
extern "C"  void ConfigHandler_OnProcessingInstruction_m1977038436 (ConfigHandler_t2180714860 * __this, String_t* ___name0, String_t* ___text1, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnIgnorableWhitespace(System.String)
extern "C"  void ConfigHandler_OnIgnorableWhitespace_m1819705975 (ConfigHandler_t2180714860 * __this, String_t* ___s0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnStartElement(System.String,Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1118843986;
extern Il2CppCodeGenString* _stringLiteral372029315;
extern Il2CppCodeGenString* _stringLiteral3346588105;
extern Il2CppCodeGenString* _stringLiteral811305496;
extern const uint32_t ConfigHandler_OnStartElement_m2567023365_MetadataUsageId;
extern "C"  void ConfigHandler_OnStartElement_m2567023365 (ConfigHandler_t2180714860 * __this, String_t* ___name0, Il2CppObject * ___attrs1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_OnStartElement_m2567023365_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Exception_t1927440687 * V_0 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		{
			String_t* L_0 = __this->get_currentXmlPath_6();
			bool L_1 = String_StartsWith_m1841920685(L_0, _stringLiteral1118843986, /*hidden argument*/NULL);
			if (!L_1)
			{
				goto IL_001d;
			}
		}

IL_0015:
		{
			String_t* L_2 = ___name0;
			Il2CppObject * L_3 = ___attrs1;
			ConfigHandler_ParseElement_m713051069(__this, L_2, L_3, /*hidden argument*/NULL);
		}

IL_001d:
		{
			String_t* L_4 = __this->get_currentXmlPath_6();
			String_t* L_5 = ___name0;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_6 = String_Concat_m612901809(NULL /*static, unused*/, L_4, _stringLiteral372029315, L_5, /*hidden argument*/NULL);
			__this->set_currentXmlPath_6(L_6);
			goto IL_005c;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0039;
		throw e;
	}

CATCH_0039:
	{ // begin catch(System.Exception)
		{
			V_0 = ((Exception_t1927440687 *)__exception_local);
			String_t* L_7 = ___name0;
			Exception_t1927440687 * L_8 = V_0;
			String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Exception::get_Message() */, L_8);
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_10 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral3346588105, L_7, _stringLiteral811305496, L_9, /*hidden argument*/NULL);
			Exception_t1927440687 * L_11 = V_0;
			RemotingException_t109604560 * L_12 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3560220926(L_12, L_10, L_11, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_12);
		}

IL_0057:
		{
			goto IL_005c;
		}
	} // end catch (depth: 1)

IL_005c:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ParseElement(System.String,Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* ConfigHandler_t2180714860_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral3130431008;
extern Il2CppCodeGenString* _stringLiteral3464432975;
extern Il2CppCodeGenString* _stringLiteral825743886;
extern Il2CppCodeGenString* _stringLiteral3637194755;
extern Il2CppCodeGenString* _stringLiteral1818391887;
extern Il2CppCodeGenString* _stringLiteral3749654163;
extern Il2CppCodeGenString* _stringLiteral1681167945;
extern Il2CppCodeGenString* _stringLiteral3881083812;
extern Il2CppCodeGenString* _stringLiteral3374638073;
extern Il2CppCodeGenString* _stringLiteral1905906193;
extern Il2CppCodeGenString* _stringLiteral2752322653;
extern Il2CppCodeGenString* _stringLiteral540185389;
extern Il2CppCodeGenString* _stringLiteral2652186846;
extern Il2CppCodeGenString* _stringLiteral1079412832;
extern Il2CppCodeGenString* _stringLiteral1870696200;
extern Il2CppCodeGenString* _stringLiteral1244735261;
extern Il2CppCodeGenString* _stringLiteral882420973;
extern Il2CppCodeGenString* _stringLiteral2787760668;
extern Il2CppCodeGenString* _stringLiteral2468267234;
extern Il2CppCodeGenString* _stringLiteral1804801784;
extern Il2CppCodeGenString* _stringLiteral2632115629;
extern Il2CppCodeGenString* _stringLiteral1878791818;
extern Il2CppCodeGenString* _stringLiteral3950396857;
extern Il2CppCodeGenString* _stringLiteral564554174;
extern Il2CppCodeGenString* _stringLiteral2317236068;
extern Il2CppCodeGenString* _stringLiteral27726768;
extern Il2CppCodeGenString* _stringLiteral386853519;
extern Il2CppCodeGenString* _stringLiteral1414244983;
extern Il2CppCodeGenString* _stringLiteral4067733765;
extern Il2CppCodeGenString* _stringLiteral1983445210;
extern const uint32_t ConfigHandler_ParseElement_m713051069_MetadataUsageId;
extern "C"  void ConfigHandler_ParseElement_m713051069 (ConfigHandler_t2180714860 * __this, String_t* ___name0, Il2CppObject * ___attrs1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ParseElement_m713051069_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ProviderData_t2518653487 * V_0 = NULL;
	String_t* V_1 = NULL;
	Dictionary_2_t3986656710 * V_2 = NULL;
	int32_t V_3 = 0;
	{
		Stack_t1043988394 * L_0 = __this->get_currentProviderData_3();
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		String_t* L_1 = ___name0;
		Il2CppObject * L_2 = ___attrs1;
		ConfigHandler_ReadCustomProviderData_m784203316(__this, L_1, L_2, /*hidden argument*/NULL);
		return;
	}

IL_0014:
	{
		String_t* L_3 = ___name0;
		V_1 = L_3;
		String_t* L_4 = V_1;
		if (!L_4)
		{
			goto IL_0512;
		}
	}
	{
		Dictionary_2_t3986656710 * L_5 = ((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map27_8();
		if (L_5)
		{
			goto IL_0121;
		}
	}
	{
		Dictionary_2_t3986656710 * L_6 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_6, ((int32_t)19), /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_2 = L_6;
		Dictionary_2_t3986656710 * L_7 = V_2;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral3130431008, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_2;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral3464432975, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_2;
		Dictionary_2_Add_m1209957957(L_9, _stringLiteral825743886, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_10 = V_2;
		Dictionary_2_Add_m1209957957(L_10, _stringLiteral3637194755, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_11 = V_2;
		Dictionary_2_Add_m1209957957(L_11, _stringLiteral1818391887, 4, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_12 = V_2;
		Dictionary_2_Add_m1209957957(L_12, _stringLiteral3749654163, 5, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_13 = V_2;
		Dictionary_2_Add_m1209957957(L_13, _stringLiteral1681167945, 6, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_14 = V_2;
		Dictionary_2_Add_m1209957957(L_14, _stringLiteral3881083812, 6, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_15 = V_2;
		Dictionary_2_Add_m1209957957(L_15, _stringLiteral3374638073, 7, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_16 = V_2;
		Dictionary_2_Add_m1209957957(L_16, _stringLiteral1905906193, 8, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_17 = V_2;
		Dictionary_2_Add_m1209957957(L_17, _stringLiteral2752322653, ((int32_t)9), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_18 = V_2;
		Dictionary_2_Add_m1209957957(L_18, _stringLiteral540185389, ((int32_t)10), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_19 = V_2;
		Dictionary_2_Add_m1209957957(L_19, _stringLiteral2652186846, ((int32_t)11), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_20 = V_2;
		Dictionary_2_Add_m1209957957(L_20, _stringLiteral1079412832, ((int32_t)12), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_21 = V_2;
		Dictionary_2_Add_m1209957957(L_21, _stringLiteral1870696200, ((int32_t)13), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_22 = V_2;
		Dictionary_2_Add_m1209957957(L_22, _stringLiteral1244735261, ((int32_t)14), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_23 = V_2;
		Dictionary_2_Add_m1209957957(L_23, _stringLiteral882420973, ((int32_t)15), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_24 = V_2;
		Dictionary_2_Add_m1209957957(L_24, _stringLiteral2787760668, ((int32_t)16), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_25 = V_2;
		Dictionary_2_Add_m1209957957(L_25, _stringLiteral2468267234, ((int32_t)17), /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_26 = V_2;
		((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map27_8(L_26);
	}

IL_0121:
	{
		Dictionary_2_t3986656710 * L_27 = ((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map27_8();
		String_t* L_28 = V_1;
		bool L_29 = Dictionary_2_TryGetValue_m2977303364(L_27, L_28, (&V_3), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_29)
		{
			goto IL_0512;
		}
	}
	{
		int32_t L_30 = V_3;
		if (L_30 == 0)
		{
			goto IL_0186;
		}
		if (L_30 == 1)
		{
			goto IL_01bc;
		}
		if (L_30 == 2)
		{
			goto IL_01dd;
		}
		if (L_30 == 3)
		{
			goto IL_01ff;
		}
		if (L_30 == 4)
		{
			goto IL_0244;
		}
		if (L_30 == 5)
		{
			goto IL_0266;
		}
		if (L_30 == 6)
		{
			goto IL_0288;
		}
		if (L_30 == 7)
		{
			goto IL_0366;
		}
		if (L_30 == 8)
		{
			goto IL_0391;
		}
		if (L_30 == 9)
		{
			goto IL_03ab;
		}
		if (L_30 == 10)
		{
			goto IL_03f0;
		}
		if (L_30 == 11)
		{
			goto IL_0435;
		}
		if (L_30 == 12)
		{
			goto IL_044f;
		}
		if (L_30 == 13)
		{
			goto IL_0471;
		}
		if (L_30 == 14)
		{
			goto IL_0493;
		}
		if (L_30 == 15)
		{
			goto IL_04b4;
		}
		if (L_30 == 16)
		{
			goto IL_04ce;
		}
		if (L_30 == 17)
		{
			goto IL_04e8;
		}
	}
	{
		goto IL_0512;
	}

IL_0186:
	{
		String_t* L_31 = ___name0;
		StringU5BU5D_t1642385972* L_32 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_32, _stringLiteral1804801784);
		(L_32)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1804801784);
		ConfigHandler_ValidatePath_m3188987489(__this, L_31, L_32, /*hidden argument*/NULL);
		Il2CppObject * L_33 = ___attrs1;
		StringU5BU5D_t1642385972* L_34 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_33);
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_34)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_01b7;
		}
	}
	{
		Il2CppObject * L_35 = ___attrs1;
		StringU5BU5D_t1642385972* L_36 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(5 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Values() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_35);
		int32_t L_37 = 0;
		String_t* L_38 = (L_36)->GetAt(static_cast<il2cpp_array_size_t>(L_37));
		__this->set_appName_5(L_38);
	}

IL_01b7:
	{
		goto IL_0528;
	}

IL_01bc:
	{
		String_t* L_39 = ___name0;
		StringU5BU5D_t1642385972* L_40 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_40, _stringLiteral3130431008);
		(L_40)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3130431008);
		ConfigHandler_ValidatePath_m3188987489(__this, L_39, L_40, /*hidden argument*/NULL);
		Il2CppObject * L_41 = ___attrs1;
		ConfigHandler_ReadLifetine_m4190202502(__this, L_41, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_01dd:
	{
		String_t* L_42 = ___name0;
		StringU5BU5D_t1642385972* L_43 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_43, _stringLiteral1804801784);
		(L_43)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1804801784);
		StringU5BU5D_t1642385972* L_44 = L_43;
		ArrayElementTypeCheck (L_44, _stringLiteral3130431008);
		(L_44)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3130431008);
		ConfigHandler_ValidatePath_m3188987489(__this, L_42, L_44, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_01ff:
	{
		String_t* L_45 = ___name0;
		StringU5BU5D_t1642385972* L_46 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_46, _stringLiteral825743886);
		(L_46)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral825743886);
		ConfigHandler_ValidatePath_m3188987489(__this, L_45, L_46, /*hidden argument*/NULL);
		String_t* L_47 = __this->get_currentXmlPath_6();
		int32_t L_48 = String_IndexOf_m4251815737(L_47, _stringLiteral3130431008, /*hidden argument*/NULL);
		if ((((int32_t)L_48) == ((int32_t)(-1))))
		{
			goto IL_0237;
		}
	}
	{
		Il2CppObject * L_49 = ___attrs1;
		ConfigHandler_ReadChannel_m90614780(__this, L_49, (bool)0, /*hidden argument*/NULL);
		goto IL_023f;
	}

IL_0237:
	{
		Il2CppObject * L_50 = ___attrs1;
		ConfigHandler_ReadChannel_m90614780(__this, L_50, (bool)1, /*hidden argument*/NULL);
	}

IL_023f:
	{
		goto IL_0528;
	}

IL_0244:
	{
		String_t* L_51 = ___name0;
		StringU5BU5D_t1642385972* L_52 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_52, _stringLiteral2787760668);
		(L_52)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2787760668);
		StringU5BU5D_t1642385972* L_53 = L_52;
		ArrayElementTypeCheck (L_53, _stringLiteral3637194755);
		(L_53)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3637194755);
		ConfigHandler_ValidatePath_m3188987489(__this, L_51, L_53, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_0266:
	{
		String_t* L_54 = ___name0;
		StringU5BU5D_t1642385972* L_55 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_55, _stringLiteral2787760668);
		(L_55)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2787760668);
		StringU5BU5D_t1642385972* L_56 = L_55;
		ArrayElementTypeCheck (L_56, _stringLiteral3637194755);
		(L_56)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3637194755);
		ConfigHandler_ValidatePath_m3188987489(__this, L_54, L_56, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_0288:
	{
		bool L_57 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral2632115629, /*hidden argument*/NULL);
		if (L_57)
		{
			goto IL_02a8;
		}
	}
	{
		bool L_58 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral1878791818, /*hidden argument*/NULL);
		if (!L_58)
		{
			goto IL_02c9;
		}
	}

IL_02a8:
	{
		String_t* L_59 = ___name0;
		Il2CppObject * L_60 = ___attrs1;
		ProviderData_t2518653487 * L_61 = ConfigHandler_ReadProvider_m1441445958(__this, L_59, L_60, (bool)0, /*hidden argument*/NULL);
		V_0 = L_61;
		ChannelData_t1489610737 * L_62 = __this->get_currentChannel_2();
		ArrayList_t4252133567 * L_63 = ChannelData_get_ServerProviders_m237896543(L_62, /*hidden argument*/NULL);
		ProviderData_t2518653487 * L_64 = V_0;
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_63, L_64);
		goto IL_0361;
	}

IL_02c9:
	{
		bool L_65 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral3950396857, /*hidden argument*/NULL);
		if (L_65)
		{
			goto IL_02e9;
		}
	}
	{
		bool L_66 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral564554174, /*hidden argument*/NULL);
		if (!L_66)
		{
			goto IL_030a;
		}
	}

IL_02e9:
	{
		String_t* L_67 = ___name0;
		Il2CppObject * L_68 = ___attrs1;
		ProviderData_t2518653487 * L_69 = ConfigHandler_ReadProvider_m1441445958(__this, L_67, L_68, (bool)0, /*hidden argument*/NULL);
		V_0 = L_69;
		ChannelData_t1489610737 * L_70 = __this->get_currentChannel_2();
		ArrayList_t4252133567 * L_71 = ChannelData_get_ClientProviders_m648877347(L_70, /*hidden argument*/NULL);
		ProviderData_t2518653487 * L_72 = V_0;
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_71, L_72);
		goto IL_0361;
	}

IL_030a:
	{
		bool L_73 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral2317236068, /*hidden argument*/NULL);
		if (!L_73)
		{
			goto IL_032f;
		}
	}
	{
		String_t* L_74 = ___name0;
		Il2CppObject * L_75 = ___attrs1;
		ProviderData_t2518653487 * L_76 = ConfigHandler_ReadProvider_m1441445958(__this, L_74, L_75, (bool)1, /*hidden argument*/NULL);
		V_0 = L_76;
		ProviderData_t2518653487 * L_77 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_RegisterServerProviderTemplate_m2851537389(NULL /*static, unused*/, L_77, /*hidden argument*/NULL);
		goto IL_0361;
	}

IL_032f:
	{
		bool L_78 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral27726768, /*hidden argument*/NULL);
		if (!L_78)
		{
			goto IL_0354;
		}
	}
	{
		String_t* L_79 = ___name0;
		Il2CppObject * L_80 = ___attrs1;
		ProviderData_t2518653487 * L_81 = ConfigHandler_ReadProvider_m1441445958(__this, L_79, L_80, (bool)1, /*hidden argument*/NULL);
		V_0 = L_81;
		ProviderData_t2518653487 * L_82 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_RegisterClientProviderTemplate_m514821425(NULL /*static, unused*/, L_82, /*hidden argument*/NULL);
		goto IL_0361;
	}

IL_0354:
	{
		String_t* L_83 = ___name0;
		ConfigHandler_ValidatePath_m3188987489(__this, L_83, ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)0)), /*hidden argument*/NULL);
	}

IL_0361:
	{
		goto IL_0528;
	}

IL_0366:
	{
		String_t* L_84 = ___name0;
		StringU5BU5D_t1642385972* L_85 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_85, _stringLiteral3130431008);
		(L_85)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3130431008);
		ConfigHandler_ValidatePath_m3188987489(__this, L_84, L_85, /*hidden argument*/NULL);
		Il2CppObject * L_86 = ___attrs1;
		String_t* L_87 = InterfaceFuncInvoker1< String_t*, String_t* >::Invoke(3 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.String) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_86, _stringLiteral386853519);
		__this->set_currentClientUrl_4(L_87);
		goto IL_0528;
	}

IL_0391:
	{
		String_t* L_88 = ___name0;
		StringU5BU5D_t1642385972* L_89 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_89, _stringLiteral3130431008);
		(L_89)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3130431008);
		ConfigHandler_ValidatePath_m3188987489(__this, L_88, L_89, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_03ab:
	{
		String_t* L_90 = ___name0;
		StringU5BU5D_t1642385972* L_91 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_91, _stringLiteral3374638073);
		(L_91)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3374638073);
		StringU5BU5D_t1642385972* L_92 = L_91;
		ArrayElementTypeCheck (L_92, _stringLiteral1905906193);
		(L_92)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral1905906193);
		ConfigHandler_ValidatePath_m3188987489(__this, L_90, L_92, /*hidden argument*/NULL);
		bool L_93 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral3374638073, /*hidden argument*/NULL);
		if (!L_93)
		{
			goto IL_03e4;
		}
	}
	{
		Il2CppObject * L_94 = ___attrs1;
		ConfigHandler_ReadClientWellKnown_m4206953534(__this, L_94, /*hidden argument*/NULL);
		goto IL_03eb;
	}

IL_03e4:
	{
		Il2CppObject * L_95 = ___attrs1;
		ConfigHandler_ReadServiceWellKnown_m1495748104(__this, L_95, /*hidden argument*/NULL);
	}

IL_03eb:
	{
		goto IL_0528;
	}

IL_03f0:
	{
		String_t* L_96 = ___name0;
		StringU5BU5D_t1642385972* L_97 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)2));
		ArrayElementTypeCheck (L_97, _stringLiteral3374638073);
		(L_97)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3374638073);
		StringU5BU5D_t1642385972* L_98 = L_97;
		ArrayElementTypeCheck (L_98, _stringLiteral1905906193);
		(L_98)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral1905906193);
		ConfigHandler_ValidatePath_m3188987489(__this, L_96, L_98, /*hidden argument*/NULL);
		bool L_99 = ConfigHandler_CheckPath_m2296459741(__this, _stringLiteral3374638073, /*hidden argument*/NULL);
		if (!L_99)
		{
			goto IL_0429;
		}
	}
	{
		Il2CppObject * L_100 = ___attrs1;
		ConfigHandler_ReadClientActivated_m225401690(__this, L_100, /*hidden argument*/NULL);
		goto IL_0430;
	}

IL_0429:
	{
		Il2CppObject * L_101 = ___attrs1;
		ConfigHandler_ReadServiceActivated_m907987684(__this, L_101, /*hidden argument*/NULL);
	}

IL_0430:
	{
		goto IL_0528;
	}

IL_0435:
	{
		String_t* L_102 = ___name0;
		StringU5BU5D_t1642385972* L_103 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_103, _stringLiteral3130431008);
		(L_103)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral3130431008);
		ConfigHandler_ValidatePath_m3188987489(__this, L_102, L_103, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_044f:
	{
		String_t* L_104 = ___name0;
		StringU5BU5D_t1642385972* L_105 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_105, _stringLiteral2652186846);
		(L_105)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2652186846);
		ConfigHandler_ValidatePath_m3188987489(__this, L_104, L_105, /*hidden argument*/NULL);
		Il2CppObject * L_106 = ___attrs1;
		ConfigHandler_ReadInteropXml_m539906871(__this, L_106, (bool)0, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_0471:
	{
		String_t* L_107 = ___name0;
		StringU5BU5D_t1642385972* L_108 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_108, _stringLiteral2652186846);
		(L_108)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2652186846);
		ConfigHandler_ValidatePath_m3188987489(__this, L_107, L_108, /*hidden argument*/NULL);
		Il2CppObject * L_109 = ___attrs1;
		ConfigHandler_ReadInteropXml_m539906871(__this, L_109, (bool)0, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_0493:
	{
		String_t* L_110 = ___name0;
		StringU5BU5D_t1642385972* L_111 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_111, _stringLiteral2652186846);
		(L_111)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2652186846);
		ConfigHandler_ValidatePath_m3188987489(__this, L_110, L_111, /*hidden argument*/NULL);
		Il2CppObject * L_112 = ___attrs1;
		ConfigHandler_ReadPreload_m455851711(__this, L_112, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_04b4:
	{
		String_t* L_113 = ___name0;
		StringU5BU5D_t1642385972* L_114 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_114, _stringLiteral1804801784);
		(L_114)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1804801784);
		ConfigHandler_ValidatePath_m3188987489(__this, L_113, L_114, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_04ce:
	{
		String_t* L_115 = ___name0;
		StringU5BU5D_t1642385972* L_116 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_116, _stringLiteral1804801784);
		(L_116)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1804801784);
		ConfigHandler_ValidatePath_m3188987489(__this, L_115, L_116, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_04e8:
	{
		String_t* L_117 = ___name0;
		StringU5BU5D_t1642385972* L_118 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_118, _stringLiteral1804801784);
		(L_118)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1804801784);
		ConfigHandler_ValidatePath_m3188987489(__this, L_117, L_118, /*hidden argument*/NULL);
		Il2CppObject * L_119 = ___attrs1;
		String_t* L_120 = InterfaceFuncInvoker1< String_t*, String_t* >::Invoke(3 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.String) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_119, _stringLiteral1414244983);
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_SetCustomErrorsMode_m1844153208(NULL /*static, unused*/, L_120, /*hidden argument*/NULL);
		goto IL_0528;
	}

IL_0512:
	{
		String_t* L_121 = ___name0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_122 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral4067733765, L_121, _stringLiteral1983445210, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_123 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_123, L_122, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_123);
	}

IL_0528:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnEndElement(System.String)
extern "C"  void ConfigHandler_OnEndElement_m3200644118 (ConfigHandler_t2180714860 * __this, String_t* ___name0, const MethodInfo* method)
{
	{
		Stack_t1043988394 * L_0 = __this->get_currentProviderData_3();
		if (!L_0)
		{
			goto IL_002e;
		}
	}
	{
		Stack_t1043988394 * L_1 = __this->get_currentProviderData_3();
		VirtFuncInvoker0< Il2CppObject * >::Invoke(18 /* System.Object System.Collections.Stack::Pop() */, L_1);
		Stack_t1043988394 * L_2 = __this->get_currentProviderData_3();
		int32_t L_3 = VirtFuncInvoker0< int32_t >::Invoke(10 /* System.Int32 System.Collections.Stack::get_Count() */, L_2);
		if (L_3)
		{
			goto IL_002e;
		}
	}
	{
		__this->set_currentProviderData_3((Stack_t1043988394 *)NULL);
	}

IL_002e:
	{
		String_t* L_4 = __this->get_currentXmlPath_6();
		String_t* L_5 = __this->get_currentXmlPath_6();
		int32_t L_6 = String_get_Length_m1606060069(L_5, /*hidden argument*/NULL);
		String_t* L_7 = ___name0;
		int32_t L_8 = String_get_Length_m1606060069(L_7, /*hidden argument*/NULL);
		String_t* L_9 = String_Substring_m12482732(L_4, 0, ((int32_t)((int32_t)((int32_t)((int32_t)L_6-(int32_t)L_8))-(int32_t)1)), /*hidden argument*/NULL);
		__this->set_currentXmlPath_6(L_9);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadCustomProviderData(System.String,Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* SinkProviderData_t2645445792_il2cpp_TypeInfo_var;
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_t3321498491_il2cpp_TypeInfo_var;
extern const uint32_t ConfigHandler_ReadCustomProviderData_m784203316_MetadataUsageId;
extern "C"  void ConfigHandler_ReadCustomProviderData_m784203316 (ConfigHandler_t2180714860 * __this, String_t* ___name0, Il2CppObject * ___attrs1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadCustomProviderData_m784203316_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SinkProviderData_t2645445792 * V_0 = NULL;
	SinkProviderData_t2645445792 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		Stack_t1043988394 * L_0 = __this->get_currentProviderData_3();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(17 /* System.Object System.Collections.Stack::Peek() */, L_0);
		V_0 = ((SinkProviderData_t2645445792 *)CastclassClass(L_1, SinkProviderData_t2645445792_il2cpp_TypeInfo_var));
		String_t* L_2 = ___name0;
		SinkProviderData_t2645445792 * L_3 = (SinkProviderData_t2645445792 *)il2cpp_codegen_object_new(SinkProviderData_t2645445792_il2cpp_TypeInfo_var);
		SinkProviderData__ctor_m1828480392(L_3, L_2, /*hidden argument*/NULL);
		V_1 = L_3;
		V_2 = 0;
		goto IL_003d;
	}

IL_001f:
	{
		SinkProviderData_t2645445792 * L_4 = V_1;
		Il2CppObject * L_5 = SinkProviderData_get_Properties_m536484876(L_4, /*hidden argument*/NULL);
		Il2CppObject * L_6 = ___attrs1;
		StringU5BU5D_t1642385972* L_7 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_6);
		int32_t L_8 = V_2;
		int32_t L_9 = L_8;
		String_t* L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		Il2CppObject * L_11 = ___attrs1;
		int32_t L_12 = V_2;
		String_t* L_13 = InterfaceFuncInvoker1< String_t*, int32_t >::Invoke(2 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.Int32) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_11, L_12);
		InterfaceActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(1 /* System.Void System.Collections.IDictionary::set_Item(System.Object,System.Object) */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_5, L_10, L_13);
		int32_t L_14 = V_2;
		V_2 = ((int32_t)((int32_t)L_14+(int32_t)1));
	}

IL_003d:
	{
		int32_t L_15 = V_2;
		Il2CppObject * L_16 = ___attrs1;
		StringU5BU5D_t1642385972* L_17 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_16);
		if ((((int32_t)L_15) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_17)->max_length)))))))
		{
			goto IL_001f;
		}
	}
	{
		SinkProviderData_t2645445792 * L_18 = V_0;
		Il2CppObject * L_19 = SinkProviderData_get_Children_m100594762(L_18, /*hidden argument*/NULL);
		SinkProviderData_t2645445792 * L_20 = V_1;
		InterfaceFuncInvoker1< int32_t, Il2CppObject * >::Invoke(4 /* System.Int32 System.Collections.IList::Add(System.Object) */, IList_t3321498491_il2cpp_TypeInfo_var, L_19, L_20);
		Stack_t1043988394 * L_21 = __this->get_currentProviderData_3();
		SinkProviderData_t2645445792 * L_22 = V_1;
		VirtActionInvoker1< Il2CppObject * >::Invoke(19 /* System.Void System.Collections.Stack::Push(System.Object) */, L_21, L_22);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadLifetine(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* ConfigHandler_t2180714860_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral190416435;
extern Il2CppCodeGenString* _stringLiteral2660804213;
extern Il2CppCodeGenString* _stringLiteral1404422989;
extern Il2CppCodeGenString* _stringLiteral2887540223;
extern Il2CppCodeGenString* _stringLiteral2442108587;
extern const uint32_t ConfigHandler_ReadLifetine_m4190202502_MetadataUsageId;
extern "C"  void ConfigHandler_ReadLifetine_m4190202502 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadLifetine_m4190202502_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	String_t* V_1 = NULL;
	Dictionary_2_t3986656710 * V_2 = NULL;
	int32_t V_3 = 0;
	{
		V_0 = 0;
		goto IL_0102;
	}

IL_0007:
	{
		Il2CppObject * L_0 = ___attrs0;
		StringU5BU5D_t1642385972* L_1 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_0);
		int32_t L_2 = V_0;
		int32_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		V_1 = L_4;
		String_t* L_5 = V_1;
		if (!L_5)
		{
			goto IL_00e6;
		}
	}
	{
		Dictionary_2_t3986656710 * L_6 = ((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map28_9();
		if (L_6)
		{
			goto IL_005d;
		}
	}
	{
		Dictionary_2_t3986656710 * L_7 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_7, 4, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_2 = L_7;
		Dictionary_2_t3986656710 * L_8 = V_2;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral190416435, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_2;
		Dictionary_2_Add_m1209957957(L_9, _stringLiteral2660804213, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_10 = V_2;
		Dictionary_2_Add_m1209957957(L_10, _stringLiteral1404422989, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_11 = V_2;
		Dictionary_2_Add_m1209957957(L_11, _stringLiteral2887540223, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_12 = V_2;
		((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map28_9(L_12);
	}

IL_005d:
	{
		Dictionary_2_t3986656710 * L_13 = ((ConfigHandler_t2180714860_StaticFields*)ConfigHandler_t2180714860_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map28_9();
		String_t* L_14 = V_1;
		bool L_15 = Dictionary_2_TryGetValue_m2977303364(L_13, L_14, (&V_3), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_15)
		{
			goto IL_00e6;
		}
	}
	{
		int32_t L_16 = V_3;
		if (L_16 == 0)
		{
			goto IL_008a;
		}
		if (L_16 == 1)
		{
			goto IL_00a1;
		}
		if (L_16 == 2)
		{
			goto IL_00b8;
		}
		if (L_16 == 3)
		{
			goto IL_00cf;
		}
	}
	{
		goto IL_00e6;
	}

IL_008a:
	{
		Il2CppObject * L_17 = ___attrs0;
		int32_t L_18 = V_0;
		String_t* L_19 = InterfaceFuncInvoker1< String_t*, int32_t >::Invoke(2 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.Int32) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_17, L_18);
		TimeSpan_t3430258949  L_20 = ConfigHandler_ParseTime_m1231083163(__this, L_19, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		LifetimeServices_set_LeaseTime_m1487876644(NULL /*static, unused*/, L_20, /*hidden argument*/NULL);
		goto IL_00fe;
	}

IL_00a1:
	{
		Il2CppObject * L_21 = ___attrs0;
		int32_t L_22 = V_0;
		String_t* L_23 = InterfaceFuncInvoker1< String_t*, int32_t >::Invoke(2 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.Int32) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_21, L_22);
		TimeSpan_t3430258949  L_24 = ConfigHandler_ParseTime_m1231083163(__this, L_23, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		LifetimeServices_set_SponsorshipTimeout_m1403222216(NULL /*static, unused*/, L_24, /*hidden argument*/NULL);
		goto IL_00fe;
	}

IL_00b8:
	{
		Il2CppObject * L_25 = ___attrs0;
		int32_t L_26 = V_0;
		String_t* L_27 = InterfaceFuncInvoker1< String_t*, int32_t >::Invoke(2 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.Int32) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_25, L_26);
		TimeSpan_t3430258949  L_28 = ConfigHandler_ParseTime_m1231083163(__this, L_27, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		LifetimeServices_set_RenewOnCallTime_m3507481746(NULL /*static, unused*/, L_28, /*hidden argument*/NULL);
		goto IL_00fe;
	}

IL_00cf:
	{
		Il2CppObject * L_29 = ___attrs0;
		int32_t L_30 = V_0;
		String_t* L_31 = InterfaceFuncInvoker1< String_t*, int32_t >::Invoke(2 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.Int32) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_29, L_30);
		TimeSpan_t3430258949  L_32 = ConfigHandler_ParseTime_m1231083163(__this, L_31, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		LifetimeServices_set_LeaseManagerPollTime_m3919998154(NULL /*static, unused*/, L_32, /*hidden argument*/NULL);
		goto IL_00fe;
	}

IL_00e6:
	{
		Il2CppObject * L_33 = ___attrs0;
		StringU5BU5D_t1642385972* L_34 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_33);
		int32_t L_35 = V_0;
		int32_t L_36 = L_35;
		String_t* L_37 = (L_34)->GetAt(static_cast<il2cpp_array_size_t>(L_36));
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_38 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral2442108587, L_37, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_39 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_39, L_38, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_39);
	}

IL_00fe:
	{
		int32_t L_40 = V_0;
		V_0 = ((int32_t)((int32_t)L_40+(int32_t)1));
	}

IL_0102:
	{
		int32_t L_41 = V_0;
		Il2CppObject * L_42 = ___attrs0;
		StringU5BU5D_t1642385972* L_43 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_42);
		if ((((int32_t)L_41) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_43)->max_length)))))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.TimeSpan System.Runtime.Remoting.ConfigHandler::ParseTime(System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* CharU5BU5D_t1328083999_il2cpp_TypeInfo_var;
extern Il2CppClass* Il2CppObject_il2cpp_TypeInfo_var;
extern Il2CppClass* TimeSpan_t3430258949_il2cpp_TypeInfo_var;
extern FieldInfo* U3CPrivateImplementationDetailsU3E_t1486305137____U24U24fieldU2D31_21_FieldInfo_var;
extern Il2CppCodeGenString* _stringLiteral1738070351;
extern Il2CppCodeGenString* _stringLiteral372029423;
extern Il2CppCodeGenString* _stringLiteral96825301;
extern Il2CppCodeGenString* _stringLiteral372029402;
extern Il2CppCodeGenString* _stringLiteral372029414;
extern Il2CppCodeGenString* _stringLiteral372029409;
extern Il2CppCodeGenString* _stringLiteral1685131766;
extern Il2CppCodeGenString* _stringLiteral2615517886;
extern const uint32_t ConfigHandler_ParseTime_m1231083163_MetadataUsageId;
extern "C"  TimeSpan_t3430258949  ConfigHandler_ParseTime_m1231083163 (ConfigHandler_t2180714860 * __this, String_t* ___s0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ParseTime_m1231083163_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	String_t* V_1 = NULL;
	double V_2 = 0.0;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		String_t* L_0 = ___s0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_1 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		bool L_2 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		if (L_2)
		{
			goto IL_0016;
		}
	}
	{
		String_t* L_3 = ___s0;
		if (L_3)
		{
			goto IL_0021;
		}
	}

IL_0016:
	{
		RemotingException_t109604560 * L_4 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_4, _stringLiteral1738070351, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
	}

IL_0021:
	{
		String_t* L_5 = ___s0;
		CharU5BU5D_t1328083999* L_6 = ((CharU5BU5D_t1328083999*)SZArrayNew(CharU5BU5D_t1328083999_il2cpp_TypeInfo_var, (uint32_t)4));
		RuntimeHelpers_InitializeArray_m3920580167(NULL /*static, unused*/, (Il2CppArray *)(Il2CppArray *)L_6, LoadFieldToken(U3CPrivateImplementationDetailsU3E_t1486305137____U24U24fieldU2D31_21_FieldInfo_var), /*hidden argument*/NULL);
		int32_t L_7 = String_IndexOfAny_m2016554902(L_5, L_6, /*hidden argument*/NULL);
		V_0 = L_7;
		int32_t L_8 = V_0;
		if ((!(((uint32_t)L_8) == ((uint32_t)(-1)))))
		{
			goto IL_004b;
		}
	}
	{
		V_1 = _stringLiteral372029423;
		goto IL_005d;
	}

IL_004b:
	{
		String_t* L_9 = ___s0;
		int32_t L_10 = V_0;
		String_t* L_11 = String_Substring_m2032624251(L_9, L_10, /*hidden argument*/NULL);
		V_1 = L_11;
		String_t* L_12 = ___s0;
		int32_t L_13 = V_0;
		String_t* L_14 = String_Substring_m12482732(L_12, 0, L_13, /*hidden argument*/NULL);
		___s0 = L_14;
	}

IL_005d:
	try
	{ // begin try (depth: 1)
		String_t* L_15 = ___s0;
		double L_16 = Double_Parse_m1560474910(NULL /*static, unused*/, L_15, /*hidden argument*/NULL);
		V_2 = L_16;
		goto IL_0080;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Il2CppObject_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0069;
		throw e;
	}

CATCH_0069:
	{ // begin catch(System.Object)
		{
			String_t* L_17 = ___s0;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_18 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral96825301, L_17, /*hidden argument*/NULL);
			RemotingException_t109604560 * L_19 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3568495070(L_19, L_18, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_19);
		}

IL_007b:
		{
			goto IL_0080;
		}
	} // end catch (depth: 1)

IL_0080:
	{
		String_t* L_20 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_21 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_20, _stringLiteral372029402, /*hidden argument*/NULL);
		if (!L_21)
		{
			goto IL_0097;
		}
	}
	{
		double L_22 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_23 = TimeSpan_FromDays_m2859053398(NULL /*static, unused*/, L_22, /*hidden argument*/NULL);
		return L_23;
	}

IL_0097:
	{
		String_t* L_24 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_25 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_24, _stringLiteral372029414, /*hidden argument*/NULL);
		if (!L_25)
		{
			goto IL_00ae;
		}
	}
	{
		double L_26 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_27 = TimeSpan_FromHours_m2521548378(NULL /*static, unused*/, L_26, /*hidden argument*/NULL);
		return L_27;
	}

IL_00ae:
	{
		String_t* L_28 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_29 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_28, _stringLiteral372029409, /*hidden argument*/NULL);
		if (!L_29)
		{
			goto IL_00c5;
		}
	}
	{
		double L_30 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_31 = TimeSpan_FromMinutes_m1997633268(NULL /*static, unused*/, L_30, /*hidden argument*/NULL);
		return L_31;
	}

IL_00c5:
	{
		String_t* L_32 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_33 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_32, _stringLiteral372029423, /*hidden argument*/NULL);
		if (!L_33)
		{
			goto IL_00dc;
		}
	}
	{
		double L_34 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_35 = TimeSpan_FromSeconds_m2861206200(NULL /*static, unused*/, L_34, /*hidden argument*/NULL);
		return L_35;
	}

IL_00dc:
	{
		String_t* L_36 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_37 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_36, _stringLiteral1685131766, /*hidden argument*/NULL);
		if (!L_37)
		{
			goto IL_00f3;
		}
	}
	{
		double L_38 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_39 = TimeSpan_FromMilliseconds_m664523225(NULL /*static, unused*/, L_38, /*hidden argument*/NULL);
		return L_39;
	}

IL_00f3:
	{
		String_t* L_40 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_41 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral2615517886, L_40, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_42 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_42, L_41, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_42);
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadChannel(Mono.Xml.SmallXmlParser/IAttrList,System.Boolean)
extern Il2CppClass* ChannelData_t1489610737_il2cpp_TypeInfo_var;
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3021628817;
extern Il2CppCodeGenString* _stringLiteral1160351167;
extern Il2CppCodeGenString* _stringLiteral287061489;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern Il2CppCodeGenString* _stringLiteral2035507306;
extern const uint32_t ConfigHandler_ReadChannel_m90614780_MetadataUsageId;
extern "C"  void ConfigHandler_ReadChannel_m90614780 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, bool ___isTemplate1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadChannel_m90614780_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ChannelData_t1489610737 * V_0 = NULL;
	int32_t V_1 = 0;
	String_t* V_2 = NULL;
	String_t* V_3 = NULL;
	{
		ChannelData_t1489610737 * L_0 = (ChannelData_t1489610737 *)il2cpp_codegen_object_new(ChannelData_t1489610737_il2cpp_TypeInfo_var);
		ChannelData__ctor_m2081039517(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		V_1 = 0;
		goto IL_00ac;
	}

IL_000d:
	{
		Il2CppObject * L_1 = ___attrs0;
		StringU5BU5D_t1642385972* L_2 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_1);
		int32_t L_3 = V_1;
		int32_t L_4 = L_3;
		String_t* L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_2 = L_5;
		Il2CppObject * L_6 = ___attrs0;
		StringU5BU5D_t1642385972* L_7 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(5 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Values() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_6);
		int32_t L_8 = V_1;
		int32_t L_9 = L_8;
		String_t* L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		V_3 = L_10;
		String_t* L_11 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_12 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_11, _stringLiteral3021628817, /*hidden argument*/NULL);
		if (!L_12)
		{
			goto IL_0041;
		}
	}
	{
		bool L_13 = ___isTemplate1;
		if (L_13)
		{
			goto IL_0041;
		}
	}
	{
		ChannelData_t1489610737 * L_14 = V_0;
		String_t* L_15 = V_3;
		L_14->set_Ref_0(L_15);
		goto IL_00a8;
	}

IL_0041:
	{
		String_t* L_16 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_17 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_16, _stringLiteral1160351167, /*hidden argument*/NULL);
		if (!L_17)
		{
			goto IL_005d;
		}
	}
	{
		ChannelData_t1489610737 * L_18 = V_0;
		String_t* L_19 = V_3;
		L_18->set_DelayLoadAsClientChannel_3(L_19);
		goto IL_00a8;
	}

IL_005d:
	{
		String_t* L_20 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_21 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_20, _stringLiteral287061489, /*hidden argument*/NULL);
		if (!L_21)
		{
			goto IL_007f;
		}
	}
	{
		bool L_22 = ___isTemplate1;
		if (!L_22)
		{
			goto IL_007f;
		}
	}
	{
		ChannelData_t1489610737 * L_23 = V_0;
		String_t* L_24 = V_3;
		L_23->set_Id_2(L_24);
		goto IL_00a8;
	}

IL_007f:
	{
		String_t* L_25 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_26 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_25, _stringLiteral1421151742, /*hidden argument*/NULL);
		if (!L_26)
		{
			goto IL_009b;
		}
	}
	{
		ChannelData_t1489610737 * L_27 = V_0;
		String_t* L_28 = V_3;
		L_27->set_Type_1(L_28);
		goto IL_00a8;
	}

IL_009b:
	{
		ChannelData_t1489610737 * L_29 = V_0;
		Hashtable_t909839986 * L_30 = ChannelData_get_CustomProperties_m1470957369(L_29, /*hidden argument*/NULL);
		String_t* L_31 = V_2;
		String_t* L_32 = V_3;
		VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(25 /* System.Void System.Collections.Hashtable::Add(System.Object,System.Object) */, L_30, L_31, L_32);
	}

IL_00a8:
	{
		int32_t L_33 = V_1;
		V_1 = ((int32_t)((int32_t)L_33+(int32_t)1));
	}

IL_00ac:
	{
		int32_t L_34 = V_1;
		Il2CppObject * L_35 = ___attrs0;
		StringU5BU5D_t1642385972* L_36 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_35);
		if ((((int32_t)L_34) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_36)->max_length)))))))
		{
			goto IL_000d;
		}
	}
	{
		bool L_37 = ___isTemplate1;
		if (!L_37)
		{
			goto IL_00f7;
		}
	}
	{
		ChannelData_t1489610737 * L_38 = V_0;
		String_t* L_39 = L_38->get_Id_2();
		if (L_39)
		{
			goto IL_00d6;
		}
	}
	{
		RemotingException_t109604560 * L_40 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_40, _stringLiteral2035507306, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_40);
	}

IL_00d6:
	{
		ChannelData_t1489610737 * L_41 = V_0;
		String_t* L_42 = L_41->get_Type_1();
		if (L_42)
		{
			goto IL_00ec;
		}
	}
	{
		RemotingException_t109604560 * L_43 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_43, _stringLiteral2035507306, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_43);
	}

IL_00ec:
	{
		ChannelData_t1489610737 * L_44 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_RegisterChannelTemplate_m3410954518(NULL /*static, unused*/, L_44, /*hidden argument*/NULL);
		goto IL_0104;
	}

IL_00f7:
	{
		ArrayList_t4252133567 * L_45 = __this->get_channelInstances_1();
		ChannelData_t1489610737 * L_46 = V_0;
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_45, L_46);
	}

IL_0104:
	{
		ChannelData_t1489610737 * L_47 = V_0;
		__this->set_currentChannel_2(L_47);
		return;
	}
}
// System.Runtime.Remoting.ProviderData System.Runtime.Remoting.ConfigHandler::ReadProvider(System.String,Mono.Xml.SmallXmlParser/IAttrList,System.Boolean)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ProviderData_t2518653487_il2cpp_TypeInfo_var;
extern Il2CppClass* FormatterData_t12176916_il2cpp_TypeInfo_var;
extern Il2CppClass* SinkProviderData_t2645445792_il2cpp_TypeInfo_var;
extern Il2CppClass* Stack_t1043988394_il2cpp_TypeInfo_var;
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1681167945;
extern Il2CppCodeGenString* _stringLiteral3430668174;
extern Il2CppCodeGenString* _stringLiteral287061489;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern Il2CppCodeGenString* _stringLiteral3021628817;
extern Il2CppCodeGenString* _stringLiteral2035507306;
extern const uint32_t ConfigHandler_ReadProvider_m1441445958_MetadataUsageId;
extern "C"  ProviderData_t2518653487 * ConfigHandler_ReadProvider_m1441445958 (ConfigHandler_t2180714860 * __this, String_t* ___name0, Il2CppObject * ___attrs1, bool ___isTemplate2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadProvider_m1441445958_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ProviderData_t2518653487 * V_0 = NULL;
	SinkProviderData_t2645445792 * V_1 = NULL;
	int32_t V_2 = 0;
	String_t* V_3 = NULL;
	String_t* V_4 = NULL;
	ProviderData_t2518653487 * G_B3_0 = NULL;
	{
		String_t* L_0 = ___name0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_1 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_0, _stringLiteral1681167945, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_001a;
		}
	}
	{
		ProviderData_t2518653487 * L_2 = (ProviderData_t2518653487 *)il2cpp_codegen_object_new(ProviderData_t2518653487_il2cpp_TypeInfo_var);
		ProviderData__ctor_m1260387831(L_2, /*hidden argument*/NULL);
		G_B3_0 = L_2;
		goto IL_001f;
	}

IL_001a:
	{
		FormatterData_t12176916 * L_3 = (FormatterData_t12176916 *)il2cpp_codegen_object_new(FormatterData_t12176916_il2cpp_TypeInfo_var);
		FormatterData__ctor_m3974986124(L_3, /*hidden argument*/NULL);
		G_B3_0 = ((ProviderData_t2518653487 *)(L_3));
	}

IL_001f:
	{
		V_0 = G_B3_0;
		SinkProviderData_t2645445792 * L_4 = (SinkProviderData_t2645445792 *)il2cpp_codegen_object_new(SinkProviderData_t2645445792_il2cpp_TypeInfo_var);
		SinkProviderData__ctor_m1828480392(L_4, _stringLiteral3430668174, /*hidden argument*/NULL);
		V_1 = L_4;
		ProviderData_t2518653487 * L_5 = V_0;
		SinkProviderData_t2645445792 * L_6 = V_1;
		Il2CppObject * L_7 = SinkProviderData_get_Children_m100594762(L_6, /*hidden argument*/NULL);
		L_5->set_CustomData_4(L_7);
		Stack_t1043988394 * L_8 = (Stack_t1043988394 *)il2cpp_codegen_object_new(Stack_t1043988394_il2cpp_TypeInfo_var);
		Stack__ctor_m521896492(L_8, /*hidden argument*/NULL);
		__this->set_currentProviderData_3(L_8);
		Stack_t1043988394 * L_9 = __this->get_currentProviderData_3();
		SinkProviderData_t2645445792 * L_10 = V_1;
		VirtActionInvoker1< Il2CppObject * >::Invoke(19 /* System.Void System.Collections.Stack::Push(System.Object) */, L_9, L_10);
		V_2 = 0;
		goto IL_00dd;
	}

IL_0055:
	{
		Il2CppObject * L_11 = ___attrs1;
		StringU5BU5D_t1642385972* L_12 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_11);
		int32_t L_13 = V_2;
		int32_t L_14 = L_13;
		String_t* L_15 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
		V_3 = L_15;
		Il2CppObject * L_16 = ___attrs1;
		StringU5BU5D_t1642385972* L_17 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(5 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Values() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_16);
		int32_t L_18 = V_2;
		int32_t L_19 = L_18;
		String_t* L_20 = (L_17)->GetAt(static_cast<il2cpp_array_size_t>(L_19));
		V_4 = L_20;
		String_t* L_21 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_22 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_21, _stringLiteral287061489, /*hidden argument*/NULL);
		if (!L_22)
		{
			goto IL_008b;
		}
	}
	{
		bool L_23 = ___isTemplate2;
		if (!L_23)
		{
			goto IL_008b;
		}
	}
	{
		ProviderData_t2518653487 * L_24 = V_0;
		String_t* L_25 = V_4;
		L_24->set_Id_2(L_25);
		goto IL_00d9;
	}

IL_008b:
	{
		String_t* L_26 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_27 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_26, _stringLiteral1421151742, /*hidden argument*/NULL);
		if (!L_27)
		{
			goto IL_00a8;
		}
	}
	{
		ProviderData_t2518653487 * L_28 = V_0;
		String_t* L_29 = V_4;
		L_28->set_Type_1(L_29);
		goto IL_00d9;
	}

IL_00a8:
	{
		String_t* L_30 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_31 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_30, _stringLiteral3021628817, /*hidden argument*/NULL);
		if (!L_31)
		{
			goto IL_00cb;
		}
	}
	{
		bool L_32 = ___isTemplate2;
		if (L_32)
		{
			goto IL_00cb;
		}
	}
	{
		ProviderData_t2518653487 * L_33 = V_0;
		String_t* L_34 = V_4;
		L_33->set_Ref_0(L_34);
		goto IL_00d9;
	}

IL_00cb:
	{
		ProviderData_t2518653487 * L_35 = V_0;
		Hashtable_t909839986 * L_36 = L_35->get_CustomProperties_3();
		String_t* L_37 = V_3;
		String_t* L_38 = V_4;
		VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(25 /* System.Void System.Collections.Hashtable::Add(System.Object,System.Object) */, L_36, L_37, L_38);
	}

IL_00d9:
	{
		int32_t L_39 = V_2;
		V_2 = ((int32_t)((int32_t)L_39+(int32_t)1));
	}

IL_00dd:
	{
		int32_t L_40 = V_2;
		Il2CppObject * L_41 = ___attrs1;
		StringU5BU5D_t1642385972* L_42 = InterfaceFuncInvoker0< StringU5BU5D_t1642385972* >::Invoke(4 /* System.String[] Mono.Xml.SmallXmlParser/IAttrList::get_Names() */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_41);
		if ((((int32_t)L_40) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_42)->max_length)))))))
		{
			goto IL_0055;
		}
	}
	{
		ProviderData_t2518653487 * L_43 = V_0;
		String_t* L_44 = L_43->get_Id_2();
		if (L_44)
		{
			goto IL_0107;
		}
	}
	{
		bool L_45 = ___isTemplate2;
		if (!L_45)
		{
			goto IL_0107;
		}
	}
	{
		RemotingException_t109604560 * L_46 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_46, _stringLiteral2035507306, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_46);
	}

IL_0107:
	{
		ProviderData_t2518653487 * L_47 = V_0;
		return L_47;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadClientActivated(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* ActivatedClientTypeEntry_t4060499430_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern Il2CppCodeGenString* _stringLiteral4173648305;
extern const uint32_t ConfigHandler_ReadClientActivated_m225401690_MetadataUsageId;
extern "C"  void ConfigHandler_ReadClientActivated_m225401690 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadClientActivated_m225401690_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ConfigHandler_GetNotNull_m2454680251(__this, L_0, _stringLiteral1421151742, /*hidden argument*/NULL);
		V_0 = L_1;
		String_t* L_2 = ConfigHandler_ExtractAssembly_m2993776658(__this, (&V_0), /*hidden argument*/NULL);
		V_1 = L_2;
		String_t* L_3 = __this->get_currentClientUrl_4();
		if (!L_3)
		{
			goto IL_0036;
		}
	}
	{
		String_t* L_4 = __this->get_currentClientUrl_4();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_5 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0041;
		}
	}

IL_0036:
	{
		RemotingException_t109604560 * L_7 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_7, _stringLiteral4173648305, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_0041:
	{
		ArrayList_t4252133567 * L_8 = __this->get_typeEntries_0();
		String_t* L_9 = V_0;
		String_t* L_10 = V_1;
		String_t* L_11 = __this->get_currentClientUrl_4();
		ActivatedClientTypeEntry_t4060499430 * L_12 = (ActivatedClientTypeEntry_t4060499430 *)il2cpp_codegen_object_new(ActivatedClientTypeEntry_t4060499430_il2cpp_TypeInfo_var);
		ActivatedClientTypeEntry__ctor_m2437890002(L_12, L_9, L_10, L_11, /*hidden argument*/NULL);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_8, L_12);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadServiceActivated(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* ActivatedServiceTypeEntry_t3934090848_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern const uint32_t ConfigHandler_ReadServiceActivated_m907987684_MetadataUsageId;
extern "C"  void ConfigHandler_ReadServiceActivated_m907987684 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadServiceActivated_m907987684_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ConfigHandler_GetNotNull_m2454680251(__this, L_0, _stringLiteral1421151742, /*hidden argument*/NULL);
		V_0 = L_1;
		String_t* L_2 = ConfigHandler_ExtractAssembly_m2993776658(__this, (&V_0), /*hidden argument*/NULL);
		V_1 = L_2;
		ArrayList_t4252133567 * L_3 = __this->get_typeEntries_0();
		String_t* L_4 = V_0;
		String_t* L_5 = V_1;
		ActivatedServiceTypeEntry_t3934090848 * L_6 = (ActivatedServiceTypeEntry_t3934090848 *)il2cpp_codegen_object_new(ActivatedServiceTypeEntry_t3934090848_il2cpp_TypeInfo_var);
		ActivatedServiceTypeEntry__ctor_m2853895798(L_6, L_4, L_5, /*hidden argument*/NULL);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_3, L_6);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadClientWellKnown(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* WellKnownClientTypeEntry_t3314744170_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral386853519;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern const uint32_t ConfigHandler_ReadClientWellKnown_m4206953534_MetadataUsageId;
extern "C"  void ConfigHandler_ReadClientWellKnown_m4206953534 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadClientWellKnown_m4206953534_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	String_t* V_2 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ConfigHandler_GetNotNull_m2454680251(__this, L_0, _stringLiteral386853519, /*hidden argument*/NULL);
		V_0 = L_1;
		Il2CppObject * L_2 = ___attrs0;
		String_t* L_3 = ConfigHandler_GetNotNull_m2454680251(__this, L_2, _stringLiteral1421151742, /*hidden argument*/NULL);
		V_1 = L_3;
		String_t* L_4 = ConfigHandler_ExtractAssembly_m2993776658(__this, (&V_1), /*hidden argument*/NULL);
		V_2 = L_4;
		ArrayList_t4252133567 * L_5 = __this->get_typeEntries_0();
		String_t* L_6 = V_1;
		String_t* L_7 = V_2;
		String_t* L_8 = V_0;
		WellKnownClientTypeEntry_t3314744170 * L_9 = (WellKnownClientTypeEntry_t3314744170 *)il2cpp_codegen_object_new(WellKnownClientTypeEntry_t3314744170_il2cpp_TypeInfo_var);
		WellKnownClientTypeEntry__ctor_m670594074(L_9, L_6, L_7, L_8, /*hidden argument*/NULL);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_5, L_9);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadServiceWellKnown(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* WellKnownServiceTypeEntry_t1712728956_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1810265715;
extern Il2CppCodeGenString* _stringLiteral1414244983;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern Il2CppCodeGenString* _stringLiteral957284138;
extern Il2CppCodeGenString* _stringLiteral2498125651;
extern Il2CppCodeGenString* _stringLiteral4172275530;
extern Il2CppCodeGenString* _stringLiteral2694133394;
extern const uint32_t ConfigHandler_ReadServiceWellKnown_m1495748104_MetadataUsageId;
extern "C"  void ConfigHandler_ReadServiceWellKnown_m1495748104 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadServiceWellKnown_m1495748104_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	String_t* V_2 = NULL;
	String_t* V_3 = NULL;
	int32_t V_4 = 0;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ConfigHandler_GetNotNull_m2454680251(__this, L_0, _stringLiteral1810265715, /*hidden argument*/NULL);
		V_0 = L_1;
		Il2CppObject * L_2 = ___attrs0;
		String_t* L_3 = ConfigHandler_GetNotNull_m2454680251(__this, L_2, _stringLiteral1414244983, /*hidden argument*/NULL);
		V_1 = L_3;
		Il2CppObject * L_4 = ___attrs0;
		String_t* L_5 = ConfigHandler_GetNotNull_m2454680251(__this, L_4, _stringLiteral1421151742, /*hidden argument*/NULL);
		V_2 = L_5;
		String_t* L_6 = ConfigHandler_ExtractAssembly_m2993776658(__this, (&V_2), /*hidden argument*/NULL);
		V_3 = L_6;
		String_t* L_7 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_8 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_7, _stringLiteral957284138, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_0048;
		}
	}
	{
		V_4 = 2;
		goto IL_0076;
	}

IL_0048:
	{
		String_t* L_9 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_10 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_9, _stringLiteral2498125651, /*hidden argument*/NULL);
		if (!L_10)
		{
			goto IL_0060;
		}
	}
	{
		V_4 = 1;
		goto IL_0076;
	}

IL_0060:
	{
		String_t* L_11 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_12 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral4172275530, L_11, _stringLiteral2694133394, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_13 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_13, L_12, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_13);
	}

IL_0076:
	{
		ArrayList_t4252133567 * L_14 = __this->get_typeEntries_0();
		String_t* L_15 = V_2;
		String_t* L_16 = V_3;
		String_t* L_17 = V_0;
		int32_t L_18 = V_4;
		WellKnownServiceTypeEntry_t1712728956 * L_19 = (WellKnownServiceTypeEntry_t1712728956 *)il2cpp_codegen_object_new(WellKnownServiceTypeEntry_t1712728956_il2cpp_TypeInfo_var);
		WellKnownServiceTypeEntry__ctor_m1109686429(L_19, L_15, L_16, L_17, L_18, /*hidden argument*/NULL);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_14, L_19);
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadInteropXml(Mono.Xml.SmallXmlParser/IAttrList,System.Boolean)
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* CharU5BU5D_t1328083999_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapServices_t3397513225_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4231481921;
extern Il2CppCodeGenString* _stringLiteral2665398521;
extern const uint32_t ConfigHandler_ReadInteropXml_m539906871_MetadataUsageId;
extern "C"  void ConfigHandler_ReadInteropXml_m539906871 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, bool ___isElement1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadInteropXml_m539906871_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Type_t * V_0 = NULL;
	StringU5BU5D_t1642385972* V_1 = NULL;
	String_t* V_2 = NULL;
	String_t* V_3 = NULL;
	String_t* G_B3_0 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ConfigHandler_GetNotNull_m2454680251(__this, L_0, _stringLiteral4231481921, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m773255995, L_1, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		V_0 = L_2;
		Il2CppObject * L_3 = ___attrs0;
		String_t* L_4 = ConfigHandler_GetNotNull_m2454680251(__this, L_3, _stringLiteral2665398521, /*hidden argument*/NULL);
		CharU5BU5D_t1328083999* L_5 = ((CharU5BU5D_t1328083999*)SZArrayNew(CharU5BU5D_t1328083999_il2cpp_TypeInfo_var, (uint32_t)1));
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppChar)((int32_t)44));
		StringU5BU5D_t1642385972* L_6 = String_Split_m3326265864(L_4, L_5, /*hidden argument*/NULL);
		V_1 = L_6;
		StringU5BU5D_t1642385972* L_7 = V_1;
		int32_t L_8 = 0;
		String_t* L_9 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		String_t* L_10 = String_Trim_m2668767713(L_9, /*hidden argument*/NULL);
		V_2 = L_10;
		StringU5BU5D_t1642385972* L_11 = V_1;
		if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_004e;
		}
	}
	{
		StringU5BU5D_t1642385972* L_12 = V_1;
		int32_t L_13 = 1;
		String_t* L_14 = (L_12)->GetAt(static_cast<il2cpp_array_size_t>(L_13));
		String_t* L_15 = String_Trim_m2668767713(L_14, /*hidden argument*/NULL);
		G_B3_0 = L_15;
		goto IL_004f;
	}

IL_004e:
	{
		G_B3_0 = ((String_t*)(NULL));
	}

IL_004f:
	{
		V_3 = G_B3_0;
		bool L_16 = ___isElement1;
		if (!L_16)
		{
			goto IL_0063;
		}
	}
	{
		String_t* L_17 = V_2;
		String_t* L_18 = V_3;
		Type_t * L_19 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SoapServices_t3397513225_il2cpp_TypeInfo_var);
		SoapServices_RegisterInteropXmlElement_m1542943839(NULL /*static, unused*/, L_17, L_18, L_19, /*hidden argument*/NULL);
		goto IL_006b;
	}

IL_0063:
	{
		String_t* L_20 = V_2;
		String_t* L_21 = V_3;
		Type_t * L_22 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SoapServices_t3397513225_il2cpp_TypeInfo_var);
		SoapServices_RegisterInteropXmlType_m2949236705(NULL /*static, unused*/, L_20, L_21, L_22, /*hidden argument*/NULL);
	}

IL_006b:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::ReadPreload(Mono.Xml.SmallXmlParser/IAttrList)
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapServices_t3397513225_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1421151742;
extern Il2CppCodeGenString* _stringLiteral1488311710;
extern Il2CppCodeGenString* _stringLiteral3383067454;
extern Il2CppCodeGenString* _stringLiteral316685325;
extern const uint32_t ConfigHandler_ReadPreload_m455851711_MetadataUsageId;
extern "C"  void ConfigHandler_ReadPreload_m455851711 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ReadPreload_m455851711_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	String_t* V_1 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = InterfaceFuncInvoker1< String_t*, String_t* >::Invoke(3 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.String) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_0, _stringLiteral1421151742);
		V_0 = L_1;
		Il2CppObject * L_2 = ___attrs0;
		String_t* L_3 = InterfaceFuncInvoker1< String_t*, String_t* >::Invoke(3 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.String) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_2, _stringLiteral1488311710);
		V_1 = L_3;
		String_t* L_4 = V_0;
		if (!L_4)
		{
			goto IL_002f;
		}
	}
	{
		String_t* L_5 = V_1;
		if (!L_5)
		{
			goto IL_002f;
		}
	}
	{
		RemotingException_t109604560 * L_6 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_6, _stringLiteral3383067454, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6);
	}

IL_002f:
	{
		String_t* L_7 = V_0;
		if (!L_7)
		{
			goto IL_0045;
		}
	}
	{
		String_t* L_8 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_9 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m773255995, L_8, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		IL2CPP_RUNTIME_CLASS_INIT(SoapServices_t3397513225_il2cpp_TypeInfo_var);
		SoapServices_PreLoad_m490411755(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		goto IL_0066;
	}

IL_0045:
	{
		String_t* L_10 = V_1;
		if (!L_10)
		{
			goto IL_005b;
		}
	}
	{
		String_t* L_11 = V_1;
		Assembly_t4268412390 * L_12 = Assembly_Load_m902205655(NULL /*static, unused*/, L_11, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(SoapServices_t3397513225_il2cpp_TypeInfo_var);
		SoapServices_PreLoad_m981167866(NULL /*static, unused*/, L_12, /*hidden argument*/NULL);
		goto IL_0066;
	}

IL_005b:
	{
		RemotingException_t109604560 * L_13 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_13, _stringLiteral316685325, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_13);
	}

IL_0066:
	{
		return;
	}
}
// System.String System.Runtime.Remoting.ConfigHandler::GetNotNull(Mono.Xml.SmallXmlParser/IAttrList,System.String)
extern Il2CppClass* IAttrList_t4064541270_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4228450727;
extern const uint32_t ConfigHandler_GetNotNull_m2454680251_MetadataUsageId;
extern "C"  String_t* ConfigHandler_GetNotNull_m2454680251 (ConfigHandler_t2180714860 * __this, Il2CppObject * ___attrs0, String_t* ___name1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_GetNotNull_m2454680251_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	{
		Il2CppObject * L_0 = ___attrs0;
		String_t* L_1 = ___name1;
		String_t* L_2 = InterfaceFuncInvoker1< String_t*, String_t* >::Invoke(3 /* System.String Mono.Xml.SmallXmlParser/IAttrList::GetValue(System.String) */, IAttrList_t4064541270_il2cpp_TypeInfo_var, L_0, L_1);
		V_0 = L_2;
		String_t* L_3 = V_0;
		if (!L_3)
		{
			goto IL_001e;
		}
	}
	{
		String_t* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_5 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_002f;
		}
	}

IL_001e:
	{
		String_t* L_7 = ___name1;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_8 = String_Concat_m2596409543(NULL /*static, unused*/, L_7, _stringLiteral4228450727, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_9 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_9, L_8, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9);
	}

IL_002f:
	{
		String_t* L_10 = V_0;
		return L_10;
	}
}
// System.String System.Runtime.Remoting.ConfigHandler::ExtractAssembly(System.String&)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t ConfigHandler_ExtractAssembly_m2993776658_MetadataUsageId;
extern "C"  String_t* ConfigHandler_ExtractAssembly_m2993776658 (ConfigHandler_t2180714860 * __this, String_t** ___type0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_ExtractAssembly_m2993776658_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	String_t* V_1 = NULL;
	{
		String_t** L_0 = ___type0;
		int32_t L_1 = String_IndexOf_m2358239236((*((String_t**)L_0)), ((int32_t)44), /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = V_0;
		if ((!(((uint32_t)L_2) == ((uint32_t)(-1)))))
		{
			goto IL_0017;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		return L_3;
	}

IL_0017:
	{
		String_t** L_4 = ___type0;
		int32_t L_5 = V_0;
		String_t* L_6 = String_Substring_m2032624251((*((String_t**)L_4)), ((int32_t)((int32_t)L_5+(int32_t)1)), /*hidden argument*/NULL);
		String_t* L_7 = String_Trim_m2668767713(L_6, /*hidden argument*/NULL);
		V_1 = L_7;
		String_t** L_8 = ___type0;
		String_t** L_9 = ___type0;
		int32_t L_10 = V_0;
		String_t* L_11 = String_Substring_m12482732((*((String_t**)L_9)), 0, L_10, /*hidden argument*/NULL);
		String_t* L_12 = String_Trim_m2668767713(L_11, /*hidden argument*/NULL);
		*((Il2CppObject **)(L_8)) = (Il2CppObject *)L_12;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_8), (Il2CppObject *)L_12);
		String_t* L_13 = V_1;
		return L_13;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnChars(System.String)
extern "C"  void ConfigHandler_OnChars_m2004226744 (ConfigHandler_t2180714860 * __this, String_t* ___ch0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.ConfigHandler::OnEndParsing(Mono.Xml.SmallXmlParser)
extern Il2CppClass* RemotingConfiguration_t438177651_il2cpp_TypeInfo_var;
extern const uint32_t ConfigHandler_OnEndParsing_m2528686941_MetadataUsageId;
extern "C"  void ConfigHandler_OnEndParsing_m2528686941 (ConfigHandler_t2180714860 * __this, SmallXmlParser_t3549787957 * ___parser0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConfigHandler_OnEndParsing_m2528686941_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = __this->get_channelInstances_1();
		bool L_1 = __this->get_onlyDelayedChannels_7();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_RegisterChannels_m2036610082(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		String_t* L_2 = __this->get_appName_5();
		if (!L_2)
		{
			goto IL_0027;
		}
	}
	{
		String_t* L_3 = __this->get_appName_5();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_set_ApplicationName_m484446441(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
	}

IL_0027:
	{
		bool L_4 = __this->get_onlyDelayedChannels_7();
		if (L_4)
		{
			goto IL_003d;
		}
	}
	{
		ArrayList_t4252133567 * L_5 = __this->get_typeEntries_0();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingConfiguration_t438177651_il2cpp_TypeInfo_var);
		RemotingConfiguration_RegisterTypes_m1739896888(NULL /*static, unused*/, L_5, /*hidden argument*/NULL);
	}

IL_003d:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::.ctor()
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context__ctor_m3303382579_MetadataUsageId;
extern "C"  void Context__ctor_m3303382579 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context__ctor_m3303382579_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		int32_t L_0 = Thread_GetDomainID_m21918982(NULL /*static, unused*/, /*hidden argument*/NULL);
		__this->set_domain_id_0(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		int32_t L_1 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_count_9();
		int32_t L_2 = L_1;
		((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->set_global_count_9(((int32_t)((int32_t)L_2+(int32_t)1)));
		__this->set_context_id_1(((int32_t)((int32_t)1+(int32_t)L_2)));
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::.cctor()
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context__cctor_m3895126354_MetadataUsageId;
extern "C"  void Context__cctor_m3895126354 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context__cctor_m3895126354_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_0, /*hidden argument*/NULL);
		((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->set_namedSlots_10(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::Finalize()
extern "C"  void Context_Finalize_m1386439645 (Context_t502196753 * __this, const MethodInfo* method)
{
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		IL2CPP_LEAVE(0xC, FINALLY_0005);
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0005;
	}

FINALLY_0005:
	{ // begin finally (depth: 1)
		Object_Finalize_m4087144328(__this, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(5)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(5)
	{
		IL2CPP_JUMP_TBL(0xC, IL_000c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_000c:
	{
		return;
	}
}
// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Contexts.Context::get_DefaultContext()
extern "C"  Context_t502196753 * Context_get_DefaultContext_m2211922324 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	{
		Context_t502196753 * L_0 = AppDomain_InternalGetDefaultContext_m978759799(NULL /*static, unused*/, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Int32 System.Runtime.Remoting.Contexts.Context::get_ContextID()
extern "C"  int32_t Context_get_ContextID_m1615769170 (Context_t502196753 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_context_id_1();
		return L_0;
	}
}
// System.Runtime.Remoting.Contexts.IContextProperty[] System.Runtime.Remoting.Contexts.Context::get_ContextProperties()
extern const Il2CppType* IContextPropertyU5BU5D_t977923046_0_0_0_var;
extern Il2CppClass* IContextPropertyU5BU5D_t977923046_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t Context_get_ContextProperties_m2382392632_MetadataUsageId;
extern "C"  IContextPropertyU5BU5D_t977923046* Context_get_ContextProperties_m2382392632 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_get_ContextProperties_m2382392632_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = __this->get_context_properties_7();
		if (L_0)
		{
			goto IL_0012;
		}
	}
	{
		return ((IContextPropertyU5BU5D_t977923046*)SZArrayNew(IContextPropertyU5BU5D_t977923046_il2cpp_TypeInfo_var, (uint32_t)0));
	}

IL_0012:
	{
		ArrayList_t4252133567 * L_1 = __this->get_context_properties_7();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(IContextPropertyU5BU5D_t977923046_0_0_0_var), /*hidden argument*/NULL);
		Il2CppArray * L_3 = VirtFuncInvoker1< Il2CppArray *, Type_t * >::Invoke(48 /* System.Array System.Collections.ArrayList::ToArray(System.Type) */, L_1, L_2);
		return ((IContextPropertyU5BU5D_t977923046*)Castclass(L_3, IContextPropertyU5BU5D_t977923046_il2cpp_TypeInfo_var));
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::get_IsDefaultContext()
extern "C"  bool Context_get_IsDefaultContext_m3300558634 (Context_t502196753 * __this, const MethodInfo* method)
{
	{
		int32_t L_0 = __this->get_context_id_1();
		return (bool)((((int32_t)L_0) == ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::get_NeedsContextSink()
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_get_NeedsContextSink_m1907794755_MetadataUsageId;
extern "C"  bool Context_get_NeedsContextSink_m1907794755 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_get_NeedsContextSink_m1907794755_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t G_B6_0 = 0;
	int32_t G_B8_0 = 0;
	{
		int32_t L_0 = __this->get_context_id_1();
		if (L_0)
		{
			goto IL_003f;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_1 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		if (!L_1)
		{
			goto IL_0024;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_2 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		bool L_3 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_2, /*hidden argument*/NULL);
		if (L_3)
		{
			goto IL_003f;
		}
	}

IL_0024:
	{
		DynamicPropertyCollection_t2282532998 * L_4 = __this->get_context_dynamic_properties_12();
		if (!L_4)
		{
			goto IL_003c;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_5 = __this->get_context_dynamic_properties_12();
		bool L_6 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_5, /*hidden argument*/NULL);
		G_B6_0 = ((int32_t)(L_6));
		goto IL_003d;
	}

IL_003c:
	{
		G_B6_0 = 0;
	}

IL_003d:
	{
		G_B8_0 = G_B6_0;
		goto IL_0040;
	}

IL_003f:
	{
		G_B8_0 = 1;
	}

IL_0040:
	{
		return (bool)G_B8_0;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::RegisterDynamicProperty(System.Runtime.Remoting.Contexts.IDynamicProperty,System.ContextBoundObject,System.Runtime.Remoting.Contexts.Context)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_RegisterDynamicProperty_m2075612383_MetadataUsageId;
extern "C"  bool Context_RegisterDynamicProperty_m2075612383 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___prop0, ContextBoundObject_t4264702438 * ___obj1, Context_t502196753 * ___ctx2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_RegisterDynamicProperty_m2075612383_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DynamicPropertyCollection_t2282532998 * V_0 = NULL;
	{
		ContextBoundObject_t4264702438 * L_0 = ___obj1;
		Context_t502196753 * L_1 = ___ctx2;
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_2 = Context_GetDynamicPropertyCollection_m1987747444(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		DynamicPropertyCollection_t2282532998 * L_3 = V_0;
		Il2CppObject * L_4 = ___prop0;
		bool L_5 = DynamicPropertyCollection_RegisterDynamicProperty_m3083838256(L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::UnregisterDynamicProperty(System.String,System.ContextBoundObject,System.Runtime.Remoting.Contexts.Context)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_UnregisterDynamicProperty_m4064851633_MetadataUsageId;
extern "C"  bool Context_UnregisterDynamicProperty_m4064851633 (Il2CppObject * __this /* static, unused */, String_t* ___name0, ContextBoundObject_t4264702438 * ___obj1, Context_t502196753 * ___ctx2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_UnregisterDynamicProperty_m4064851633_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DynamicPropertyCollection_t2282532998 * V_0 = NULL;
	{
		ContextBoundObject_t4264702438 * L_0 = ___obj1;
		Context_t502196753 * L_1 = ___ctx2;
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_2 = Context_GetDynamicPropertyCollection_m1987747444(NULL /*static, unused*/, L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		DynamicPropertyCollection_t2282532998 * L_3 = V_0;
		String_t* L_4 = ___name0;
		bool L_5 = DynamicPropertyCollection_UnregisterDynamicProperty_m432705250(L_3, L_4, /*hidden argument*/NULL);
		return L_5;
	}
}
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection System.Runtime.Remoting.Contexts.Context::GetDynamicPropertyCollection(System.ContextBoundObject,System.Runtime.Remoting.Contexts.Context)
extern Il2CppClass* RemotingServices_t2399536837_il2cpp_TypeInfo_var;
extern Il2CppClass* DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var;
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3801909245;
extern const uint32_t Context_GetDynamicPropertyCollection_m1987747444_MetadataUsageId;
extern "C"  DynamicPropertyCollection_t2282532998 * Context_GetDynamicPropertyCollection_m1987747444 (Il2CppObject * __this /* static, unused */, ContextBoundObject_t4264702438 * ___obj0, Context_t502196753 * ___ctx1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetDynamicPropertyCollection_m1987747444_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	RealProxy_t298428346 * V_0 = NULL;
	{
		Context_t502196753 * L_0 = ___ctx1;
		if (L_0)
		{
			goto IL_0036;
		}
	}
	{
		ContextBoundObject_t4264702438 * L_1 = ___obj0;
		if (!L_1)
		{
			goto IL_0036;
		}
	}
	{
		ContextBoundObject_t4264702438 * L_2 = ___obj0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		bool L_3 = RemotingServices_IsTransparentProxy_m162250343(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
		if (!L_3)
		{
			goto IL_002a;
		}
	}
	{
		ContextBoundObject_t4264702438 * L_4 = ___obj0;
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		RealProxy_t298428346 * L_5 = RemotingServices_GetRealProxy_m620317996(NULL /*static, unused*/, L_4, /*hidden argument*/NULL);
		V_0 = L_5;
		RealProxy_t298428346 * L_6 = V_0;
		Identity_t3647548000 * L_7 = RealProxy_get_ObjectIdentity_m1633976845(L_6, /*hidden argument*/NULL);
		DynamicPropertyCollection_t2282532998 * L_8 = Identity_get_ClientDynamicProperties_m767245959(L_7, /*hidden argument*/NULL);
		return L_8;
	}

IL_002a:
	{
		ContextBoundObject_t4264702438 * L_9 = ___obj0;
		ServerIdentity_t1656058977 * L_10 = MarshalByRefObject_get_ObjectIdentity_m2107521536(L_9, /*hidden argument*/NULL);
		DynamicPropertyCollection_t2282532998 * L_11 = Identity_get_ServerDynamicProperties_m2264450835(L_10, /*hidden argument*/NULL);
		return L_11;
	}

IL_0036:
	{
		Context_t502196753 * L_12 = ___ctx1;
		if (!L_12)
		{
			goto IL_005f;
		}
	}
	{
		ContextBoundObject_t4264702438 * L_13 = ___obj0;
		if (L_13)
		{
			goto IL_005f;
		}
	}
	{
		Context_t502196753 * L_14 = ___ctx1;
		DynamicPropertyCollection_t2282532998 * L_15 = L_14->get_context_dynamic_properties_12();
		if (L_15)
		{
			goto IL_0058;
		}
	}
	{
		Context_t502196753 * L_16 = ___ctx1;
		DynamicPropertyCollection_t2282532998 * L_17 = (DynamicPropertyCollection_t2282532998 *)il2cpp_codegen_object_new(DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var);
		DynamicPropertyCollection__ctor_m1159577654(L_17, /*hidden argument*/NULL);
		L_16->set_context_dynamic_properties_12(L_17);
	}

IL_0058:
	{
		Context_t502196753 * L_18 = ___ctx1;
		DynamicPropertyCollection_t2282532998 * L_19 = L_18->get_context_dynamic_properties_12();
		return L_19;
	}

IL_005f:
	{
		Context_t502196753 * L_20 = ___ctx1;
		if (L_20)
		{
			goto IL_0085;
		}
	}
	{
		ContextBoundObject_t4264702438 * L_21 = ___obj0;
		if (L_21)
		{
			goto IL_0085;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_22 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		if (L_22)
		{
			goto IL_007f;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_23 = (DynamicPropertyCollection_t2282532998 *)il2cpp_codegen_object_new(DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var);
		DynamicPropertyCollection__ctor_m1159577654(L_23, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->set_global_dynamic_properties_11(L_23);
	}

IL_007f:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_24 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		return L_24;
	}

IL_0085:
	{
		ArgumentException_t3259014390 * L_25 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_25, _stringLiteral3801909245, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_25);
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::NotifyGlobalDynamicSinks(System.Boolean,System.Runtime.Remoting.Messaging.IMessage,System.Boolean,System.Boolean)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_NotifyGlobalDynamicSinks_m2916447645_MetadataUsageId;
extern "C"  void Context_NotifyGlobalDynamicSinks_m2916447645 (Il2CppObject * __this /* static, unused */, bool ___start0, Il2CppObject * ___req_msg1, bool ___client_site2, bool ___async3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_NotifyGlobalDynamicSinks_m2916447645_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_0 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		if (!L_0)
		{
			goto IL_0027;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_1 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		bool L_2 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_0027;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_3 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		bool L_4 = ___start0;
		Il2CppObject * L_5 = ___req_msg1;
		bool L_6 = ___client_site2;
		bool L_7 = ___async3;
		DynamicPropertyCollection_NotifyMessage_m840388347(L_3, L_4, L_5, L_6, L_7, /*hidden argument*/NULL);
	}

IL_0027:
	{
		return;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::get_HasGlobalDynamicSinks()
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_get_HasGlobalDynamicSinks_m3205328884_MetadataUsageId;
extern "C"  bool Context_get_HasGlobalDynamicSinks_m3205328884 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_get_HasGlobalDynamicSinks_m3205328884_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t G_B3_0 = 0;
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_0 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		DynamicPropertyCollection_t2282532998 * L_1 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_global_dynamic_properties_11();
		bool L_2 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_1, /*hidden argument*/NULL);
		G_B3_0 = ((int32_t)(L_2));
		goto IL_0017;
	}

IL_0016:
	{
		G_B3_0 = 0;
	}

IL_0017:
	{
		return (bool)G_B3_0;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::NotifyDynamicSinks(System.Boolean,System.Runtime.Remoting.Messaging.IMessage,System.Boolean,System.Boolean)
extern "C"  void Context_NotifyDynamicSinks_m1367144344 (Context_t502196753 * __this, bool ___start0, Il2CppObject * ___req_msg1, bool ___client_site2, bool ___async3, const MethodInfo* method)
{
	{
		DynamicPropertyCollection_t2282532998 * L_0 = __this->get_context_dynamic_properties_12();
		if (!L_0)
		{
			goto IL_002b;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_1 = __this->get_context_dynamic_properties_12();
		bool L_2 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_1, /*hidden argument*/NULL);
		if (!L_2)
		{
			goto IL_002b;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_3 = __this->get_context_dynamic_properties_12();
		bool L_4 = ___start0;
		Il2CppObject * L_5 = ___req_msg1;
		bool L_6 = ___client_site2;
		bool L_7 = ___async3;
		DynamicPropertyCollection_NotifyMessage_m840388347(L_3, L_4, L_5, L_6, L_7, /*hidden argument*/NULL);
	}

IL_002b:
	{
		return;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::get_HasDynamicSinks()
extern "C"  bool Context_get_HasDynamicSinks_m1998518649 (Context_t502196753 * __this, const MethodInfo* method)
{
	int32_t G_B3_0 = 0;
	{
		DynamicPropertyCollection_t2282532998 * L_0 = __this->get_context_dynamic_properties_12();
		if (!L_0)
		{
			goto IL_0018;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_1 = __this->get_context_dynamic_properties_12();
		bool L_2 = DynamicPropertyCollection_get_HasProperties_m2092159924(L_1, /*hidden argument*/NULL);
		G_B3_0 = ((int32_t)(L_2));
		goto IL_0019;
	}

IL_0018:
	{
		G_B3_0 = 0;
	}

IL_0019:
	{
		return (bool)G_B3_0;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.Context::get_HasExitSinks()
extern Il2CppClass* ClientContextTerminatorSink_t3236389774_il2cpp_TypeInfo_var;
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_get_HasExitSinks_m1233814330_MetadataUsageId;
extern "C"  bool Context_get_HasExitSinks_m1233814330 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_get_HasExitSinks_m1233814330_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t G_B4_0 = 0;
	{
		Il2CppObject * L_0 = Context_GetClientContextSinkChain_m1645078461(__this, /*hidden argument*/NULL);
		if (!((ClientContextTerminatorSink_t3236389774 *)IsInstClass(L_0, ClientContextTerminatorSink_t3236389774_il2cpp_TypeInfo_var)))
		{
			goto IL_0022;
		}
	}
	{
		bool L_1 = Context_get_HasDynamicSinks_m1998518649(__this, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0022;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		bool L_2 = Context_get_HasGlobalDynamicSinks_m3205328884(NULL /*static, unused*/, /*hidden argument*/NULL);
		G_B4_0 = ((int32_t)(L_2));
		goto IL_0023;
	}

IL_0022:
	{
		G_B4_0 = 1;
	}

IL_0023:
	{
		return (bool)G_B4_0;
	}
}
// System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String)
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t Context_GetProperty_m1664740450_MetadataUsageId;
extern "C"  Il2CppObject * Context_GetProperty_m1664740450 (Context_t502196753 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetProperty_m1664740450_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = __this->get_context_properties_7();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (Il2CppObject *)NULL;
	}

IL_000d:
	{
		ArrayList_t4252133567 * L_1 = __this->get_context_properties_7();
		Il2CppObject * L_2 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_1);
		V_1 = L_2;
	}

IL_0019:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0042;
		}

IL_001e:
		{
			Il2CppObject * L_3 = V_1;
			Il2CppObject * L_4 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_3);
			V_0 = ((Il2CppObject *)Castclass(L_4, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Il2CppObject * L_5 = V_0;
			String_t* L_6 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Contexts.IContextProperty::get_Name() */, IContextProperty_t287246399_il2cpp_TypeInfo_var, L_5);
			String_t* L_7 = ___name0;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			bool L_8 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_6, L_7, /*hidden argument*/NULL);
			if (!L_8)
			{
				goto IL_0042;
			}
		}

IL_003b:
		{
			Il2CppObject * L_9 = V_0;
			V_2 = L_9;
			IL2CPP_LEAVE(0x66, FINALLY_0052);
		}

IL_0042:
		{
			Il2CppObject * L_10 = V_1;
			bool L_11 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_10);
			if (L_11)
			{
				goto IL_001e;
			}
		}

IL_004d:
		{
			IL2CPP_LEAVE(0x64, FINALLY_0052);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0052;
	}

FINALLY_0052:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_12 = V_1;
			V_3 = ((Il2CppObject *)IsInst(L_12, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_13 = V_3;
			if (L_13)
			{
				goto IL_005d;
			}
		}

IL_005c:
		{
			IL2CPP_END_FINALLY(82)
		}

IL_005d:
		{
			Il2CppObject * L_14 = V_3;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_14);
			IL2CPP_END_FINALLY(82)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(82)
	{
		IL2CPP_JUMP_TBL(0x66, IL_0066)
		IL2CPP_JUMP_TBL(0x64, IL_0064)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0064:
	{
		return (Il2CppObject *)NULL;
	}

IL_0066:
	{
		Il2CppObject * L_15 = V_2;
		return L_15;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::SetProperty(System.Runtime.Remoting.Contexts.IContextProperty)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3250019505;
extern Il2CppCodeGenString* _stringLiteral2655115758;
extern Il2CppCodeGenString* _stringLiteral713869011;
extern const uint32_t Context_SetProperty_m1208242955_MetadataUsageId;
extern "C"  void Context_SetProperty_m1208242955 (Context_t502196753 * __this, Il2CppObject * ___prop0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_SetProperty_m1208242955_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___prop0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral3250019505, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Context_t502196753 * L_2 = Context_get_DefaultContext_m2211922324(NULL /*static, unused*/, /*hidden argument*/NULL);
		if ((!(((Il2CppObject*)(Context_t502196753 *)__this) == ((Il2CppObject*)(Context_t502196753 *)L_2))))
		{
			goto IL_0027;
		}
	}
	{
		InvalidOperationException_t721527559 * L_3 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_3, _stringLiteral2655115758, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_0027:
	{
		bool L_4 = __this->get_frozen_8();
		if (!L_4)
		{
			goto IL_003d;
		}
	}
	{
		InvalidOperationException_t721527559 * L_5 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_5, _stringLiteral713869011, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_003d:
	{
		ArrayList_t4252133567 * L_6 = __this->get_context_properties_7();
		if (L_6)
		{
			goto IL_0053;
		}
	}
	{
		ArrayList_t4252133567 * L_7 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_7, /*hidden argument*/NULL);
		__this->set_context_properties_7(L_7);
	}

IL_0053:
	{
		ArrayList_t4252133567 * L_8 = __this->get_context_properties_7();
		Il2CppObject * L_9 = ___prop0;
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_8, L_9);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::Freeze()
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t Context_Freeze_m1127151596_MetadataUsageId;
extern "C"  void Context_Freeze_m1127151596 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_Freeze_m1127151596_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = __this->get_context_properties_7();
		if (!L_0)
		{
			goto IL_0051;
		}
	}
	{
		ArrayList_t4252133567 * L_1 = __this->get_context_properties_7();
		Il2CppObject * L_2 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_1);
		V_1 = L_2;
	}

IL_0017:
	try
	{ // begin try (depth: 1)
		{
			goto IL_002f;
		}

IL_001c:
		{
			Il2CppObject * L_3 = V_1;
			Il2CppObject * L_4 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_3);
			V_0 = ((Il2CppObject *)Castclass(L_4, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Il2CppObject * L_5 = V_0;
			InterfaceActionInvoker1< Context_t502196753 * >::Invoke(1 /* System.Void System.Runtime.Remoting.Contexts.IContextProperty::Freeze(System.Runtime.Remoting.Contexts.Context) */, IContextProperty_t287246399_il2cpp_TypeInfo_var, L_5, __this);
		}

IL_002f:
		{
			Il2CppObject * L_6 = V_1;
			bool L_7 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_6);
			if (L_7)
			{
				goto IL_001c;
			}
		}

IL_003a:
		{
			IL2CPP_LEAVE(0x51, FINALLY_003f);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_003f;
	}

FINALLY_003f:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_8 = V_1;
			V_2 = ((Il2CppObject *)IsInst(L_8, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_9 = V_2;
			if (L_9)
			{
				goto IL_004a;
			}
		}

IL_0049:
		{
			IL2CPP_END_FINALLY(63)
		}

IL_004a:
		{
			Il2CppObject * L_10 = V_2;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_10);
			IL2CPP_END_FINALLY(63)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(63)
	{
		IL2CPP_JUMP_TBL(0x51, IL_0051)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0051:
	{
		return;
	}
}
// System.String System.Runtime.Remoting.Contexts.Context::ToString()
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1670132966;
extern const uint32_t Context_ToString_m3056873882_MetadataUsageId;
extern "C"  String_t* Context_ToString_m3056873882 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_ToString_m3056873882_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		int32_t L_0 = __this->get_context_id_1();
		int32_t L_1 = L_0;
		Il2CppObject * L_2 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_1);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = String_Concat_m56707527(NULL /*static, unused*/, _stringLiteral1670132966, L_2, /*hidden argument*/NULL);
		return L_3;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.Context::GetServerContextSinkChain()
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* ServerContextTerminatorSink_t1054294306_il2cpp_TypeInfo_var;
extern Il2CppClass* IContributeServerContextSink_t1849145353_il2cpp_TypeInfo_var;
extern const uint32_t Context_GetServerContextSinkChain_m390126977_MetadataUsageId;
extern "C"  Il2CppObject * Context_GetServerContextSinkChain_m390126977 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetServerContextSinkChain_m390126977_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	Il2CppObject * V_1 = NULL;
	{
		Il2CppObject * L_0 = __this->get_server_context_sink_chain_4();
		if (L_0)
		{
			goto IL_007d;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Il2CppObject * L_1 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_default_server_context_sink_3();
		if (L_1)
		{
			goto IL_001f;
		}
	}
	{
		ServerContextTerminatorSink_t1054294306 * L_2 = (ServerContextTerminatorSink_t1054294306 *)il2cpp_codegen_object_new(ServerContextTerminatorSink_t1054294306_il2cpp_TypeInfo_var);
		ServerContextTerminatorSink__ctor_m2130310560(L_2, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->set_default_server_context_sink_3(L_2);
	}

IL_001f:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Il2CppObject * L_3 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_default_server_context_sink_3();
		__this->set_server_context_sink_chain_4(L_3);
		ArrayList_t4252133567 * L_4 = __this->get_context_properties_7();
		if (!L_4)
		{
			goto IL_007d;
		}
	}
	{
		ArrayList_t4252133567 * L_5 = __this->get_context_properties_7();
		int32_t L_6 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_5);
		V_0 = ((int32_t)((int32_t)L_6-(int32_t)1));
		goto IL_0076;
	}

IL_0048:
	{
		ArrayList_t4252133567 * L_7 = __this->get_context_properties_7();
		int32_t L_8 = V_0;
		Il2CppObject * L_9 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_7, L_8);
		V_1 = ((Il2CppObject *)IsInst(L_9, IContributeServerContextSink_t1849145353_il2cpp_TypeInfo_var));
		Il2CppObject * L_10 = V_1;
		if (!L_10)
		{
			goto IL_0072;
		}
	}
	{
		Il2CppObject * L_11 = V_1;
		Il2CppObject * L_12 = __this->get_server_context_sink_chain_4();
		Il2CppObject * L_13 = InterfaceFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.IContributeServerContextSink::GetServerContextSink(System.Runtime.Remoting.Messaging.IMessageSink) */, IContributeServerContextSink_t1849145353_il2cpp_TypeInfo_var, L_11, L_12);
		__this->set_server_context_sink_chain_4(L_13);
	}

IL_0072:
	{
		int32_t L_14 = V_0;
		V_0 = ((int32_t)((int32_t)L_14-(int32_t)1));
	}

IL_0076:
	{
		int32_t L_15 = V_0;
		if ((((int32_t)L_15) >= ((int32_t)0)))
		{
			goto IL_0048;
		}
	}

IL_007d:
	{
		Il2CppObject * L_16 = __this->get_server_context_sink_chain_4();
		return L_16;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.Context::GetClientContextSinkChain()
extern Il2CppClass* ClientContextTerminatorSink_t3236389774_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* IContributeClientContextSink_t3409105893_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t Context_GetClientContextSinkChain_m1645078461_MetadataUsageId;
extern "C"  Il2CppObject * Context_GetClientContextSinkChain_m1645078461 (Context_t502196753 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetClientContextSinkChain_m1645078461_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Il2CppObject * L_0 = __this->get_client_context_sink_chain_5();
		if (L_0)
		{
			goto IL_0080;
		}
	}
	{
		ClientContextTerminatorSink_t3236389774 * L_1 = (ClientContextTerminatorSink_t3236389774 *)il2cpp_codegen_object_new(ClientContextTerminatorSink_t3236389774_il2cpp_TypeInfo_var);
		ClientContextTerminatorSink__ctor_m4067561773(L_1, __this, /*hidden argument*/NULL);
		__this->set_client_context_sink_chain_5(L_1);
		ArrayList_t4252133567 * L_2 = __this->get_context_properties_7();
		if (!L_2)
		{
			goto IL_0080;
		}
	}
	{
		ArrayList_t4252133567 * L_3 = __this->get_context_properties_7();
		Il2CppObject * L_4 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_3);
		V_1 = L_4;
	}

IL_002e:
	try
	{ // begin try (depth: 1)
		{
			goto IL_005e;
		}

IL_0033:
		{
			Il2CppObject * L_5 = V_1;
			Il2CppObject * L_6 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_5);
			V_0 = ((Il2CppObject *)Castclass(L_6, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Il2CppObject * L_7 = V_0;
			V_2 = ((Il2CppObject *)IsInst(L_7, IContributeClientContextSink_t3409105893_il2cpp_TypeInfo_var));
			Il2CppObject * L_8 = V_2;
			if (!L_8)
			{
				goto IL_005e;
			}
		}

IL_004c:
		{
			Il2CppObject * L_9 = V_2;
			Il2CppObject * L_10 = __this->get_client_context_sink_chain_5();
			Il2CppObject * L_11 = InterfaceFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.IContributeClientContextSink::GetClientContextSink(System.Runtime.Remoting.Messaging.IMessageSink) */, IContributeClientContextSink_t3409105893_il2cpp_TypeInfo_var, L_9, L_10);
			__this->set_client_context_sink_chain_5(L_11);
		}

IL_005e:
		{
			Il2CppObject * L_12 = V_1;
			bool L_13 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_12);
			if (L_13)
			{
				goto IL_0033;
			}
		}

IL_0069:
		{
			IL2CPP_LEAVE(0x80, FINALLY_006e);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_006e;
	}

FINALLY_006e:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_14 = V_1;
			V_3 = ((Il2CppObject *)IsInst(L_14, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_15 = V_3;
			if (L_15)
			{
				goto IL_0079;
			}
		}

IL_0078:
		{
			IL2CPP_END_FINALLY(110)
		}

IL_0079:
		{
			Il2CppObject * L_16 = V_3;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_16);
			IL2CPP_END_FINALLY(110)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(110)
	{
		IL2CPP_JUMP_TBL(0x80, IL_0080)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0080:
	{
		Il2CppObject * L_17 = __this->get_client_context_sink_chain_5();
		return L_17;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.Context::CreateServerObjectSinkChain(System.MarshalByRefObject,System.Boolean)
extern Il2CppClass* StackBuilderSink_t1613771438_il2cpp_TypeInfo_var;
extern Il2CppClass* ServerObjectTerminatorSink_t4261369100_il2cpp_TypeInfo_var;
extern Il2CppClass* LeaseSink_t3007073869_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* IContributeObjectSink_t2326363786_il2cpp_TypeInfo_var;
extern const uint32_t Context_CreateServerObjectSinkChain_m1085388208_MetadataUsageId;
extern "C"  Il2CppObject * Context_CreateServerObjectSinkChain_m1085388208 (Context_t502196753 * __this, MarshalByRefObject_t1285298191 * ___obj0, bool ___forceInternalExecute1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_CreateServerObjectSinkChain_m1085388208_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	int32_t V_1 = 0;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	{
		MarshalByRefObject_t1285298191 * L_0 = ___obj0;
		bool L_1 = ___forceInternalExecute1;
		StackBuilderSink_t1613771438 * L_2 = (StackBuilderSink_t1613771438 *)il2cpp_codegen_object_new(StackBuilderSink_t1613771438_il2cpp_TypeInfo_var);
		StackBuilderSink__ctor_m3726324009(L_2, L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		Il2CppObject * L_3 = V_0;
		ServerObjectTerminatorSink_t4261369100 * L_4 = (ServerObjectTerminatorSink_t4261369100 *)il2cpp_codegen_object_new(ServerObjectTerminatorSink_t4261369100_il2cpp_TypeInfo_var);
		ServerObjectTerminatorSink__ctor_m3076939583(L_4, L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		Il2CppObject * L_5 = V_0;
		LeaseSink_t3007073869 * L_6 = (LeaseSink_t3007073869 *)il2cpp_codegen_object_new(LeaseSink_t3007073869_il2cpp_TypeInfo_var);
		LeaseSink__ctor_m295312109(L_6, L_5, /*hidden argument*/NULL);
		V_0 = L_6;
		ArrayList_t4252133567 * L_7 = __this->get_context_properties_7();
		if (!L_7)
		{
			goto IL_0067;
		}
	}
	{
		ArrayList_t4252133567 * L_8 = __this->get_context_properties_7();
		int32_t L_9 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_8);
		V_1 = ((int32_t)((int32_t)L_9-(int32_t)1));
		goto IL_0060;
	}

IL_0034:
	{
		ArrayList_t4252133567 * L_10 = __this->get_context_properties_7();
		int32_t L_11 = V_1;
		Il2CppObject * L_12 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_10, L_11);
		V_2 = ((Il2CppObject *)Castclass(L_12, IContextProperty_t287246399_il2cpp_TypeInfo_var));
		Il2CppObject * L_13 = V_2;
		V_3 = ((Il2CppObject *)IsInst(L_13, IContributeObjectSink_t2326363786_il2cpp_TypeInfo_var));
		Il2CppObject * L_14 = V_3;
		if (!L_14)
		{
			goto IL_005c;
		}
	}
	{
		Il2CppObject * L_15 = V_3;
		MarshalByRefObject_t1285298191 * L_16 = ___obj0;
		Il2CppObject * L_17 = V_0;
		Il2CppObject * L_18 = InterfaceFuncInvoker2< Il2CppObject *, MarshalByRefObject_t1285298191 *, Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.IContributeObjectSink::GetObjectSink(System.MarshalByRefObject,System.Runtime.Remoting.Messaging.IMessageSink) */, IContributeObjectSink_t2326363786_il2cpp_TypeInfo_var, L_15, L_16, L_17);
		V_0 = L_18;
	}

IL_005c:
	{
		int32_t L_19 = V_1;
		V_1 = ((int32_t)((int32_t)L_19-(int32_t)1));
	}

IL_0060:
	{
		int32_t L_20 = V_1;
		if ((((int32_t)L_20) >= ((int32_t)0)))
		{
			goto IL_0034;
		}
	}

IL_0067:
	{
		Il2CppObject * L_21 = V_0;
		return L_21;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.Context::CreateEnvoySink(System.MarshalByRefObject)
extern Il2CppClass* EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* IContributeEnvoySink_t4106549430_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t Context_CreateEnvoySink_m2626543427_MetadataUsageId;
extern "C"  Il2CppObject * Context_CreateEnvoySink_m2626543427 (Context_t502196753 * __this, MarshalByRefObject_t1285298191 * ___serverObject0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_CreateEnvoySink_m2626543427_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var);
		EnvoyTerminatorSink_t3043186997 * L_0 = ((EnvoyTerminatorSink_t3043186997_StaticFields*)EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var->static_fields)->get_Instance_0();
		V_0 = L_0;
		ArrayList_t4252133567 * L_1 = __this->get_context_properties_7();
		if (!L_1)
		{
			goto IL_0069;
		}
	}
	{
		ArrayList_t4252133567 * L_2 = __this->get_context_properties_7();
		Il2CppObject * L_3 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_2);
		V_2 = L_3;
	}

IL_001d:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0044;
		}

IL_0022:
		{
			Il2CppObject * L_4 = V_2;
			Il2CppObject * L_5 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_4);
			V_1 = ((Il2CppObject *)Castclass(L_5, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Il2CppObject * L_6 = V_1;
			V_3 = ((Il2CppObject *)IsInst(L_6, IContributeEnvoySink_t4106549430_il2cpp_TypeInfo_var));
			Il2CppObject * L_7 = V_3;
			if (!L_7)
			{
				goto IL_0044;
			}
		}

IL_003b:
		{
			Il2CppObject * L_8 = V_3;
			MarshalByRefObject_t1285298191 * L_9 = ___serverObject0;
			Il2CppObject * L_10 = V_0;
			Il2CppObject * L_11 = InterfaceFuncInvoker2< Il2CppObject *, MarshalByRefObject_t1285298191 *, Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.IContributeEnvoySink::GetEnvoySink(System.MarshalByRefObject,System.Runtime.Remoting.Messaging.IMessageSink) */, IContributeEnvoySink_t4106549430_il2cpp_TypeInfo_var, L_8, L_9, L_10);
			V_0 = L_11;
		}

IL_0044:
		{
			Il2CppObject * L_12 = V_2;
			bool L_13 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_12);
			if (L_13)
			{
				goto IL_0022;
			}
		}

IL_004f:
		{
			IL2CPP_LEAVE(0x69, FINALLY_0054);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0054;
	}

FINALLY_0054:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_14 = V_2;
			V_4 = ((Il2CppObject *)IsInst(L_14, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_15 = V_4;
			if (L_15)
			{
				goto IL_0061;
			}
		}

IL_0060:
		{
			IL2CPP_END_FINALLY(84)
		}

IL_0061:
		{
			Il2CppObject * L_16 = V_4;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_16);
			IL2CPP_END_FINALLY(84)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(84)
	{
		IL2CPP_JUMP_TBL(0x69, IL_0069)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0069:
	{
		Il2CppObject * L_17 = V_0;
		return L_17;
	}
}
// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Contexts.Context::SwitchToContext(System.Runtime.Remoting.Contexts.Context)
extern "C"  Context_t502196753 * Context_SwitchToContext_m3368914854 (Il2CppObject * __this /* static, unused */, Context_t502196753 * ___newContext0, const MethodInfo* method)
{
	{
		Context_t502196753 * L_0 = ___newContext0;
		Context_t502196753 * L_1 = AppDomain_InternalSetContext_m1264487503(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Runtime.Remoting.Contexts.Context System.Runtime.Remoting.Contexts.Context::CreateNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerable_t2911409499_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* IContextProperty_t287246399_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2057921776;
extern const uint32_t Context_CreateNewContext_m538209045_MetadataUsageId;
extern "C"  Context_t502196753 * Context_CreateNewContext_m538209045 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___msg0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_CreateNewContext_m538209045_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Context_t502196753 * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Context_t502196753 * L_0 = (Context_t502196753 *)il2cpp_codegen_object_new(Context_t502196753_il2cpp_TypeInfo_var);
		Context__ctor_m3303382579(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		Il2CppObject * L_1 = ___msg0;
		Il2CppObject * L_2 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Collections.IList System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ContextProperties() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, L_1);
		Il2CppObject * L_3 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Collections.IEnumerator System.Collections.IEnumerable::GetEnumerator() */, IEnumerable_t2911409499_il2cpp_TypeInfo_var, L_2);
		V_2 = L_3;
	}

IL_0012:
	try
	{ // begin try (depth: 1)
		{
			goto IL_003b;
		}

IL_0017:
		{
			Il2CppObject * L_4 = V_2;
			Il2CppObject * L_5 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_4);
			V_1 = ((Il2CppObject *)Castclass(L_5, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Context_t502196753 * L_6 = V_0;
			Il2CppObject * L_7 = V_1;
			String_t* L_8 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Contexts.IContextProperty::get_Name() */, IContextProperty_t287246399_il2cpp_TypeInfo_var, L_7);
			Il2CppObject * L_9 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(6 /* System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String) */, L_6, L_8);
			if (L_9)
			{
				goto IL_003b;
			}
		}

IL_0034:
		{
			Context_t502196753 * L_10 = V_0;
			Il2CppObject * L_11 = V_1;
			VirtActionInvoker1< Il2CppObject * >::Invoke(7 /* System.Void System.Runtime.Remoting.Contexts.Context::SetProperty(System.Runtime.Remoting.Contexts.IContextProperty) */, L_10, L_11);
		}

IL_003b:
		{
			Il2CppObject * L_12 = V_2;
			bool L_13 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_12);
			if (L_13)
			{
				goto IL_0017;
			}
		}

IL_0046:
		{
			IL2CPP_LEAVE(0x60, FINALLY_004b);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_004b;
	}

FINALLY_004b:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_14 = V_2;
			V_5 = ((Il2CppObject *)IsInst(L_14, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_15 = V_5;
			if (L_15)
			{
				goto IL_0058;
			}
		}

IL_0057:
		{
			IL2CPP_END_FINALLY(75)
		}

IL_0058:
		{
			Il2CppObject * L_16 = V_5;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_16);
			IL2CPP_END_FINALLY(75)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(75)
	{
		IL2CPP_JUMP_TBL(0x60, IL_0060)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0060:
	{
		Context_t502196753 * L_17 = V_0;
		VirtActionInvoker0::Invoke(8 /* System.Void System.Runtime.Remoting.Contexts.Context::Freeze() */, L_17);
		Il2CppObject * L_18 = ___msg0;
		Il2CppObject * L_19 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Collections.IList System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ContextProperties() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, L_18);
		Il2CppObject * L_20 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Collections.IEnumerator System.Collections.IEnumerable::GetEnumerator() */, IEnumerable_t2911409499_il2cpp_TypeInfo_var, L_19);
		V_4 = L_20;
	}

IL_0073:
	try
	{ // begin try (depth: 1)
		{
			goto IL_009c;
		}

IL_0078:
		{
			Il2CppObject * L_21 = V_4;
			Il2CppObject * L_22 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_21);
			V_3 = ((Il2CppObject *)Castclass(L_22, IContextProperty_t287246399_il2cpp_TypeInfo_var));
			Il2CppObject * L_23 = V_3;
			Context_t502196753 * L_24 = V_0;
			bool L_25 = InterfaceFuncInvoker1< bool, Context_t502196753 * >::Invoke(2 /* System.Boolean System.Runtime.Remoting.Contexts.IContextProperty::IsNewContextOK(System.Runtime.Remoting.Contexts.Context) */, IContextProperty_t287246399_il2cpp_TypeInfo_var, L_23, L_24);
			if (L_25)
			{
				goto IL_009c;
			}
		}

IL_0091:
		{
			RemotingException_t109604560 * L_26 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3568495070(L_26, _stringLiteral2057921776, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_26);
		}

IL_009c:
		{
			Il2CppObject * L_27 = V_4;
			bool L_28 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_27);
			if (L_28)
			{
				goto IL_0078;
			}
		}

IL_00a8:
		{
			IL2CPP_LEAVE(0xC3, FINALLY_00ad);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00ad;
	}

FINALLY_00ad:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_29 = V_4;
			V_6 = ((Il2CppObject *)IsInst(L_29, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_30 = V_6;
			if (L_30)
			{
				goto IL_00bb;
			}
		}

IL_00ba:
		{
			IL2CPP_END_FINALLY(173)
		}

IL_00bb:
		{
			Il2CppObject * L_31 = V_6;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_31);
			IL2CPP_END_FINALLY(173)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(173)
	{
		IL2CPP_JUMP_TBL(0xC3, IL_00c3)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00c3:
	{
		Context_t502196753 * L_32 = V_0;
		return L_32;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::DoCallBack(System.Runtime.Remoting.Contexts.CrossContextDelegate)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* ContextCallbackObject_t3978189709_il2cpp_TypeInfo_var;
extern const uint32_t Context_DoCallBack_m1158598055_MetadataUsageId;
extern "C"  void Context_DoCallBack_m1158598055 (Context_t502196753 * __this, CrossContextDelegate_t754146990 * ___deleg0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_DoCallBack_m1158598055_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Context_t502196753 * V_0 = NULL;
	Context_t502196753 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		Context_t502196753 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			ContextCallbackObject_t3978189709 * L_1 = __this->get_callback_object_13();
			if (L_1)
			{
				goto IL_002c;
			}
		}

IL_0013:
		{
			IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
			Context_t502196753 * L_2 = Context_SwitchToContext_m3368914854(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
			V_1 = L_2;
			ContextCallbackObject_t3978189709 * L_3 = (ContextCallbackObject_t3978189709 *)il2cpp_codegen_object_new(ContextCallbackObject_t3978189709_il2cpp_TypeInfo_var);
			ContextCallbackObject__ctor_m643700319(L_3, /*hidden argument*/NULL);
			__this->set_callback_object_13(L_3);
			Context_t502196753 * L_4 = V_1;
			Context_SwitchToContext_m3368914854(NULL /*static, unused*/, L_4, /*hidden argument*/NULL);
		}

IL_002c:
		{
			IL2CPP_LEAVE(0x38, FINALLY_0031);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0031;
	}

FINALLY_0031:
	{ // begin finally (depth: 1)
		Context_t502196753 * L_5 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_5, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(49)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(49)
	{
		IL2CPP_JUMP_TBL(0x38, IL_0038)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0038:
	{
		ContextCallbackObject_t3978189709 * L_6 = __this->get_callback_object_13();
		CrossContextDelegate_t754146990 * L_7 = ___deleg0;
		ContextCallbackObject_DoCallBack_m2074821203(L_6, L_7, /*hidden argument*/NULL);
		return;
	}
}
// System.LocalDataStoreSlot System.Runtime.Remoting.Contexts.Context::AllocateDataSlot()
extern Il2CppClass* LocalDataStoreSlot_t486331200_il2cpp_TypeInfo_var;
extern const uint32_t Context_AllocateDataSlot_m2880663534_MetadataUsageId;
extern "C"  LocalDataStoreSlot_t486331200 * Context_AllocateDataSlot_m2880663534 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_AllocateDataSlot_m2880663534_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		LocalDataStoreSlot_t486331200 * L_0 = (LocalDataStoreSlot_t486331200 *)il2cpp_codegen_object_new(LocalDataStoreSlot_t486331200_il2cpp_TypeInfo_var);
		LocalDataStoreSlot__ctor_m3632793016(L_0, (bool)0, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.LocalDataStoreSlot System.Runtime.Remoting.Contexts.Context::AllocateNamedDataSlot(System.String)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_AllocateNamedDataSlot_m3200404053_MetadataUsageId;
extern "C"  LocalDataStoreSlot_t486331200 * Context_AllocateNamedDataSlot_m3200404053 (Il2CppObject * __this /* static, unused */, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_AllocateNamedDataSlot_m3200404053_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	LocalDataStoreSlot_t486331200 * V_1 = NULL;
	LocalDataStoreSlot_t486331200 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_0 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(19 /* System.Object System.Collections.Hashtable::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0011:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
			LocalDataStoreSlot_t486331200 * L_3 = Context_AllocateDataSlot_m2880663534(NULL /*static, unused*/, /*hidden argument*/NULL);
			V_1 = L_3;
			Hashtable_t909839986 * L_4 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
			String_t* L_5 = ___name0;
			LocalDataStoreSlot_t486331200 * L_6 = V_1;
			VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(25 /* System.Void System.Collections.Hashtable::Add(System.Object,System.Object) */, L_4, L_5, L_6);
			LocalDataStoreSlot_t486331200 * L_7 = V_1;
			V_2 = L_7;
			IL2CPP_LEAVE(0x36, FINALLY_002f);
		}

IL_002a:
		{
			; // IL_002a: leave IL_0036
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_002f;
	}

FINALLY_002f:
	{ // begin finally (depth: 1)
		Il2CppObject * L_8 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_8, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(47)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(47)
	{
		IL2CPP_JUMP_TBL(0x36, IL_0036)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0036:
	{
		LocalDataStoreSlot_t486331200 * L_9 = V_2;
		return L_9;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::FreeNamedDataSlot(System.String)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern const uint32_t Context_FreeNamedDataSlot_m3938279346_MetadataUsageId;
extern "C"  void Context_FreeNamedDataSlot_m3938279346 (Il2CppObject * __this /* static, unused */, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_FreeNamedDataSlot_m3938279346_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_0 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(19 /* System.Object System.Collections.Hashtable::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0011:
	try
	{ // begin try (depth: 1)
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_3 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
		String_t* L_4 = ___name0;
		VirtActionInvoker1< Il2CppObject * >::Invoke(29 /* System.Void System.Collections.Hashtable::Remove(System.Object) */, L_3, L_4);
		IL2CPP_LEAVE(0x28, FINALLY_0021);
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0021;
	}

FINALLY_0021:
	{ // begin finally (depth: 1)
		Il2CppObject * L_5 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_5, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(33)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(33)
	{
		IL2CPP_JUMP_TBL(0x28, IL_0028)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0028:
	{
		return;
	}
}
// System.Object System.Runtime.Remoting.Contexts.Context::GetData(System.LocalDataStoreSlot)
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern const uint32_t Context_GetData_m3976523785_MetadataUsageId;
extern "C"  Il2CppObject * Context_GetData_m3976523785 (Il2CppObject * __this /* static, unused */, LocalDataStoreSlot_t486331200 * ___slot0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetData_m3976523785_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Context_t502196753 * V_0 = NULL;
	Context_t502196753 * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_0 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		V_0 = L_0;
		Context_t502196753 * L_1 = V_0;
		V_1 = L_1;
		Context_t502196753 * L_2 = V_1;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			Context_t502196753 * L_3 = V_0;
			ObjectU5BU5D_t3614634134* L_4 = L_3->get_datastore_6();
			if (!L_4)
			{
				goto IL_003f;
			}
		}

IL_0019:
		{
			LocalDataStoreSlot_t486331200 * L_5 = ___slot0;
			int32_t L_6 = L_5->get_slot_0();
			Context_t502196753 * L_7 = V_0;
			ObjectU5BU5D_t3614634134* L_8 = L_7->get_datastore_6();
			if ((((int32_t)L_6) >= ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_8)->max_length)))))))
			{
				goto IL_003f;
			}
		}

IL_002c:
		{
			Context_t502196753 * L_9 = V_0;
			ObjectU5BU5D_t3614634134* L_10 = L_9->get_datastore_6();
			LocalDataStoreSlot_t486331200 * L_11 = ___slot0;
			int32_t L_12 = L_11->get_slot_0();
			int32_t L_13 = L_12;
			Il2CppObject * L_14 = (L_10)->GetAt(static_cast<il2cpp_array_size_t>(L_13));
			V_2 = L_14;
			IL2CPP_LEAVE(0x52, FINALLY_004b);
		}

IL_003f:
		{
			V_2 = NULL;
			IL2CPP_LEAVE(0x52, FINALLY_004b);
		}

IL_0046:
		{
			; // IL_0046: leave IL_0052
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_004b;
	}

FINALLY_004b:
	{ // begin finally (depth: 1)
		Context_t502196753 * L_15 = V_1;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_15, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(75)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(75)
	{
		IL2CPP_JUMP_TBL(0x52, IL_0052)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0052:
	{
		Il2CppObject * L_16 = V_2;
		return L_16;
	}
}
// System.LocalDataStoreSlot System.Runtime.Remoting.Contexts.Context::GetNamedDataSlot(System.String)
extern Il2CppClass* Context_t502196753_il2cpp_TypeInfo_var;
extern Il2CppClass* LocalDataStoreSlot_t486331200_il2cpp_TypeInfo_var;
extern const uint32_t Context_GetNamedDataSlot_m372993642_MetadataUsageId;
extern "C"  LocalDataStoreSlot_t486331200 * Context_GetNamedDataSlot_m372993642 (Il2CppObject * __this /* static, unused */, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_GetNamedDataSlot_m372993642_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	LocalDataStoreSlot_t486331200 * V_1 = NULL;
	LocalDataStoreSlot_t486331200 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_0 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(19 /* System.Object System.Collections.Hashtable::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0011:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_3 = ((Context_t502196753_StaticFields*)Context_t502196753_il2cpp_TypeInfo_var->static_fields)->get_namedSlots_10();
			String_t* L_4 = ___name0;
			Il2CppObject * L_5 = VirtFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(22 /* System.Object System.Collections.Hashtable::get_Item(System.Object) */, L_3, L_4);
			V_1 = ((LocalDataStoreSlot_t486331200 *)IsInstSealed(L_5, LocalDataStoreSlot_t486331200_il2cpp_TypeInfo_var));
			LocalDataStoreSlot_t486331200 * L_6 = V_1;
			if (L_6)
			{
				goto IL_0034;
			}
		}

IL_0028:
		{
			String_t* L_7 = ___name0;
			IL2CPP_RUNTIME_CLASS_INIT(Context_t502196753_il2cpp_TypeInfo_var);
			LocalDataStoreSlot_t486331200 * L_8 = Context_AllocateNamedDataSlot_m3200404053(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
			V_2 = L_8;
			IL2CPP_LEAVE(0x47, FINALLY_0040);
		}

IL_0034:
		{
			LocalDataStoreSlot_t486331200 * L_9 = V_1;
			V_2 = L_9;
			IL2CPP_LEAVE(0x47, FINALLY_0040);
		}

IL_003b:
		{
			; // IL_003b: leave IL_0047
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0040;
	}

FINALLY_0040:
	{ // begin finally (depth: 1)
		Il2CppObject * L_10 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_10, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(64)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(64)
	{
		IL2CPP_JUMP_TBL(0x47, IL_0047)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0047:
	{
		LocalDataStoreSlot_t486331200 * L_11 = V_2;
		return L_11;
	}
}
// System.Void System.Runtime.Remoting.Contexts.Context::SetData(System.LocalDataStoreSlot,System.Object)
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t Context_SetData_m4115952818_MetadataUsageId;
extern "C"  void Context_SetData_m4115952818 (Il2CppObject * __this /* static, unused */, LocalDataStoreSlot_t486331200 * ___slot0, Il2CppObject * ___data1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Context_SetData_m4115952818_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Context_t502196753 * V_0 = NULL;
	Context_t502196753 * V_1 = NULL;
	ObjectU5BU5D_t3614634134* V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_0 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		V_0 = L_0;
		Context_t502196753 * L_1 = V_0;
		V_1 = L_1;
		Context_t502196753 * L_2 = V_1;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_000e:
	try
	{ // begin try (depth: 1)
		{
			Context_t502196753 * L_3 = V_0;
			ObjectU5BU5D_t3614634134* L_4 = L_3->get_datastore_6();
			if (L_4)
			{
				goto IL_0031;
			}
		}

IL_0019:
		{
			Context_t502196753 * L_5 = V_0;
			LocalDataStoreSlot_t486331200 * L_6 = ___slot0;
			int32_t L_7 = L_6->get_slot_0();
			L_5->set_datastore_6(((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)L_7+(int32_t)2)))));
			goto IL_0066;
		}

IL_0031:
		{
			LocalDataStoreSlot_t486331200 * L_8 = ___slot0;
			int32_t L_9 = L_8->get_slot_0();
			Context_t502196753 * L_10 = V_0;
			ObjectU5BU5D_t3614634134* L_11 = L_10->get_datastore_6();
			if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
			{
				goto IL_0066;
			}
		}

IL_0044:
		{
			LocalDataStoreSlot_t486331200 * L_12 = ___slot0;
			int32_t L_13 = L_12->get_slot_0();
			V_2 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)((int32_t)((int32_t)L_13+(int32_t)2))));
			Context_t502196753 * L_14 = V_0;
			ObjectU5BU5D_t3614634134* L_15 = L_14->get_datastore_6();
			ObjectU5BU5D_t3614634134* L_16 = V_2;
			Array_CopyTo_m4061033315((Il2CppArray *)(Il2CppArray *)L_15, (Il2CppArray *)(Il2CppArray *)L_16, 0, /*hidden argument*/NULL);
			Context_t502196753 * L_17 = V_0;
			ObjectU5BU5D_t3614634134* L_18 = V_2;
			L_17->set_datastore_6(L_18);
		}

IL_0066:
		{
			Context_t502196753 * L_19 = V_0;
			ObjectU5BU5D_t3614634134* L_20 = L_19->get_datastore_6();
			LocalDataStoreSlot_t486331200 * L_21 = ___slot0;
			int32_t L_22 = L_21->get_slot_0();
			Il2CppObject * L_23 = ___data1;
			ArrayElementTypeCheck (L_20, L_23);
			(L_20)->SetAt(static_cast<il2cpp_array_size_t>(L_22), (Il2CppObject *)L_23);
			IL2CPP_LEAVE(0x80, FINALLY_0079);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0079;
	}

FINALLY_0079:
	{ // begin finally (depth: 1)
		Context_t502196753 * L_24 = V_1;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_24, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(121)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(121)
	{
		IL2CPP_JUMP_TBL(0x80, IL_0080)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0080:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.ContextAttribute::.ctor(System.String)
extern "C"  void ContextAttribute__ctor_m4006843177 (ContextAttribute_t197102333 * __this, String_t* ___name0, const MethodInfo* method)
{
	{
		Attribute__ctor_m1730479323(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___name0;
		__this->set_AttributeName_0(L_0);
		return;
	}
}
// System.String System.Runtime.Remoting.Contexts.ContextAttribute::get_Name()
extern "C"  String_t* ContextAttribute_get_Name_m2899769254 (ContextAttribute_t197102333 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_AttributeName_0();
		return L_0;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.ContextAttribute::Equals(System.Object)
extern Il2CppClass* ContextAttribute_t197102333_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t ContextAttribute_Equals_m53324298_MetadataUsageId;
extern "C"  bool ContextAttribute_Equals_m53324298 (ContextAttribute_t197102333 * __this, Il2CppObject * ___o0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ContextAttribute_Equals_m53324298_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ContextAttribute_t197102333 * V_0 = NULL;
	{
		Il2CppObject * L_0 = ___o0;
		if (L_0)
		{
			goto IL_0008;
		}
	}
	{
		return (bool)0;
	}

IL_0008:
	{
		Il2CppObject * L_1 = ___o0;
		if (((ContextAttribute_t197102333 *)IsInstClass(L_1, ContextAttribute_t197102333_il2cpp_TypeInfo_var)))
		{
			goto IL_0015;
		}
	}
	{
		return (bool)0;
	}

IL_0015:
	{
		Il2CppObject * L_2 = ___o0;
		V_0 = ((ContextAttribute_t197102333 *)CastclassClass(L_2, ContextAttribute_t197102333_il2cpp_TypeInfo_var));
		ContextAttribute_t197102333 * L_3 = V_0;
		String_t* L_4 = L_3->get_AttributeName_0();
		String_t* L_5 = __this->get_AttributeName_0();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Inequality_m304203149(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0034;
		}
	}
	{
		return (bool)0;
	}

IL_0034:
	{
		return (bool)1;
	}
}
// System.Void System.Runtime.Remoting.Contexts.ContextAttribute::Freeze(System.Runtime.Remoting.Contexts.Context)
extern "C"  void ContextAttribute_Freeze_m4133346275 (ContextAttribute_t197102333 * __this, Context_t502196753 * ___newContext0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Int32 System.Runtime.Remoting.Contexts.ContextAttribute::GetHashCode()
extern "C"  int32_t ContextAttribute_GetHashCode_m3646968314 (ContextAttribute_t197102333 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_AttributeName_0();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return 0;
	}

IL_000d:
	{
		String_t* L_1 = __this->get_AttributeName_0();
		int32_t L_2 = String_GetHashCode_m931956593(L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// System.Void System.Runtime.Remoting.Contexts.ContextAttribute::GetPropertiesForNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_t3321498491_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3007101043;
extern const uint32_t ContextAttribute_GetPropertiesForNewContext_m4007241045_MetadataUsageId;
extern "C"  void ContextAttribute_GetPropertiesForNewContext_m4007241045 (ContextAttribute_t197102333 * __this, Il2CppObject * ___ctorMsg0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ContextAttribute_GetPropertiesForNewContext_m4007241045_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	{
		Il2CppObject * L_0 = ___ctorMsg0;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral3007101043, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		Il2CppObject * L_2 = ___ctorMsg0;
		Il2CppObject * L_3 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Collections.IList System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ContextProperties() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, L_2);
		V_0 = L_3;
		Il2CppObject * L_4 = V_0;
		InterfaceFuncInvoker1< int32_t, Il2CppObject * >::Invoke(4 /* System.Int32 System.Collections.IList::Add(System.Object) */, IList_t3321498491_il2cpp_TypeInfo_var, L_4, __this);
		return;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.ContextAttribute::IsContextOK(System.Runtime.Remoting.Contexts.Context,System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* ArgumentNullException_t628810857_il2cpp_TypeInfo_var;
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3007101043;
extern Il2CppCodeGenString* _stringLiteral3875251571;
extern const uint32_t ContextAttribute_IsContextOK_m3281216012_MetadataUsageId;
extern "C"  bool ContextAttribute_IsContextOK_m3281216012 (ContextAttribute_t197102333 * __this, Context_t502196753 * ___ctx0, Il2CppObject * ___ctorMsg1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ContextAttribute_IsContextOK_m3281216012_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	{
		Il2CppObject * L_0 = ___ctorMsg1;
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		ArgumentNullException_t628810857 * L_1 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_1, _stringLiteral3007101043, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1);
	}

IL_0011:
	{
		Context_t502196753 * L_2 = ___ctx0;
		if (L_2)
		{
			goto IL_0022;
		}
	}
	{
		ArgumentNullException_t628810857 * L_3 = (ArgumentNullException_t628810857 *)il2cpp_codegen_object_new(ArgumentNullException_t628810857_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_m3380712306(L_3, _stringLiteral3875251571, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_3);
	}

IL_0022:
	{
		Il2CppObject * L_4 = ___ctorMsg1;
		Type_t * L_5 = InterfaceFuncInvoker0< Type_t * >::Invoke(0 /* System.Type System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ActivationType() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, L_4);
		bool L_6 = Type_get_IsContextful_m1542685486(L_5, /*hidden argument*/NULL);
		if (L_6)
		{
			goto IL_0034;
		}
	}
	{
		return (bool)1;
	}

IL_0034:
	{
		Context_t502196753 * L_7 = ___ctx0;
		String_t* L_8 = __this->get_AttributeName_0();
		Il2CppObject * L_9 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(6 /* System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String) */, L_7, L_8);
		V_0 = L_9;
		Il2CppObject * L_10 = V_0;
		if (L_10)
		{
			goto IL_0049;
		}
	}
	{
		return (bool)0;
	}

IL_0049:
	{
		Il2CppObject * L_11 = V_0;
		if ((((Il2CppObject*)(ContextAttribute_t197102333 *)__this) == ((Il2CppObject*)(Il2CppObject *)L_11)))
		{
			goto IL_0052;
		}
	}
	{
		return (bool)0;
	}

IL_0052:
	{
		return (bool)1;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.ContextAttribute::IsNewContextOK(System.Runtime.Remoting.Contexts.Context)
extern "C"  bool ContextAttribute_IsNewContextOK_m2186905629 (ContextAttribute_t197102333 * __this, Context_t502196753 * ___newCtx0, const MethodInfo* method)
{
	{
		return (bool)1;
	}
}
// System.Void System.Runtime.Remoting.Contexts.ContextCallbackObject::.ctor()
extern "C"  void ContextCallbackObject__ctor_m643700319 (ContextCallbackObject_t3978189709 * __this, const MethodInfo* method)
{
	{
		ContextBoundObject__ctor_m315654911(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.ContextCallbackObject::DoCallBack(System.Runtime.Remoting.Contexts.CrossContextDelegate)
extern "C"  void ContextCallbackObject_DoCallBack_m2074821203 (ContextCallbackObject_t3978189709 * __this, CrossContextDelegate_t754146990 * ___deleg0, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.CrossContextChannel::.ctor()
extern "C"  void CrossContextChannel__ctor_m2991342036 (CrossContextChannel_t2302426108 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.CrossContextDelegate::.ctor(System.Object,System.IntPtr)
extern "C"  void CrossContextDelegate__ctor_m4092400948 (CrossContextDelegate_t754146990 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void System.Runtime.Remoting.Contexts.CrossContextDelegate::Invoke()
extern "C"  void CrossContextDelegate_Invoke_m2908136830 (CrossContextDelegate_t754146990 * __this, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		CrossContextDelegate_Invoke_m2908136830((CrossContextDelegate_t754146990 *)__this->get_prev_9(), method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if ((__this->get_m_target_2() != NULL || MethodHasParameters((MethodInfo*)(__this->get_method_3().get_m_value_0()))) && ___methodIsStatic)
	{
		typedef void (*FunctionPointerType) (Il2CppObject *, void* __this, const MethodInfo* method);
		((FunctionPointerType)__this->get_method_ptr_0())(NULL,il2cpp_codegen_get_delegate_this(__this),(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef void (*FunctionPointerType) (void* __this, const MethodInfo* method);
		((FunctionPointerType)__this->get_method_ptr_0())(il2cpp_codegen_get_delegate_this(__this),(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
extern "C"  void DelegatePInvokeWrapper_CrossContextDelegate_t754146990 (CrossContextDelegate_t754146990 * __this, const MethodInfo* method)
{
	typedef void (STDCALL *PInvokeFunc)();
	PInvokeFunc il2cppPInvokeFunc = reinterpret_cast<PInvokeFunc>(((Il2CppDelegate*)__this)->method->methodPointer);

	// Native function invocation
	il2cppPInvokeFunc();

}
// System.IAsyncResult System.Runtime.Remoting.Contexts.CrossContextDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * CrossContextDelegate_BeginInvoke_m4129562277 (CrossContextDelegate_t754146990 * __this, AsyncCallback_t163412349 * ___callback0, Il2CppObject * ___object1, const MethodInfo* method)
{
	void *__d_args[1] = {0};
	return (Il2CppObject *)il2cpp_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback0, (Il2CppObject*)___object1);
}
// System.Void System.Runtime.Remoting.Contexts.CrossContextDelegate::EndInvoke(System.IAsyncResult)
extern "C"  void CrossContextDelegate_EndInvoke_m3043989850 (CrossContextDelegate_t754146990 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	il2cpp_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
// System.Void System.Runtime.Remoting.Contexts.DynamicPropertyCollection::.ctor()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t DynamicPropertyCollection__ctor_m1159577654_MetadataUsageId;
extern "C"  void DynamicPropertyCollection__ctor_m1159577654 (DynamicPropertyCollection_t2282532998 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DynamicPropertyCollection__ctor_m1159577654_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		__this->set__properties_0(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.DynamicPropertyCollection::get_HasProperties()
extern "C"  bool DynamicPropertyCollection_get_HasProperties_m2092159924 (DynamicPropertyCollection_t2282532998 * __this, const MethodInfo* method)
{
	{
		ArrayList_t4252133567 * L_0 = __this->get__properties_0();
		int32_t L_1 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_0);
		return (bool)((((int32_t)L_1) > ((int32_t)0))? 1 : 0);
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.DynamicPropertyCollection::RegisterDynamicProperty(System.Runtime.Remoting.Contexts.IDynamicProperty)
extern Il2CppClass* IDynamicProperty_t603529997_il2cpp_TypeInfo_var;
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var;
extern Il2CppClass* IContributeDynamicSink_t486956128_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4122577144;
extern const uint32_t DynamicPropertyCollection_RegisterDynamicProperty_m3083838256_MetadataUsageId;
extern "C"  bool DynamicPropertyCollection_RegisterDynamicProperty_m3083838256 (DynamicPropertyCollection_t2282532998 * __this, Il2CppObject * ___prop0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DynamicPropertyCollection_RegisterDynamicProperty_m3083838256_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DynamicPropertyCollection_t2282532998 * V_0 = NULL;
	ArrayList_t4252133567 * V_1 = NULL;
	DynamicPropertyReg_t1839195831 * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	bool V_4 = false;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		DynamicPropertyCollection_t2282532998 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			Il2CppObject * L_1 = ___prop0;
			String_t* L_2 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Contexts.IDynamicProperty::get_Name() */, IDynamicProperty_t603529997_il2cpp_TypeInfo_var, L_1);
			int32_t L_3 = DynamicPropertyCollection_FindProperty_m1233265924(__this, L_2, /*hidden argument*/NULL);
			if ((((int32_t)L_3) == ((int32_t)(-1))))
			{
				goto IL_0025;
			}
		}

IL_001a:
		{
			InvalidOperationException_t721527559 * L_4 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
			InvalidOperationException__ctor_m2801133788(L_4, _stringLiteral4122577144, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_4);
		}

IL_0025:
		{
			ArrayList_t4252133567 * L_5 = __this->get__properties_0();
			ArrayList_t4252133567 * L_6 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
			ArrayList__ctor_m194094802(L_6, L_5, /*hidden argument*/NULL);
			V_1 = L_6;
			DynamicPropertyReg_t1839195831 * L_7 = (DynamicPropertyReg_t1839195831 *)il2cpp_codegen_object_new(DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var);
			DynamicPropertyReg__ctor_m750943241(L_7, /*hidden argument*/NULL);
			V_2 = L_7;
			DynamicPropertyReg_t1839195831 * L_8 = V_2;
			Il2CppObject * L_9 = ___prop0;
			L_8->set_Property_0(L_9);
			Il2CppObject * L_10 = ___prop0;
			V_3 = ((Il2CppObject *)IsInst(L_10, IContributeDynamicSink_t486956128_il2cpp_TypeInfo_var));
			Il2CppObject * L_11 = V_3;
			if (!L_11)
			{
				goto IL_0057;
			}
		}

IL_004b:
		{
			DynamicPropertyReg_t1839195831 * L_12 = V_2;
			Il2CppObject * L_13 = V_3;
			Il2CppObject * L_14 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Runtime.Remoting.Contexts.IDynamicMessageSink System.Runtime.Remoting.Contexts.IContributeDynamicSink::GetDynamicSink() */, IContributeDynamicSink_t486956128_il2cpp_TypeInfo_var, L_13);
			L_12->set_Sink_1(L_14);
		}

IL_0057:
		{
			ArrayList_t4252133567 * L_15 = V_1;
			DynamicPropertyReg_t1839195831 * L_16 = V_2;
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_15, L_16);
			ArrayList_t4252133567 * L_17 = V_1;
			__this->set__properties_0(L_17);
			V_4 = (bool)1;
			IL2CPP_LEAVE(0x7A, FINALLY_0073);
		}

IL_006e:
		{
			; // IL_006e: leave IL_007a
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0073;
	}

FINALLY_0073:
	{ // begin finally (depth: 1)
		DynamicPropertyCollection_t2282532998 * L_18 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_18, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(115)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(115)
	{
		IL2CPP_JUMP_TBL(0x7A, IL_007a)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_007a:
	{
		bool L_19 = V_4;
		return L_19;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.DynamicPropertyCollection::UnregisterDynamicProperty(System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral4003219272;
extern Il2CppCodeGenString* _stringLiteral3981451750;
extern const uint32_t DynamicPropertyCollection_UnregisterDynamicProperty_m432705250_MetadataUsageId;
extern "C"  bool DynamicPropertyCollection_UnregisterDynamicProperty_m432705250 (DynamicPropertyCollection_t2282532998 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DynamicPropertyCollection_UnregisterDynamicProperty_m432705250_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DynamicPropertyCollection_t2282532998 * V_0 = NULL;
	int32_t V_1 = 0;
	bool V_2 = false;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		DynamicPropertyCollection_t2282532998 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			String_t* L_1 = ___name0;
			int32_t L_2 = DynamicPropertyCollection_FindProperty_m1233265924(__this, L_1, /*hidden argument*/NULL);
			V_1 = L_2;
			int32_t L_3 = V_1;
			if ((!(((uint32_t)L_3) == ((uint32_t)(-1)))))
			{
				goto IL_002d;
			}
		}

IL_0017:
		{
			String_t* L_4 = ___name0;
			IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
			String_t* L_5 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral4003219272, L_4, _stringLiteral3981451750, /*hidden argument*/NULL);
			RemotingException_t109604560 * L_6 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
			RemotingException__ctor_m3568495070(L_6, L_5, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_6);
		}

IL_002d:
		{
			ArrayList_t4252133567 * L_7 = __this->get__properties_0();
			int32_t L_8 = V_1;
			VirtActionInvoker1< int32_t >::Invoke(39 /* System.Void System.Collections.ArrayList::RemoveAt(System.Int32) */, L_7, L_8);
			V_2 = (bool)1;
			IL2CPP_LEAVE(0x4C, FINALLY_0045);
		}

IL_0040:
		{
			; // IL_0040: leave IL_004c
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0045;
	}

FINALLY_0045:
	{ // begin finally (depth: 1)
		DynamicPropertyCollection_t2282532998 * L_9 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(69)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(69)
	{
		IL2CPP_JUMP_TBL(0x4C, IL_004c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_004c:
	{
		bool L_10 = V_2;
		return L_10;
	}
}
// System.Void System.Runtime.Remoting.Contexts.DynamicPropertyCollection::NotifyMessage(System.Boolean,System.Runtime.Remoting.Messaging.IMessage,System.Boolean,System.Boolean)
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var;
extern Il2CppClass* IDynamicMessageSink_t3056162262_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t DynamicPropertyCollection_NotifyMessage_m840388347_MetadataUsageId;
extern "C"  void DynamicPropertyCollection_NotifyMessage_m840388347 (DynamicPropertyCollection_t2282532998 * __this, bool ___start0, Il2CppObject * ___msg1, bool ___client_site2, bool ___async3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DynamicPropertyCollection_NotifyMessage_m840388347_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ArrayList_t4252133567 * V_0 = NULL;
	DynamicPropertyReg_t1839195831 * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	DynamicPropertyReg_t1839195831 * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Il2CppObject * V_5 = NULL;
	Il2CppObject * V_6 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = __this->get__properties_0();
		V_0 = L_0;
		bool L_1 = ___start0;
		if (!L_1)
		{
			goto IL_0069;
		}
	}
	{
		ArrayList_t4252133567 * L_2 = V_0;
		Il2CppObject * L_3 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_2);
		V_2 = L_3;
	}

IL_0014:
	try
	{ // begin try (depth: 1)
		{
			goto IL_003f;
		}

IL_0019:
		{
			Il2CppObject * L_4 = V_2;
			Il2CppObject * L_5 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_4);
			V_1 = ((DynamicPropertyReg_t1839195831 *)CastclassClass(L_5, DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var));
			DynamicPropertyReg_t1839195831 * L_6 = V_1;
			Il2CppObject * L_7 = L_6->get_Sink_1();
			if (!L_7)
			{
				goto IL_003f;
			}
		}

IL_0030:
		{
			DynamicPropertyReg_t1839195831 * L_8 = V_1;
			Il2CppObject * L_9 = L_8->get_Sink_1();
			Il2CppObject * L_10 = ___msg1;
			bool L_11 = ___client_site2;
			bool L_12 = ___async3;
			InterfaceActionInvoker3< Il2CppObject *, bool, bool >::Invoke(1 /* System.Void System.Runtime.Remoting.Contexts.IDynamicMessageSink::ProcessMessageStart(System.Runtime.Remoting.Messaging.IMessage,System.Boolean,System.Boolean) */, IDynamicMessageSink_t3056162262_il2cpp_TypeInfo_var, L_9, L_10, L_11, L_12);
		}

IL_003f:
		{
			Il2CppObject * L_13 = V_2;
			bool L_14 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_13);
			if (L_14)
			{
				goto IL_0019;
			}
		}

IL_004a:
		{
			IL2CPP_LEAVE(0x64, FINALLY_004f);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_004f;
	}

FINALLY_004f:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_15 = V_2;
			V_5 = ((Il2CppObject *)IsInst(L_15, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_16 = V_5;
			if (L_16)
			{
				goto IL_005c;
			}
		}

IL_005b:
		{
			IL2CPP_END_FINALLY(79)
		}

IL_005c:
		{
			Il2CppObject * L_17 = V_5;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_17);
			IL2CPP_END_FINALLY(79)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(79)
	{
		IL2CPP_JUMP_TBL(0x64, IL_0064)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0064:
	{
		goto IL_00c4;
	}

IL_0069:
	{
		ArrayList_t4252133567 * L_18 = V_0;
		Il2CppObject * L_19 = VirtFuncInvoker0< Il2CppObject * >::Invoke(43 /* System.Collections.IEnumerator System.Collections.ArrayList::GetEnumerator() */, L_18);
		V_4 = L_19;
	}

IL_0071:
	try
	{ // begin try (depth: 1)
		{
			goto IL_009d;
		}

IL_0076:
		{
			Il2CppObject * L_20 = V_4;
			Il2CppObject * L_21 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_20);
			V_3 = ((DynamicPropertyReg_t1839195831 *)CastclassClass(L_21, DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var));
			DynamicPropertyReg_t1839195831 * L_22 = V_3;
			Il2CppObject * L_23 = L_22->get_Sink_1();
			if (!L_23)
			{
				goto IL_009d;
			}
		}

IL_008e:
		{
			DynamicPropertyReg_t1839195831 * L_24 = V_3;
			Il2CppObject * L_25 = L_24->get_Sink_1();
			Il2CppObject * L_26 = ___msg1;
			bool L_27 = ___client_site2;
			bool L_28 = ___async3;
			InterfaceActionInvoker3< Il2CppObject *, bool, bool >::Invoke(0 /* System.Void System.Runtime.Remoting.Contexts.IDynamicMessageSink::ProcessMessageFinish(System.Runtime.Remoting.Messaging.IMessage,System.Boolean,System.Boolean) */, IDynamicMessageSink_t3056162262_il2cpp_TypeInfo_var, L_25, L_26, L_27, L_28);
		}

IL_009d:
		{
			Il2CppObject * L_29 = V_4;
			bool L_30 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_29);
			if (L_30)
			{
				goto IL_0076;
			}
		}

IL_00a9:
		{
			IL2CPP_LEAVE(0xC4, FINALLY_00ae);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00ae;
	}

FINALLY_00ae:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_31 = V_4;
			V_6 = ((Il2CppObject *)IsInst(L_31, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_32 = V_6;
			if (L_32)
			{
				goto IL_00bc;
			}
		}

IL_00bb:
		{
			IL2CPP_END_FINALLY(174)
		}

IL_00bc:
		{
			Il2CppObject * L_33 = V_6;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_33);
			IL2CPP_END_FINALLY(174)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(174)
	{
		IL2CPP_JUMP_TBL(0xC4, IL_00c4)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00c4:
	{
		return;
	}
}
// System.Int32 System.Runtime.Remoting.Contexts.DynamicPropertyCollection::FindProperty(System.String)
extern Il2CppClass* DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var;
extern Il2CppClass* IDynamicProperty_t603529997_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t DynamicPropertyCollection_FindProperty_m1233265924_MetadataUsageId;
extern "C"  int32_t DynamicPropertyCollection_FindProperty_m1233265924 (DynamicPropertyCollection_t2282532998 * __this, String_t* ___name0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DynamicPropertyCollection_FindProperty_m1233265924_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	{
		V_0 = 0;
		goto IL_0033;
	}

IL_0007:
	{
		ArrayList_t4252133567 * L_0 = __this->get__properties_0();
		int32_t L_1 = V_0;
		Il2CppObject * L_2 = VirtFuncInvoker1< Il2CppObject *, int32_t >::Invoke(21 /* System.Object System.Collections.ArrayList::get_Item(System.Int32) */, L_0, L_1);
		Il2CppObject * L_3 = ((DynamicPropertyReg_t1839195831 *)CastclassClass(L_2, DynamicPropertyReg_t1839195831_il2cpp_TypeInfo_var))->get_Property_0();
		String_t* L_4 = InterfaceFuncInvoker0< String_t* >::Invoke(0 /* System.String System.Runtime.Remoting.Contexts.IDynamicProperty::get_Name() */, IDynamicProperty_t603529997_il2cpp_TypeInfo_var, L_3);
		String_t* L_5 = ___name0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_002f;
		}
	}
	{
		int32_t L_7 = V_0;
		return L_7;
	}

IL_002f:
	{
		int32_t L_8 = V_0;
		V_0 = ((int32_t)((int32_t)L_8+(int32_t)1));
	}

IL_0033:
	{
		int32_t L_9 = V_0;
		ArrayList_t4252133567 * L_10 = __this->get__properties_0();
		int32_t L_11 = VirtFuncInvoker0< int32_t >::Invoke(23 /* System.Int32 System.Collections.ArrayList::get_Count() */, L_10);
		if ((((int32_t)L_9) < ((int32_t)L_11)))
		{
			goto IL_0007;
		}
	}
	{
		return (-1);
	}
}
// System.Void System.Runtime.Remoting.Contexts.DynamicPropertyCollection/DynamicPropertyReg::.ctor()
extern "C"  void DynamicPropertyReg__ctor_m750943241 (DynamicPropertyReg_t1839195831 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::.ctor()
extern "C"  void SynchronizationAttribute__ctor_m1709985936 (SynchronizationAttribute_t3073724998 * __this, const MethodInfo* method)
{
	{
		SynchronizationAttribute__ctor_m4065871636(__this, 8, (bool)0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::.ctor(System.Int32,System.Boolean)
extern Il2CppClass* Mutex_t297030111_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484817018;
extern Il2CppCodeGenString* _stringLiteral1232676424;
extern const uint32_t SynchronizationAttribute__ctor_m4065871636_MetadataUsageId;
extern "C"  void SynchronizationAttribute__ctor_m4065871636 (SynchronizationAttribute_t3073724998 * __this, int32_t ___flag0, bool ___reEntrant1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute__ctor_m4065871636_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Mutex_t297030111 * L_0 = (Mutex_t297030111 *)il2cpp_codegen_object_new(Mutex_t297030111_il2cpp_TypeInfo_var);
		Mutex__ctor_m2649008317(L_0, (bool)0, /*hidden argument*/NULL);
		__this->set__mutex_4(L_0);
		ContextAttribute__ctor_m4006843177(__this, _stringLiteral3484817018, /*hidden argument*/NULL);
		int32_t L_1 = ___flag0;
		if ((((int32_t)L_1) == ((int32_t)1)))
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_2 = ___flag0;
		if ((((int32_t)L_2) == ((int32_t)4)))
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_3 = ___flag0;
		if ((((int32_t)L_3) == ((int32_t)8)))
		{
			goto IL_003e;
		}
	}
	{
		int32_t L_4 = ___flag0;
		if ((((int32_t)L_4) == ((int32_t)2)))
		{
			goto IL_003e;
		}
	}
	{
		ArgumentException_t3259014390 * L_5 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_5, _stringLiteral1232676424, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_5);
	}

IL_003e:
	{
		bool L_6 = ___reEntrant1;
		__this->set__bReEntrant_1(L_6);
		int32_t L_7 = ___flag0;
		__this->set__flavor_2(L_7);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::set_Locked(System.Boolean)
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern const uint32_t SynchronizationAttribute_set_Locked_m162980252_MetadataUsageId;
extern "C"  void SynchronizationAttribute_set_Locked_m162980252 (SynchronizationAttribute_t3073724998 * __this, bool ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_set_Locked_m162980252_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SynchronizationAttribute_t3073724998 * V_0 = NULL;
	SynchronizationAttribute_t3073724998 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		bool L_0 = ___value0;
		if (!L_0)
		{
			goto IL_0056;
		}
	}
	{
		Mutex_t297030111 * L_1 = __this->get__mutex_4();
		VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.Threading.WaitHandle::WaitOne() */, L_1);
		V_0 = __this;
		SynchronizationAttribute_t3073724998 * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_001a:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_3 = __this->get__lockCount_3();
			__this->set__lockCount_3(((int32_t)((int32_t)L_3+(int32_t)1)));
			int32_t L_4 = __this->get__lockCount_3();
			if ((((int32_t)L_4) <= ((int32_t)1)))
			{
				goto IL_003a;
			}
		}

IL_0034:
		{
			SynchronizationAttribute_ReleaseLock_m2873780842(__this, /*hidden argument*/NULL);
		}

IL_003a:
		{
			IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
			Thread_t241561612 * L_5 = Thread_get_CurrentThread_m3667342817(NULL /*static, unused*/, /*hidden argument*/NULL);
			__this->set__ownerThread_5(L_5);
			IL2CPP_LEAVE(0x51, FINALLY_004a);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_004a;
	}

FINALLY_004a:
	{ // begin finally (depth: 1)
		SynchronizationAttribute_t3073724998 * L_6 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_6, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(74)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(74)
	{
		IL2CPP_JUMP_TBL(0x51, IL_0051)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0051:
	{
		goto IL_00ab;
	}

IL_0056:
	{
		V_1 = __this;
		SynchronizationAttribute_t3073724998 * L_7 = V_1;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
	}

IL_005e:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0083;
		}

IL_0063:
		{
			int32_t L_8 = __this->get__lockCount_3();
			__this->set__lockCount_3(((int32_t)((int32_t)L_8-(int32_t)1)));
			Mutex_t297030111 * L_9 = __this->get__mutex_4();
			Mutex_ReleaseMutex_m2143813124(L_9, /*hidden argument*/NULL);
			__this->set__ownerThread_5((Thread_t241561612 *)NULL);
		}

IL_0083:
		{
			int32_t L_10 = __this->get__lockCount_3();
			if ((((int32_t)L_10) <= ((int32_t)0)))
			{
				goto IL_009f;
			}
		}

IL_008f:
		{
			Thread_t241561612 * L_11 = __this->get__ownerThread_5();
			IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
			Thread_t241561612 * L_12 = Thread_get_CurrentThread_m3667342817(NULL /*static, unused*/, /*hidden argument*/NULL);
			if ((((Il2CppObject*)(Thread_t241561612 *)L_11) == ((Il2CppObject*)(Thread_t241561612 *)L_12)))
			{
				goto IL_0063;
			}
		}

IL_009f:
		{
			IL2CPP_LEAVE(0xAB, FINALLY_00a4);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00a4;
	}

FINALLY_00a4:
	{ // begin finally (depth: 1)
		SynchronizationAttribute_t3073724998 * L_13 = V_1;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_13, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(164)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(164)
	{
		IL2CPP_JUMP_TBL(0xAB, IL_00ab)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00ab:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::ReleaseLock()
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern const uint32_t SynchronizationAttribute_ReleaseLock_m2873780842_MetadataUsageId;
extern "C"  void SynchronizationAttribute_ReleaseLock_m2873780842 (SynchronizationAttribute_t3073724998 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_ReleaseLock_m2873780842_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SynchronizationAttribute_t3073724998 * V_0 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		SynchronizationAttribute_t3073724998 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			int32_t L_1 = __this->get__lockCount_3();
			if ((((int32_t)L_1) <= ((int32_t)0)))
			{
				goto IL_0044;
			}
		}

IL_0014:
		{
			Thread_t241561612 * L_2 = __this->get__ownerThread_5();
			IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
			Thread_t241561612 * L_3 = Thread_get_CurrentThread_m3667342817(NULL /*static, unused*/, /*hidden argument*/NULL);
			if ((!(((Il2CppObject*)(Thread_t241561612 *)L_2) == ((Il2CppObject*)(Thread_t241561612 *)L_3))))
			{
				goto IL_0044;
			}
		}

IL_0024:
		{
			int32_t L_4 = __this->get__lockCount_3();
			__this->set__lockCount_3(((int32_t)((int32_t)L_4-(int32_t)1)));
			Mutex_t297030111 * L_5 = __this->get__mutex_4();
			Mutex_ReleaseMutex_m2143813124(L_5, /*hidden argument*/NULL);
			__this->set__ownerThread_5((Thread_t241561612 *)NULL);
		}

IL_0044:
		{
			IL2CPP_LEAVE(0x50, FINALLY_0049);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0049;
	}

FINALLY_0049:
	{ // begin finally (depth: 1)
		SynchronizationAttribute_t3073724998 * L_6 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_6, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(73)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(73)
	{
		IL2CPP_JUMP_TBL(0x50, IL_0050)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0050:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::GetPropertiesForNewContext(System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_t3321498491_il2cpp_TypeInfo_var;
extern const uint32_t SynchronizationAttribute_GetPropertiesForNewContext_m2175864602_MetadataUsageId;
extern "C"  void SynchronizationAttribute_GetPropertiesForNewContext_m2175864602 (SynchronizationAttribute_t3073724998 * __this, Il2CppObject * ___ctorMsg0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_GetPropertiesForNewContext_m2175864602_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		int32_t L_0 = __this->get__flavor_2();
		if ((((int32_t)L_0) == ((int32_t)1)))
		{
			goto IL_0019;
		}
	}
	{
		Il2CppObject * L_1 = ___ctorMsg0;
		Il2CppObject * L_2 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Collections.IList System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ContextProperties() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, L_1);
		InterfaceFuncInvoker1< int32_t, Il2CppObject * >::Invoke(4 /* System.Int32 System.Collections.IList::Add(System.Object) */, IList_t3321498491_il2cpp_TypeInfo_var, L_2, __this);
	}

IL_0019:
	{
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.SynchronizationAttribute::GetClientContextSink(System.Runtime.Remoting.Messaging.IMessageSink)
extern Il2CppClass* SynchronizedClientContextSink_t3779986825_il2cpp_TypeInfo_var;
extern const uint32_t SynchronizationAttribute_GetClientContextSink_m1264319894_MetadataUsageId;
extern "C"  Il2CppObject * SynchronizationAttribute_GetClientContextSink_m1264319894 (SynchronizationAttribute_t3073724998 * __this, Il2CppObject * ___nextSink0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_GetClientContextSink_m1264319894_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___nextSink0;
		SynchronizedClientContextSink_t3779986825 * L_1 = (SynchronizedClientContextSink_t3779986825 *)il2cpp_codegen_object_new(SynchronizedClientContextSink_t3779986825_il2cpp_TypeInfo_var);
		SynchronizedClientContextSink__ctor_m978504596(L_1, L_0, __this, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Contexts.SynchronizationAttribute::GetServerContextSink(System.Runtime.Remoting.Messaging.IMessageSink)
extern Il2CppClass* SynchronizedServerContextSink_t462987365_il2cpp_TypeInfo_var;
extern const uint32_t SynchronizationAttribute_GetServerContextSink_m105122290_MetadataUsageId;
extern "C"  Il2CppObject * SynchronizationAttribute_GetServerContextSink_m105122290 (SynchronizationAttribute_t3073724998 * __this, Il2CppObject * ___nextSink0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_GetServerContextSink_m105122290_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___nextSink0;
		SynchronizedServerContextSink_t462987365 * L_1 = (SynchronizedServerContextSink_t462987365 *)il2cpp_codegen_object_new(SynchronizedServerContextSink_t462987365_il2cpp_TypeInfo_var);
		SynchronizedServerContextSink__ctor_m661819440(L_1, L_0, __this, /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean System.Runtime.Remoting.Contexts.SynchronizationAttribute::IsContextOK(System.Runtime.Remoting.Contexts.Context,System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484817018;
extern const uint32_t SynchronizationAttribute_IsContextOK_m525966365_MetadataUsageId;
extern "C"  bool SynchronizationAttribute_IsContextOK_m525966365 (SynchronizationAttribute_t3073724998 * __this, Context_t502196753 * ___ctx0, Il2CppObject * ___msg1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_IsContextOK_m525966365_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SynchronizationAttribute_t3073724998 * V_0 = NULL;
	int32_t V_1 = 0;
	{
		Context_t502196753 * L_0 = ___ctx0;
		Il2CppObject * L_1 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(6 /* System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String) */, L_0, _stringLiteral3484817018);
		V_0 = ((SynchronizationAttribute_t3073724998 *)IsInstClass(L_1, SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var));
		int32_t L_2 = __this->get__flavor_2();
		V_1 = L_2;
		int32_t L_3 = V_1;
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 0)
		{
			goto IL_0045;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 1)
		{
			goto IL_0054;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 2)
		{
			goto IL_0056;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 3)
		{
			goto IL_004a;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 4)
		{
			goto IL_0056;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 5)
		{
			goto IL_0056;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 6)
		{
			goto IL_0056;
		}
		if (((int32_t)((int32_t)L_3-(int32_t)1)) == 7)
		{
			goto IL_0052;
		}
	}
	{
		goto IL_0056;
	}

IL_0045:
	{
		SynchronizationAttribute_t3073724998 * L_4 = V_0;
		return (bool)((((Il2CppObject*)(SynchronizationAttribute_t3073724998 *)L_4) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0);
	}

IL_004a:
	{
		SynchronizationAttribute_t3073724998 * L_5 = V_0;
		return (bool)((((int32_t)((((Il2CppObject*)(SynchronizationAttribute_t3073724998 *)L_5) == ((Il2CppObject*)(Il2CppObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}

IL_0052:
	{
		return (bool)0;
	}

IL_0054:
	{
		return (bool)1;
	}

IL_0056:
	{
		return (bool)0;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::ExitContext()
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484817018;
extern const uint32_t SynchronizationAttribute_ExitContext_m2253102541_MetadataUsageId;
extern "C"  void SynchronizationAttribute_ExitContext_m2253102541 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_ExitContext_m2253102541_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SynchronizationAttribute_t3073724998 * V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_0 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		bool L_1 = Context_get_IsDefaultContext_m3300558634(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		return;
	}

IL_0010:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_2 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		Il2CppObject * L_3 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(6 /* System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String) */, L_2, _stringLiteral3484817018);
		V_0 = ((SynchronizationAttribute_t3073724998 *)IsInstClass(L_3, SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var));
		SynchronizationAttribute_t3073724998 * L_4 = V_0;
		if (L_4)
		{
			goto IL_002c;
		}
	}
	{
		return;
	}

IL_002c:
	{
		SynchronizationAttribute_t3073724998 * L_5 = V_0;
		VirtActionInvoker1< bool >::Invoke(16 /* System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::set_Locked(System.Boolean) */, L_5, (bool)0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::EnterContext()
extern Il2CppClass* Thread_t241561612_il2cpp_TypeInfo_var;
extern Il2CppClass* SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3484817018;
extern const uint32_t SynchronizationAttribute_EnterContext_m2984912761_MetadataUsageId;
extern "C"  void SynchronizationAttribute_EnterContext_m2984912761 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (SynchronizationAttribute_EnterContext_m2984912761_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SynchronizationAttribute_t3073724998 * V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_0 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		bool L_1 = Context_get_IsDefaultContext_m3300558634(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0010;
		}
	}
	{
		return;
	}

IL_0010:
	{
		IL2CPP_RUNTIME_CLASS_INIT(Thread_t241561612_il2cpp_TypeInfo_var);
		Context_t502196753 * L_2 = Thread_get_CurrentContext_m3123598616(NULL /*static, unused*/, /*hidden argument*/NULL);
		Il2CppObject * L_3 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(6 /* System.Runtime.Remoting.Contexts.IContextProperty System.Runtime.Remoting.Contexts.Context::GetProperty(System.String) */, L_2, _stringLiteral3484817018);
		V_0 = ((SynchronizationAttribute_t3073724998 *)IsInstClass(L_3, SynchronizationAttribute_t3073724998_il2cpp_TypeInfo_var));
		SynchronizationAttribute_t3073724998 * L_4 = V_0;
		if (L_4)
		{
			goto IL_002c;
		}
	}
	{
		return;
	}

IL_002c:
	{
		SynchronizationAttribute_t3073724998 * L_5 = V_0;
		VirtActionInvoker1< bool >::Invoke(16 /* System.Void System.Runtime.Remoting.Contexts.SynchronizationAttribute::set_Locked(System.Boolean) */, L_5, (bool)1);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizedClientContextSink::.ctor(System.Runtime.Remoting.Messaging.IMessageSink,System.Runtime.Remoting.Contexts.SynchronizationAttribute)
extern "C"  void SynchronizedClientContextSink__ctor_m978504596 (SynchronizedClientContextSink_t3779986825 * __this, Il2CppObject * ___next0, SynchronizationAttribute_t3073724998 * ___att1, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SynchronizationAttribute_t3073724998 * L_0 = ___att1;
		__this->set__att_1(L_0);
		Il2CppObject * L_1 = ___next0;
		__this->set__next_0(L_1);
		return;
	}
}
// System.Void System.Runtime.Remoting.Contexts.SynchronizedServerContextSink::.ctor(System.Runtime.Remoting.Messaging.IMessageSink,System.Runtime.Remoting.Contexts.SynchronizationAttribute)
extern "C"  void SynchronizedServerContextSink__ctor_m661819440 (SynchronizedServerContextSink_t462987365 * __this, Il2CppObject * ___next0, SynchronizationAttribute_t3073724998 * ___att1, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SynchronizationAttribute_t3073724998 * L_0 = ___att1;
		__this->set__att_1(L_0);
		Il2CppObject * L_1 = ___next0;
		__this->set__next_0(L_1);
		return;
	}
}
// System.Void System.Runtime.Remoting.EnvoyInfo::.ctor(System.Runtime.Remoting.Messaging.IMessageSink)
extern "C"  void EnvoyInfo__ctor_m1576967598 (EnvoyInfo_t815109115 * __this, Il2CppObject * ___sinks0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Il2CppObject * L_0 = ___sinks0;
		__this->set_envoySinks_0(L_0);
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.EnvoyInfo::get_EnvoySinks()
extern "C"  Il2CppObject * EnvoyInfo_get_EnvoySinks_m1168833697 (EnvoyInfo_t815109115 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_envoySinks_0();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.FormatterData::.ctor()
extern "C"  void FormatterData__ctor_m3974986124 (FormatterData_t12176916 * __this, const MethodInfo* method)
{
	{
		ProviderData__ctor_m1260387831(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Identity::.ctor(System.String)
extern "C"  void Identity__ctor_m3398266716 (Identity_t3647548000 * __this, String_t* ___objectUri0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___objectUri0;
		__this->set__objectUri_0(L_0);
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Identity::get_ChannelSink()
extern "C"  Il2CppObject * Identity_get_ChannelSink_m3989446673 (Identity_t3647548000 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get__channelSink_1();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Identity::set_ChannelSink(System.Runtime.Remoting.Messaging.IMessageSink)
extern "C"  void Identity_set_ChannelSink_m2409636044 (Identity_t3647548000 * __this, Il2CppObject * ___value0, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___value0;
		__this->set__channelSink_1(L_0);
		return;
	}
}
// System.String System.Runtime.Remoting.Identity::get_ObjectUri()
extern "C"  String_t* Identity_get_ObjectUri_m2053110803 (Identity_t3647548000 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__objectUri_0();
		return L_0;
	}
}
// System.Boolean System.Runtime.Remoting.Identity::get_Disposed()
extern "C"  bool Identity_get_Disposed_m720757734 (Identity_t3647548000 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get__disposed_6();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Identity::set_Disposed(System.Boolean)
extern "C"  void Identity_set_Disposed_m628843469 (Identity_t3647548000 * __this, bool ___value0, const MethodInfo* method)
{
	{
		bool L_0 = ___value0;
		__this->set__disposed_6(L_0);
		return;
	}
}
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection System.Runtime.Remoting.Identity::get_ClientDynamicProperties()
extern Il2CppClass* DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var;
extern const uint32_t Identity_get_ClientDynamicProperties_m767245959_MetadataUsageId;
extern "C"  DynamicPropertyCollection_t2282532998 * Identity_get_ClientDynamicProperties_m767245959 (Identity_t3647548000 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Identity_get_ClientDynamicProperties_m767245959_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		DynamicPropertyCollection_t2282532998 * L_0 = __this->get__clientDynamicProperties_3();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_1 = (DynamicPropertyCollection_t2282532998 *)il2cpp_codegen_object_new(DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var);
		DynamicPropertyCollection__ctor_m1159577654(L_1, /*hidden argument*/NULL);
		__this->set__clientDynamicProperties_3(L_1);
	}

IL_0016:
	{
		DynamicPropertyCollection_t2282532998 * L_2 = __this->get__clientDynamicProperties_3();
		return L_2;
	}
}
// System.Runtime.Remoting.Contexts.DynamicPropertyCollection System.Runtime.Remoting.Identity::get_ServerDynamicProperties()
extern Il2CppClass* DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var;
extern const uint32_t Identity_get_ServerDynamicProperties_m2264450835_MetadataUsageId;
extern "C"  DynamicPropertyCollection_t2282532998 * Identity_get_ServerDynamicProperties_m2264450835 (Identity_t3647548000 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (Identity_get_ServerDynamicProperties_m2264450835_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		DynamicPropertyCollection_t2282532998 * L_0 = __this->get__serverDynamicProperties_4();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		DynamicPropertyCollection_t2282532998 * L_1 = (DynamicPropertyCollection_t2282532998 *)il2cpp_codegen_object_new(DynamicPropertyCollection_t2282532998_il2cpp_TypeInfo_var);
		DynamicPropertyCollection__ctor_m1159577654(L_1, /*hidden argument*/NULL);
		__this->set__serverDynamicProperties_4(L_1);
	}

IL_0016:
	{
		DynamicPropertyCollection_t2282532998 * L_2 = __this->get__serverDynamicProperties_4();
		return L_2;
	}
}
// System.Void System.Runtime.Remoting.InternalRemotingServices::.cctor()
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern Il2CppClass* InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var;
extern const uint32_t InternalRemotingServices__cctor_m3821625125_MetadataUsageId;
extern "C"  void InternalRemotingServices__cctor_m3821625125 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (InternalRemotingServices__cctor_m3821625125_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_0, /*hidden argument*/NULL);
		((InternalRemotingServices_t3953136710_StaticFields*)InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var->static_fields)->set__soapAttributes_0(L_0);
		return;
	}
}
// System.Runtime.Remoting.Metadata.SoapAttribute System.Runtime.Remoting.InternalRemotingServices::GetCachedSoapAttribute(System.Object)
extern const Il2CppType* SoapAttribute_t1982224933_0_0_0_var;
extern Il2CppClass* InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapAttribute_t1982224933_il2cpp_TypeInfo_var;
extern Il2CppClass* ICustomAttributeProvider_t502202687_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapTypeAttribute_t3444503085_il2cpp_TypeInfo_var;
extern Il2CppClass* FieldInfo_t_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapFieldAttribute_t3073759685_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodBase_t904190842_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapMethodAttribute_t2381910676_il2cpp_TypeInfo_var;
extern Il2CppClass* ParameterInfo_t2249040075_il2cpp_TypeInfo_var;
extern Il2CppClass* SoapParameterAttribute_t2780084514_il2cpp_TypeInfo_var;
extern const uint32_t InternalRemotingServices_GetCachedSoapAttribute_m2607420042_MetadataUsageId;
extern "C"  SoapAttribute_t1982224933 * InternalRemotingServices_GetCachedSoapAttribute_m2607420042 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___reflectionObject0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (InternalRemotingServices_GetCachedSoapAttribute_m2607420042_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	SoapAttribute_t1982224933 * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	ObjectU5BU5D_t3614634134* V_3 = NULL;
	SoapAttribute_t1982224933 * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		IL2CPP_RUNTIME_CLASS_INIT(InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var);
		Hashtable_t909839986 * L_0 = ((InternalRemotingServices_t3953136710_StaticFields*)InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var->static_fields)->get__soapAttributes_0();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(19 /* System.Object System.Collections.Hashtable::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0011:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_3 = ((InternalRemotingServices_t3953136710_StaticFields*)InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var->static_fields)->get__soapAttributes_0();
			Il2CppObject * L_4 = ___reflectionObject0;
			Il2CppObject * L_5 = VirtFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(22 /* System.Object System.Collections.Hashtable::get_Item(System.Object) */, L_3, L_4);
			V_1 = ((SoapAttribute_t1982224933 *)IsInstClass(L_5, SoapAttribute_t1982224933_il2cpp_TypeInfo_var));
			SoapAttribute_t1982224933 * L_6 = V_1;
			if (!L_6)
			{
				goto IL_0030;
			}
		}

IL_0028:
		{
			SoapAttribute_t1982224933 * L_7 = V_1;
			V_4 = L_7;
			IL2CPP_LEAVE(0xDA, FINALLY_00d3);
		}

IL_0030:
		{
			Il2CppObject * L_8 = ___reflectionObject0;
			V_2 = ((Il2CppObject *)Castclass(L_8, ICustomAttributeProvider_t502202687_il2cpp_TypeInfo_var));
			Il2CppObject * L_9 = V_2;
			IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
			Type_t * L_10 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(SoapAttribute_t1982224933_0_0_0_var), /*hidden argument*/NULL);
			ObjectU5BU5D_t3614634134* L_11 = InterfaceFuncInvoker2< ObjectU5BU5D_t3614634134*, Type_t *, bool >::Invoke(0 /* System.Object[] System.Reflection.ICustomAttributeProvider::GetCustomAttributes(System.Type,System.Boolean) */, ICustomAttributeProvider_t502202687_il2cpp_TypeInfo_var, L_9, L_10, (bool)1);
			V_3 = L_11;
			ObjectU5BU5D_t3614634134* L_12 = V_3;
			if ((((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_12)->max_length))))) <= ((int32_t)0)))
			{
				goto IL_0060;
			}
		}

IL_0052:
		{
			ObjectU5BU5D_t3614634134* L_13 = V_3;
			int32_t L_14 = 0;
			Il2CppObject * L_15 = (L_13)->GetAt(static_cast<il2cpp_array_size_t>(L_14));
			V_1 = ((SoapAttribute_t1982224933 *)CastclassClass(L_15, SoapAttribute_t1982224933_il2cpp_TypeInfo_var));
			goto IL_00b3;
		}

IL_0060:
		{
			Il2CppObject * L_16 = ___reflectionObject0;
			if (!((Type_t *)IsInstClass(L_16, Type_t_il2cpp_TypeInfo_var)))
			{
				goto IL_0076;
			}
		}

IL_006b:
		{
			SoapTypeAttribute_t3444503085 * L_17 = (SoapTypeAttribute_t3444503085 *)il2cpp_codegen_object_new(SoapTypeAttribute_t3444503085_il2cpp_TypeInfo_var);
			SoapTypeAttribute__ctor_m440109178(L_17, /*hidden argument*/NULL);
			V_1 = L_17;
			goto IL_00b3;
		}

IL_0076:
		{
			Il2CppObject * L_18 = ___reflectionObject0;
			if (!((FieldInfo_t *)IsInstClass(L_18, FieldInfo_t_il2cpp_TypeInfo_var)))
			{
				goto IL_008c;
			}
		}

IL_0081:
		{
			SoapFieldAttribute_t3073759685 * L_19 = (SoapFieldAttribute_t3073759685 *)il2cpp_codegen_object_new(SoapFieldAttribute_t3073759685_il2cpp_TypeInfo_var);
			SoapFieldAttribute__ctor_m3200752676(L_19, /*hidden argument*/NULL);
			V_1 = L_19;
			goto IL_00b3;
		}

IL_008c:
		{
			Il2CppObject * L_20 = ___reflectionObject0;
			if (!((MethodBase_t904190842 *)IsInstClass(L_20, MethodBase_t904190842_il2cpp_TypeInfo_var)))
			{
				goto IL_00a2;
			}
		}

IL_0097:
		{
			SoapMethodAttribute_t2381910676 * L_21 = (SoapMethodAttribute_t2381910676 *)il2cpp_codegen_object_new(SoapMethodAttribute_t2381910676_il2cpp_TypeInfo_var);
			SoapMethodAttribute__ctor_m2752613603(L_21, /*hidden argument*/NULL);
			V_1 = L_21;
			goto IL_00b3;
		}

IL_00a2:
		{
			Il2CppObject * L_22 = ___reflectionObject0;
			if (!((ParameterInfo_t2249040075 *)IsInstClass(L_22, ParameterInfo_t2249040075_il2cpp_TypeInfo_var)))
			{
				goto IL_00b3;
			}
		}

IL_00ad:
		{
			SoapParameterAttribute_t2780084514 * L_23 = (SoapParameterAttribute_t2780084514 *)il2cpp_codegen_object_new(SoapParameterAttribute_t2780084514_il2cpp_TypeInfo_var);
			SoapParameterAttribute__ctor_m1907474965(L_23, /*hidden argument*/NULL);
			V_1 = L_23;
		}

IL_00b3:
		{
			SoapAttribute_t1982224933 * L_24 = V_1;
			Il2CppObject * L_25 = ___reflectionObject0;
			VirtActionInvoker1< Il2CppObject * >::Invoke(6 /* System.Void System.Runtime.Remoting.Metadata.SoapAttribute::SetReflectionObject(System.Object) */, L_24, L_25);
			IL2CPP_RUNTIME_CLASS_INIT(InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var);
			Hashtable_t909839986 * L_26 = ((InternalRemotingServices_t3953136710_StaticFields*)InternalRemotingServices_t3953136710_il2cpp_TypeInfo_var->static_fields)->get__soapAttributes_0();
			Il2CppObject * L_27 = ___reflectionObject0;
			SoapAttribute_t1982224933 * L_28 = V_1;
			VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(23 /* System.Void System.Collections.Hashtable::set_Item(System.Object,System.Object) */, L_26, L_27, L_28);
			SoapAttribute_t1982224933 * L_29 = V_1;
			V_4 = L_29;
			IL2CPP_LEAVE(0xDA, FINALLY_00d3);
		}

IL_00ce:
		{
			; // IL_00ce: leave IL_00da
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00d3;
	}

FINALLY_00d3:
	{ // begin finally (depth: 1)
		Il2CppObject * L_30 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_30, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(211)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(211)
	{
		IL2CPP_JUMP_TBL(0xDA, IL_00da)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00da:
	{
		SoapAttribute_t1982224933 * L_31 = V_4;
		return L_31;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LeaseManager::.ctor()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t LeaseManager__ctor_m2166901364_MetadataUsageId;
extern "C"  void LeaseManager__ctor_m2166901364 (LeaseManager_t1025868639 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LeaseManager__ctor_m2166901364_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		__this->set__objects_0(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LeaseManager::SetPollTime(System.TimeSpan)
extern "C"  void LeaseManager_SetPollTime_m3137304074 (LeaseManager_t1025868639 * __this, TimeSpan_t3430258949  ___timeSpan0, const MethodInfo* method)
{
	Il2CppObject * V_0 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = __this->get__objects_0();
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(29 /* System.Object System.Collections.ArrayList::get_SyncRoot() */, L_0);
		V_0 = L_1;
		Il2CppObject * L_2 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_2, /*hidden argument*/NULL);
	}

IL_0012:
	try
	{ // begin try (depth: 1)
		{
			Timer_t791717973 * L_3 = __this->get__timer_1();
			if (!L_3)
			{
				goto IL_002b;
			}
		}

IL_001d:
		{
			Timer_t791717973 * L_4 = __this->get__timer_1();
			TimeSpan_t3430258949  L_5 = ___timeSpan0;
			TimeSpan_t3430258949  L_6 = ___timeSpan0;
			Timer_Change_m1102301880(L_4, L_5, L_6, /*hidden argument*/NULL);
		}

IL_002b:
		{
			IL2CPP_LEAVE(0x37, FINALLY_0030);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0030;
	}

FINALLY_0030:
	{ // begin finally (depth: 1)
		Il2CppObject * L_7 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_7, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(48)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(48)
	{
		IL2CPP_JUMP_TBL(0x37, IL_0037)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0037:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LeaseSink::.ctor(System.Runtime.Remoting.Messaging.IMessageSink)
extern "C"  void LeaseSink__ctor_m295312109 (LeaseSink_t3007073869 * __this, Il2CppObject * ___nextSink0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Il2CppObject * L_0 = ___nextSink0;
		__this->set__nextSink_0(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LifetimeServices::.cctor()
extern Il2CppClass* LeaseManager_t1025868639_il2cpp_TypeInfo_var;
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern Il2CppClass* TimeSpan_t3430258949_il2cpp_TypeInfo_var;
extern const uint32_t LifetimeServices__cctor_m2764553769_MetadataUsageId;
extern "C"  void LifetimeServices__cctor_m2764553769 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LifetimeServices__cctor_m2764553769_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		LeaseManager_t1025868639 * L_0 = (LeaseManager_t1025868639 *)il2cpp_codegen_object_new(LeaseManager_t1025868639_il2cpp_TypeInfo_var);
		LeaseManager__ctor_m2166901364(L_0, /*hidden argument*/NULL);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__leaseManager_4(L_0);
		IL2CPP_RUNTIME_CLASS_INIT(TimeSpan_t3430258949_il2cpp_TypeInfo_var);
		TimeSpan_t3430258949  L_1 = TimeSpan_FromSeconds_m2861206200(NULL /*static, unused*/, (10.0), /*hidden argument*/NULL);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__leaseManagerPollTime_0(L_1);
		TimeSpan_t3430258949  L_2 = TimeSpan_FromMinutes_m1997633268(NULL /*static, unused*/, (5.0), /*hidden argument*/NULL);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__leaseTime_1(L_2);
		TimeSpan_t3430258949  L_3 = TimeSpan_FromMinutes_m1997633268(NULL /*static, unused*/, (2.0), /*hidden argument*/NULL);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__renewOnCallTime_2(L_3);
		TimeSpan_t3430258949  L_4 = TimeSpan_FromMinutes_m1997633268(NULL /*static, unused*/, (2.0), /*hidden argument*/NULL);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__sponsorshipTimeout_3(L_4);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LifetimeServices::set_LeaseManagerPollTime(System.TimeSpan)
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern const uint32_t LifetimeServices_set_LeaseManagerPollTime_m3919998154_MetadataUsageId;
extern "C"  void LifetimeServices_set_LeaseManagerPollTime_m3919998154 (Il2CppObject * __this /* static, unused */, TimeSpan_t3430258949  ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LifetimeServices_set_LeaseManagerPollTime_m3919998154_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		TimeSpan_t3430258949  L_0 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__leaseManagerPollTime_0(L_0);
		LeaseManager_t1025868639 * L_1 = ((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->get__leaseManager_4();
		TimeSpan_t3430258949  L_2 = ___value0;
		LeaseManager_SetPollTime_m3137304074(L_1, L_2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LifetimeServices::set_LeaseTime(System.TimeSpan)
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern const uint32_t LifetimeServices_set_LeaseTime_m1487876644_MetadataUsageId;
extern "C"  void LifetimeServices_set_LeaseTime_m1487876644 (Il2CppObject * __this /* static, unused */, TimeSpan_t3430258949  ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LifetimeServices_set_LeaseTime_m1487876644_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		TimeSpan_t3430258949  L_0 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__leaseTime_1(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LifetimeServices::set_RenewOnCallTime(System.TimeSpan)
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern const uint32_t LifetimeServices_set_RenewOnCallTime_m3507481746_MetadataUsageId;
extern "C"  void LifetimeServices_set_RenewOnCallTime_m3507481746 (Il2CppObject * __this /* static, unused */, TimeSpan_t3430258949  ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LifetimeServices_set_RenewOnCallTime_m3507481746_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		TimeSpan_t3430258949  L_0 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__renewOnCallTime_2(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Lifetime.LifetimeServices::set_SponsorshipTimeout(System.TimeSpan)
extern Il2CppClass* LifetimeServices_t2939669377_il2cpp_TypeInfo_var;
extern const uint32_t LifetimeServices_set_SponsorshipTimeout_m1403222216_MetadataUsageId;
extern "C"  void LifetimeServices_set_SponsorshipTimeout_m1403222216 (Il2CppObject * __this /* static, unused */, TimeSpan_t3430258949  ___value0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LifetimeServices_set_SponsorshipTimeout_m1403222216_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		TimeSpan_t3430258949  L_0 = ___value0;
		IL2CPP_RUNTIME_CLASS_INIT(LifetimeServices_t2939669377_il2cpp_TypeInfo_var);
		((LifetimeServices_t2939669377_StaticFields*)LifetimeServices_t2939669377_il2cpp_TypeInfo_var->static_fields)->set__sponsorshipTimeout_3(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ArgInfo::.ctor(System.Reflection.MethodBase,System.Runtime.Remoting.Messaging.ArgInfoType)
extern Il2CppClass* Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var;
extern const uint32_t ArgInfo__ctor_m3787931268_MetadataUsageId;
extern "C"  void ArgInfo__ctor_m3787931268 (ArgInfo_t688271106 * __this, MethodBase_t904190842 * ___method0, uint8_t ___type1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ArgInfo__ctor_m3787931268_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	int32_t V_3 = 0;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		MethodBase_t904190842 * L_0 = ___method0;
		__this->set__method_2(L_0);
		MethodBase_t904190842 * L_1 = __this->get__method_2();
		ParameterInfoU5BU5D_t2275869610* L_2 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_1);
		V_0 = L_2;
		ParameterInfoU5BU5D_t2275869610* L_3 = V_0;
		__this->set__paramMap_0(((Int32U5BU5D_t3030399641*)SZArrayNew(Int32U5BU5D_t3030399641_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length)))))));
		__this->set__inoutArgCount_1(0);
		uint8_t L_4 = ___type1;
		if (L_4)
		{
			goto IL_0078;
		}
	}
	{
		V_1 = 0;
		goto IL_006a;
	}

IL_003b:
	{
		ParameterInfoU5BU5D_t2275869610* L_5 = V_0;
		int32_t L_6 = V_1;
		int32_t L_7 = L_6;
		ParameterInfo_t2249040075 * L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		Type_t * L_9 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_8);
		bool L_10 = Type_get_IsByRef_m3523465500(L_9, /*hidden argument*/NULL);
		if (L_10)
		{
			goto IL_0066;
		}
	}
	{
		Int32U5BU5D_t3030399641* L_11 = __this->get__paramMap_0();
		int32_t L_12 = __this->get__inoutArgCount_1();
		int32_t L_13 = L_12;
		V_3 = L_13;
		__this->set__inoutArgCount_1(((int32_t)((int32_t)L_13+(int32_t)1)));
		int32_t L_14 = V_3;
		int32_t L_15 = V_1;
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(L_14), (int32_t)L_15);
	}

IL_0066:
	{
		int32_t L_16 = V_1;
		V_1 = ((int32_t)((int32_t)L_16+(int32_t)1));
	}

IL_006a:
	{
		int32_t L_17 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_18 = V_0;
		if ((((int32_t)L_17) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_18)->max_length)))))))
		{
			goto IL_003b;
		}
	}
	{
		goto IL_00c4;
	}

IL_0078:
	{
		V_2 = 0;
		goto IL_00bb;
	}

IL_007f:
	{
		ParameterInfoU5BU5D_t2275869610* L_19 = V_0;
		int32_t L_20 = V_2;
		int32_t L_21 = L_20;
		ParameterInfo_t2249040075 * L_22 = (L_19)->GetAt(static_cast<il2cpp_array_size_t>(L_21));
		Type_t * L_23 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_22);
		bool L_24 = Type_get_IsByRef_m3523465500(L_23, /*hidden argument*/NULL);
		if (L_24)
		{
			goto IL_009e;
		}
	}
	{
		ParameterInfoU5BU5D_t2275869610* L_25 = V_0;
		int32_t L_26 = V_2;
		int32_t L_27 = L_26;
		ParameterInfo_t2249040075 * L_28 = (L_25)->GetAt(static_cast<il2cpp_array_size_t>(L_27));
		bool L_29 = ParameterInfo_get_IsOut_m3097675062(L_28, /*hidden argument*/NULL);
		if (!L_29)
		{
			goto IL_00b7;
		}
	}

IL_009e:
	{
		Int32U5BU5D_t3030399641* L_30 = __this->get__paramMap_0();
		int32_t L_31 = __this->get__inoutArgCount_1();
		int32_t L_32 = L_31;
		V_3 = L_32;
		__this->set__inoutArgCount_1(((int32_t)((int32_t)L_32+(int32_t)1)));
		int32_t L_33 = V_3;
		int32_t L_34 = V_2;
		(L_30)->SetAt(static_cast<il2cpp_array_size_t>(L_33), (int32_t)L_34);
	}

IL_00b7:
	{
		int32_t L_35 = V_2;
		V_2 = ((int32_t)((int32_t)L_35+(int32_t)1));
	}

IL_00bb:
	{
		int32_t L_36 = V_2;
		ParameterInfoU5BU5D_t2275869610* L_37 = V_0;
		if ((((int32_t)L_36) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_37)->max_length)))))))
		{
			goto IL_007f;
		}
	}

IL_00c4:
	{
		return;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.ArgInfo::GetInOutArgs(System.Object[])
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t ArgInfo_GetInOutArgs_m3184132151_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ArgInfo_GetInOutArgs_m3184132151 (ArgInfo_t688271106 * __this, ObjectU5BU5D_t3614634134* ___args0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ArgInfo_GetInOutArgs_m3184132151_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ObjectU5BU5D_t3614634134* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = __this->get__inoutArgCount_1();
		V_0 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_0));
		V_1 = 0;
		goto IL_0024;
	}

IL_0013:
	{
		ObjectU5BU5D_t3614634134* L_1 = V_0;
		int32_t L_2 = V_1;
		ObjectU5BU5D_t3614634134* L_3 = ___args0;
		Int32U5BU5D_t3030399641* L_4 = __this->get__paramMap_0();
		int32_t L_5 = V_1;
		int32_t L_6 = L_5;
		int32_t L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		int32_t L_8 = L_7;
		Il2CppObject * L_9 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		ArrayElementTypeCheck (L_1, L_9);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(L_2), (Il2CppObject *)L_9);
		int32_t L_10 = V_1;
		V_1 = ((int32_t)((int32_t)L_10+(int32_t)1));
	}

IL_0024:
	{
		int32_t L_11 = V_1;
		int32_t L_12 = __this->get__inoutArgCount_1();
		if ((((int32_t)L_11) < ((int32_t)L_12)))
		{
			goto IL_0013;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_13 = V_0;
		return L_13;
	}
}
// System.Void System.Runtime.Remoting.Messaging.AsyncResult::.ctor()
extern "C"  void AsyncResult__ctor_m1183194429 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.AsyncResult::get_AsyncState()
extern "C"  Il2CppObject * AsyncResult_get_AsyncState_m4124929294 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_async_state_0();
		return L_0;
	}
}
// System.Threading.WaitHandle System.Runtime.Remoting.Messaging.AsyncResult::get_AsyncWaitHandle()
extern Il2CppClass* ManualResetEvent_t926074657_il2cpp_TypeInfo_var;
extern const uint32_t AsyncResult_get_AsyncWaitHandle_m1656810902_MetadataUsageId;
extern "C"  WaitHandle_t677569169 * AsyncResult_get_AsyncWaitHandle_m1656810902 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (AsyncResult_get_AsyncWaitHandle_m1656810902_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	AsyncResult_t2232356043 * V_0 = NULL;
	WaitHandle_t677569169 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		AsyncResult_t2232356043 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			WaitHandle_t677569169 * L_1 = __this->get_handle_1();
			if (L_1)
			{
				goto IL_0024;
			}
		}

IL_0013:
		{
			bool L_2 = __this->get_completed_6();
			ManualResetEvent_t926074657 * L_3 = (ManualResetEvent_t926074657 *)il2cpp_codegen_object_new(ManualResetEvent_t926074657_il2cpp_TypeInfo_var);
			ManualResetEvent__ctor_m3470249043(L_3, L_2, /*hidden argument*/NULL);
			__this->set_handle_1(L_3);
		}

IL_0024:
		{
			WaitHandle_t677569169 * L_4 = __this->get_handle_1();
			V_1 = L_4;
			IL2CPP_LEAVE(0x3C, FINALLY_0035);
		}

IL_0030:
		{
			; // IL_0030: leave IL_003c
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0035;
	}

FINALLY_0035:
	{ // begin finally (depth: 1)
		AsyncResult_t2232356043 * L_5 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_5, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(53)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(53)
	{
		IL2CPP_JUMP_TBL(0x3C, IL_003c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_003c:
	{
		WaitHandle_t677569169 * L_6 = V_1;
		return L_6;
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::get_CompletedSynchronously()
extern "C"  bool AsyncResult_get_CompletedSynchronously_m1094955585 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get_sync_completed_5();
		return L_0;
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::get_IsCompleted()
extern "C"  bool AsyncResult_get_IsCompleted_m2993729823 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get_completed_6();
		return L_0;
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.AsyncResult::get_EndInvokeCalled()
extern "C"  bool AsyncResult_get_EndInvokeCalled_m2149609872 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		bool L_0 = __this->get_endinvoke_called_7();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.AsyncResult::set_EndInvokeCalled(System.Boolean)
extern "C"  void AsyncResult_set_EndInvokeCalled_m2748329155 (AsyncResult_t2232356043 * __this, bool ___value0, const MethodInfo* method)
{
	{
		bool L_0 = ___value0;
		__this->set_endinvoke_called_7(L_0);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.AsyncResult::get_AsyncDelegate()
extern "C"  Il2CppObject * AsyncResult_get_AsyncDelegate_m545320384 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_async_delegate_2();
		return L_0;
	}
}
// System.Runtime.Remoting.Messaging.IMessageSink System.Runtime.Remoting.Messaging.AsyncResult::get_NextSink()
extern "C"  Il2CppObject * AsyncResult_get_NextSink_m1172723924 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		return (Il2CppObject *)NULL;
	}
}
// System.Runtime.Remoting.Messaging.IMessageCtrl System.Runtime.Remoting.Messaging.AsyncResult::AsyncProcessMessage(System.Runtime.Remoting.Messaging.IMessage,System.Runtime.Remoting.Messaging.IMessageSink)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t AsyncResult_AsyncProcessMessage_m261394736_MetadataUsageId;
extern "C"  Il2CppObject * AsyncResult_AsyncProcessMessage_m261394736 (AsyncResult_t2232356043 * __this, Il2CppObject * ___msg0, Il2CppObject * ___replySink1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (AsyncResult_AsyncProcessMessage_m261394736_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Runtime.Remoting.Messaging.IMessage System.Runtime.Remoting.Messaging.AsyncResult::GetReplyMessage()
extern "C"  Il2CppObject * AsyncResult_GetReplyMessage_m262842621 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_reply_message_14();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.AsyncResult::SetMessageCtrl(System.Runtime.Remoting.Messaging.IMessageCtrl)
extern "C"  void AsyncResult_SetMessageCtrl_m301038022 (AsyncResult_t2232356043 * __this, Il2CppObject * ___mc0, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___mc0;
		__this->set_message_ctrl_13(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.AsyncResult::SetCompletedSynchronously(System.Boolean)
extern "C"  void AsyncResult_SetCompletedSynchronously_m3871832245 (AsyncResult_t2232356043 * __this, bool ___completed0, const MethodInfo* method)
{
	{
		bool L_0 = ___completed0;
		__this->set_sync_completed_5(L_0);
		return;
	}
}
// System.Runtime.Remoting.Messaging.IMessage System.Runtime.Remoting.Messaging.AsyncResult::EndInvoke()
extern "C"  Il2CppObject * AsyncResult_EndInvoke_m2725573545 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	AsyncResult_t2232356043 * V_0 = NULL;
	Il2CppObject * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		V_0 = __this;
		AsyncResult_t2232356043 * L_0 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
	}

IL_0008:
	try
	{ // begin try (depth: 1)
		{
			bool L_1 = __this->get_completed_6();
			if (!L_1)
			{
				goto IL_001f;
			}
		}

IL_0013:
		{
			Il2CppObject * L_2 = __this->get_reply_message_14();
			V_1 = L_2;
			IL2CPP_LEAVE(0x3E, FINALLY_0024);
		}

IL_001f:
		{
			IL2CPP_LEAVE(0x2B, FINALLY_0024);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0024;
	}

FINALLY_0024:
	{ // begin finally (depth: 1)
		AsyncResult_t2232356043 * L_3 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_3, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(36)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(36)
	{
		IL2CPP_JUMP_TBL(0x3E, IL_003e)
		IL2CPP_JUMP_TBL(0x2B, IL_002b)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_002b:
	{
		WaitHandle_t677569169 * L_4 = VirtFuncInvoker0< WaitHandle_t677569169 * >::Invoke(8 /* System.Threading.WaitHandle System.Runtime.Remoting.Messaging.AsyncResult::get_AsyncWaitHandle() */, __this);
		VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.Threading.WaitHandle::WaitOne() */, L_4);
		Il2CppObject * L_5 = __this->get_reply_message_14();
		return L_5;
	}

IL_003e:
	{
		Il2CppObject * L_6 = V_1;
		return L_6;
	}
}
// System.Runtime.Remoting.Messaging.IMessage System.Runtime.Remoting.Messaging.AsyncResult::SyncProcessMessage(System.Runtime.Remoting.Messaging.IMessage)
extern Il2CppClass* ManualResetEvent_t926074657_il2cpp_TypeInfo_var;
extern Il2CppClass* AsyncCallback_t163412349_il2cpp_TypeInfo_var;
extern const uint32_t AsyncResult_SyncProcessMessage_m3254063433_MetadataUsageId;
extern "C"  Il2CppObject * AsyncResult_SyncProcessMessage_m3254063433 (AsyncResult_t2232356043 * __this, Il2CppObject * ___msg0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (AsyncResult_SyncProcessMessage_m3254063433_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	AsyncResult_t2232356043 * V_0 = NULL;
	AsyncCallback_t163412349 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Il2CppObject * L_0 = ___msg0;
		__this->set_reply_message_14(L_0);
		V_0 = __this;
		AsyncResult_t2232356043 * L_1 = V_0;
		Monitor_Enter_m2136705809(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
	}

IL_000f:
	try
	{ // begin try (depth: 1)
		{
			__this->set_completed_6((bool)1);
			WaitHandle_t677569169 * L_2 = __this->get_handle_1();
			if (!L_2)
			{
				goto IL_0032;
			}
		}

IL_0021:
		{
			WaitHandle_t677569169 * L_3 = VirtFuncInvoker0< WaitHandle_t677569169 * >::Invoke(8 /* System.Threading.WaitHandle System.Runtime.Remoting.Messaging.AsyncResult::get_AsyncWaitHandle() */, __this);
			EventWaitHandle_Set_m2975776670(((ManualResetEvent_t926074657 *)CastclassSealed(L_3, ManualResetEvent_t926074657_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		}

IL_0032:
		{
			IL2CPP_LEAVE(0x3E, FINALLY_0037);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0037;
	}

FINALLY_0037:
	{ // begin finally (depth: 1)
		AsyncResult_t2232356043 * L_4 = V_0;
		Monitor_Exit_m2677760297(NULL /*static, unused*/, L_4, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(55)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(55)
	{
		IL2CPP_JUMP_TBL(0x3E, IL_003e)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_003e:
	{
		Il2CppObject * L_5 = __this->get_async_callback_8();
		if (!L_5)
		{
			goto IL_005c;
		}
	}
	{
		Il2CppObject * L_6 = __this->get_async_callback_8();
		V_1 = ((AsyncCallback_t163412349 *)CastclassSealed(L_6, AsyncCallback_t163412349_il2cpp_TypeInfo_var));
		AsyncCallback_t163412349 * L_7 = V_1;
		AsyncCallback_Invoke_m1217672441(L_7, __this, /*hidden argument*/NULL);
	}

IL_005c:
	{
		return (Il2CppObject *)NULL;
	}
}
// System.Runtime.Remoting.Messaging.MonoMethodMessage System.Runtime.Remoting.Messaging.AsyncResult::get_CallMessage()
extern "C"  MonoMethodMessage_t771543475 * AsyncResult_get_CallMessage_m3428352375 (AsyncResult_t2232356043 * __this, const MethodInfo* method)
{
	{
		MonoMethodMessage_t771543475 * L_0 = __this->get_call_message_12();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.AsyncResult::set_CallMessage(System.Runtime.Remoting.Messaging.MonoMethodMessage)
extern "C"  void AsyncResult_set_CallMessage_m4011807282 (AsyncResult_t2232356043 * __this, MonoMethodMessage_t771543475 * ___value0, const MethodInfo* method)
{
	{
		MonoMethodMessage_t771543475 * L_0 = ___value0;
		__this->set_call_message_12(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.CallContextRemotingData::.ctor()
extern "C"  void CallContextRemotingData__ctor_m3284361930 (CallContextRemotingData_t2648008188 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.CallContextRemotingData::Clone()
extern Il2CppClass* CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var;
extern const uint32_t CallContextRemotingData_Clone_m2226242476_MetadataUsageId;
extern "C"  Il2CppObject * CallContextRemotingData_Clone_m2226242476 (CallContextRemotingData_t2648008188 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (CallContextRemotingData_Clone_m2226242476_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	CallContextRemotingData_t2648008188 * V_0 = NULL;
	{
		CallContextRemotingData_t2648008188 * L_0 = (CallContextRemotingData_t2648008188 *)il2cpp_codegen_object_new(CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var);
		CallContextRemotingData__ctor_m3284361930(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		CallContextRemotingData_t2648008188 * L_1 = V_0;
		String_t* L_2 = __this->get__logicalCallID_0();
		L_1->set__logicalCallID_0(L_2);
		CallContextRemotingData_t2648008188 * L_3 = V_0;
		return L_3;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ClientContextTerminatorSink::.ctor(System.Runtime.Remoting.Contexts.Context)
extern "C"  void ClientContextTerminatorSink__ctor_m4067561773 (ClientContextTerminatorSink_t3236389774 * __this, Context_t502196753 * ___ctx0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Context_t502196753 * L_0 = ___ctx0;
		__this->set__context_0(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::.ctor(System.Type)
extern "C"  void ConstructionCall__ctor_m1143766850 (ConstructionCall_t1254994451 * __this, Type_t * ___type0, const MethodInfo* method)
{
	{
		MethodCall__ctor_m1871406663(__this, /*hidden argument*/NULL);
		Type_t * L_0 = ___type0;
		__this->set__activationType_14(L_0);
		Type_t * L_1 = ___type0;
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(15 /* System.String System.Type::get_AssemblyQualifiedName() */, L_1);
		__this->set__activationTypeName_15(L_2);
		__this->set__isContextOk_16((bool)1);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void ConstructionCall__ctor_m3260721094 (ConstructionCall_t1254994451 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		MethodCall__ctor_m4106494862(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::InitDictionary()
extern Il2CppClass* ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var;
extern const uint32_t ConstructionCall_InitDictionary_m4046452035_MetadataUsageId;
extern "C"  void ConstructionCall_InitDictionary_m4046452035 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCall_InitDictionary_m4046452035_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ConstructionCallDictionary_t2993650247 * V_0 = NULL;
	{
		ConstructionCallDictionary_t2993650247 * L_0 = (ConstructionCallDictionary_t2993650247 *)il2cpp_codegen_object_new(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		ConstructionCallDictionary__ctor_m202701972(L_0, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		ConstructionCallDictionary_t2993650247 * L_1 = V_0;
		((MethodCall_t2461541281 *)__this)->set_ExternalProperties_8(L_1);
		ConstructionCallDictionary_t2993650247 * L_2 = V_0;
		Il2CppObject * L_3 = MethodDictionary_GetInternalProperties_m1562637947(L_2, /*hidden argument*/NULL);
		((MethodCall_t2461541281 *)__this)->set_InternalProperties_9(L_3);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::set_IsContextOk(System.Boolean)
extern "C"  void ConstructionCall_set_IsContextOk_m90795526 (ConstructionCall_t1254994451 * __this, bool ___value0, const MethodInfo* method)
{
	{
		bool L_0 = ___value0;
		__this->set__isContextOk_16(L_0);
		return;
	}
}
// System.Type System.Runtime.Remoting.Messaging.ConstructionCall::get_ActivationType()
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern const uint32_t ConstructionCall_get_ActivationType_m2706279506_MetadataUsageId;
extern "C"  Type_t * ConstructionCall_get_ActivationType_m2706279506 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCall_get_ActivationType_m2706279506_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Type_t * L_0 = __this->get__activationType_14();
		if (L_0)
		{
			goto IL_001c;
		}
	}
	{
		String_t* L_1 = __this->get__activationTypeName_15();
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_2 = il2cpp_codegen_get_type((Il2CppMethodPointer)&Type_GetType_m773255995, L_1, "mscorlib, Version=2.0.5.0, Culture=neutral, PublicKeyToken=7cec85d7bea7798e");
		__this->set__activationType_14(L_2);
	}

IL_001c:
	{
		Type_t * L_3 = __this->get__activationType_14();
		return L_3;
	}
}
// System.String System.Runtime.Remoting.Messaging.ConstructionCall::get_ActivationTypeName()
extern "C"  String_t* ConstructionCall_get_ActivationTypeName_m2441234710 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__activationTypeName_15();
		return L_0;
	}
}
// System.Runtime.Remoting.Activation.IActivator System.Runtime.Remoting.Messaging.ConstructionCall::get_Activator()
extern "C"  Il2CppObject * ConstructionCall_get_Activator_m2094779222 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get__activator_11();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::set_Activator(System.Runtime.Remoting.Activation.IActivator)
extern "C"  void ConstructionCall_set_Activator_m305409617 (ConstructionCall_t1254994451 * __this, Il2CppObject * ___value0, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___value0;
		__this->set__activator_11(L_0);
		return;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.ConstructionCall::get_CallSiteActivationAttributes()
extern "C"  ObjectU5BU5D_t3614634134* ConstructionCall_get_CallSiteActivationAttributes_m1402996937 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get__activationAttributes_12();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::SetActivationAttributes(System.Object[])
extern "C"  void ConstructionCall_SetActivationAttributes_m1878298372 (ConstructionCall_t1254994451 * __this, ObjectU5BU5D_t3614634134* ___attributes0, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = ___attributes0;
		__this->set__activationAttributes_12(L_0);
		return;
	}
}
// System.Collections.IList System.Runtime.Remoting.Messaging.ConstructionCall::get_ContextProperties()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern const uint32_t ConstructionCall_get_ContextProperties_m3726872436_MetadataUsageId;
extern "C"  Il2CppObject * ConstructionCall_get_ContextProperties_m3726872436 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCall_get_ContextProperties_m3726872436_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = __this->get__contextProperties_13();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		ArrayList_t4252133567 * L_1 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_1, /*hidden argument*/NULL);
		__this->set__contextProperties_13(L_1);
	}

IL_0016:
	{
		Il2CppObject * L_2 = __this->get__contextProperties_13();
		return L_2;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::InitMethodProperty(System.String,System.Object)
extern Il2CppClass* ConstructionCall_t1254994451_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* IActivator_t1538980900_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IList_t3321498491_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral1775101621;
extern Il2CppCodeGenString* _stringLiteral3900537226;
extern Il2CppCodeGenString* _stringLiteral1202959256;
extern Il2CppCodeGenString* _stringLiteral1733972134;
extern Il2CppCodeGenString* _stringLiteral3694332267;
extern const uint32_t ConstructionCall_InitMethodProperty_m735194407_MetadataUsageId;
extern "C"  void ConstructionCall_InitMethodProperty_m735194407 (ConstructionCall_t1254994451 * __this, String_t* ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCall_InitMethodProperty_m735194407_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_00cd;
		}
	}
	{
		Dictionary_2_t3986656710 * L_2 = ((ConstructionCall_t1254994451_StaticFields*)ConstructionCall_t1254994451_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map20_17();
		if (L_2)
		{
			goto IL_005b;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 5, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral1775101621, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral3900537226, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral1202959256, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral1733972134, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral3694332267, 4, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		((ConstructionCall_t1254994451_StaticFields*)ConstructionCall_t1254994451_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map20_17(L_9);
	}

IL_005b:
	{
		Dictionary_2_t3986656710 * L_10 = ((ConstructionCall_t1254994451_StaticFields*)ConstructionCall_t1254994451_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map20_17();
		String_t* L_11 = V_0;
		bool L_12 = Dictionary_2_TryGetValue_m2977303364(L_10, L_11, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_12)
		{
			goto IL_00cd;
		}
	}
	{
		int32_t L_13 = V_2;
		if (L_13 == 0)
		{
			goto IL_008c;
		}
		if (L_13 == 1)
		{
			goto IL_0099;
		}
		if (L_13 == 2)
		{
			goto IL_00a6;
		}
		if (L_13 == 3)
		{
			goto IL_00b3;
		}
		if (L_13 == 4)
		{
			goto IL_00c0;
		}
	}
	{
		goto IL_00cd;
	}

IL_008c:
	{
		Il2CppObject * L_14 = ___value1;
		__this->set__activator_11(((Il2CppObject *)Castclass(L_14, IActivator_t1538980900_il2cpp_TypeInfo_var)));
		return;
	}

IL_0099:
	{
		Il2CppObject * L_15 = ___value1;
		__this->set__activationAttributes_12(((ObjectU5BU5D_t3614634134*)Castclass(L_15, ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var)));
		return;
	}

IL_00a6:
	{
		Il2CppObject * L_16 = ___value1;
		__this->set__activationType_14(((Type_t *)CastclassClass(L_16, Type_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00b3:
	{
		Il2CppObject * L_17 = ___value1;
		__this->set__contextProperties_13(((Il2CppObject *)Castclass(L_17, IList_t3321498491_il2cpp_TypeInfo_var)));
		return;
	}

IL_00c0:
	{
		Il2CppObject * L_18 = ___value1;
		__this->set__activationTypeName_15(((String_t*)CastclassSealed(L_18, String_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00cd:
	{
		String_t* L_19 = ___key0;
		Il2CppObject * L_20 = ___value1;
		MethodCall_InitMethodProperty_m1719565089(__this, L_19, L_20, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCall::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* ICollection_t91669223_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1775101621;
extern Il2CppCodeGenString* _stringLiteral3900537226;
extern Il2CppCodeGenString* _stringLiteral1202959256;
extern Il2CppCodeGenString* _stringLiteral1733972134;
extern Il2CppCodeGenString* _stringLiteral3694332267;
extern const uint32_t ConstructionCall_GetObjectData_m3974358557_MetadataUsageId;
extern "C"  void ConstructionCall_GetObjectData_m3974358557 (ConstructionCall_t1254994451 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCall_GetObjectData_m3974358557_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		StreamingContext_t1417235061  L_1 = ___context1;
		MethodCall_GetObjectData_m3044004255(__this, L_0, L_1, /*hidden argument*/NULL);
		Il2CppObject * L_2 = __this->get__contextProperties_13();
		V_0 = L_2;
		Il2CppObject * L_3 = V_0;
		if (!L_3)
		{
			goto IL_0022;
		}
	}
	{
		Il2CppObject * L_4 = V_0;
		int32_t L_5 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.ICollection::get_Count() */, ICollection_t91669223_il2cpp_TypeInfo_var, L_4);
		if (L_5)
		{
			goto IL_0022;
		}
	}
	{
		V_0 = (Il2CppObject *)NULL;
	}

IL_0022:
	{
		SerializationInfo_t228987430 * L_6 = ___info0;
		Il2CppObject * L_7 = __this->get__activator_11();
		SerializationInfo_AddValue_m1740888931(L_6, _stringLiteral1775101621, L_7, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_8 = ___info0;
		ObjectU5BU5D_t3614634134* L_9 = __this->get__activationAttributes_12();
		SerializationInfo_AddValue_m1740888931(L_8, _stringLiteral3900537226, (Il2CppObject *)(Il2CppObject *)L_9, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_10 = ___info0;
		SerializationInfo_AddValue_m1740888931(L_10, _stringLiteral1202959256, NULL, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_11 = ___info0;
		Il2CppObject * L_12 = V_0;
		SerializationInfo_AddValue_m1740888931(L_11, _stringLiteral1733972134, L_12, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_13 = ___info0;
		String_t* L_14 = __this->get__activationTypeName_15();
		SerializationInfo_AddValue_m1740888931(L_13, _stringLiteral3694332267, L_14, /*hidden argument*/NULL);
		return;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Messaging.ConstructionCall::get_Properties()
extern "C"  Il2CppObject * ConstructionCall_get_Properties_m3492510759 (ConstructionCall_t1254994451 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = MethodCall_get_Properties_m1893707917(__this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCallDictionary::.ctor(System.Runtime.Remoting.Activation.IConstructionCallMessage)
extern Il2CppClass* ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var;
extern const uint32_t ConstructionCallDictionary__ctor_m202701972_MetadataUsageId;
extern "C"  void ConstructionCallDictionary__ctor_m202701972 (ConstructionCallDictionary_t2993650247 * __this, Il2CppObject * ___message0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCallDictionary__ctor_m202701972_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___message0;
		MethodDictionary__ctor_m184006744(__this, L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_1 = ((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->get_InternalKeys_6();
		MethodDictionary_set_MethodKeys_m3180307551(__this, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCallDictionary::.cctor()
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern Il2CppCodeGenString* _stringLiteral3900537226;
extern Il2CppCodeGenString* _stringLiteral1202959256;
extern Il2CppCodeGenString* _stringLiteral1733972134;
extern Il2CppCodeGenString* _stringLiteral1775101621;
extern Il2CppCodeGenString* _stringLiteral3694332267;
extern const uint32_t ConstructionCallDictionary__cctor_m1358813088_MetadataUsageId;
extern "C"  void ConstructionCallDictionary__cctor_m1358813088 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCallDictionary__cctor_m1358813088_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		StringU5BU5D_t1642385972* L_0 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)((int32_t)11)));
		ArrayElementTypeCheck (L_0, _stringLiteral977371278);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral977371278);
		StringU5BU5D_t1642385972* L_1 = L_0;
		ArrayElementTypeCheck (L_1, _stringLiteral3237227266);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3237227266);
		StringU5BU5D_t1642385972* L_2 = L_1;
		ArrayElementTypeCheck (L_2, _stringLiteral3556527655);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral3556527655);
		StringU5BU5D_t1642385972* L_3 = L_2;
		ArrayElementTypeCheck (L_3, _stringLiteral1596268323);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)_stringLiteral1596268323);
		StringU5BU5D_t1642385972* L_4 = L_3;
		ArrayElementTypeCheck (L_4, _stringLiteral1408113411);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral1408113411);
		StringU5BU5D_t1642385972* L_5 = L_4;
		ArrayElementTypeCheck (L_5, _stringLiteral1848363629);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(5), (String_t*)_stringLiteral1848363629);
		StringU5BU5D_t1642385972* L_6 = L_5;
		ArrayElementTypeCheck (L_6, _stringLiteral3900537226);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(6), (String_t*)_stringLiteral3900537226);
		StringU5BU5D_t1642385972* L_7 = L_6;
		ArrayElementTypeCheck (L_7, _stringLiteral1202959256);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(7), (String_t*)_stringLiteral1202959256);
		StringU5BU5D_t1642385972* L_8 = L_7;
		ArrayElementTypeCheck (L_8, _stringLiteral1733972134);
		(L_8)->SetAt(static_cast<il2cpp_array_size_t>(8), (String_t*)_stringLiteral1733972134);
		StringU5BU5D_t1642385972* L_9 = L_8;
		ArrayElementTypeCheck (L_9, _stringLiteral1775101621);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)9)), (String_t*)_stringLiteral1775101621);
		StringU5BU5D_t1642385972* L_10 = L_9;
		ArrayElementTypeCheck (L_10, _stringLiteral3694332267);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)10)), (String_t*)_stringLiteral3694332267);
		((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->set_InternalKeys_6(L_10);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.ConstructionCallDictionary::GetMethodProperty(System.String)
extern Il2CppClass* ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral1775101621;
extern Il2CppCodeGenString* _stringLiteral3900537226;
extern Il2CppCodeGenString* _stringLiteral1202959256;
extern Il2CppCodeGenString* _stringLiteral1733972134;
extern Il2CppCodeGenString* _stringLiteral3694332267;
extern const uint32_t ConstructionCallDictionary_GetMethodProperty_m2294555986_MetadataUsageId;
extern "C"  Il2CppObject * ConstructionCallDictionary_GetMethodProperty_m2294555986 (ConstructionCallDictionary_t2993650247 * __this, String_t* ___key0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCallDictionary_GetMethodProperty_m2294555986_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_00e1;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		Dictionary_2_t3986656710 * L_2 = ((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map23_7();
		if (L_2)
		{
			goto IL_005b;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 5, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral1775101621, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral3900537226, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral1202959256, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral1733972134, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral3694332267, 4, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map23_7(L_9);
	}

IL_005b:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		Dictionary_2_t3986656710 * L_10 = ((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map23_7();
		String_t* L_11 = V_0;
		bool L_12 = Dictionary_2_TryGetValue_m2977303364(L_10, L_11, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_12)
		{
			goto IL_00e1;
		}
	}
	{
		int32_t L_13 = V_2;
		if (L_13 == 0)
		{
			goto IL_008c;
		}
		if (L_13 == 1)
		{
			goto IL_009d;
		}
		if (L_13 == 2)
		{
			goto IL_00ae;
		}
		if (L_13 == 3)
		{
			goto IL_00bf;
		}
		if (L_13 == 4)
		{
			goto IL_00d0;
		}
	}
	{
		goto IL_00e1;
	}

IL_008c:
	{
		Il2CppObject * L_14 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		Il2CppObject * L_15 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(2 /* System.Runtime.Remoting.Activation.IActivator System.Runtime.Remoting.Activation.IConstructionCallMessage::get_Activator() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_14, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)));
		return L_15;
	}

IL_009d:
	{
		Il2CppObject * L_16 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		ObjectU5BU5D_t3614634134* L_17 = InterfaceFuncInvoker0< ObjectU5BU5D_t3614634134* >::Invoke(4 /* System.Object[] System.Runtime.Remoting.Activation.IConstructionCallMessage::get_CallSiteActivationAttributes() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_16, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)));
		return (Il2CppObject *)L_17;
	}

IL_00ae:
	{
		Il2CppObject * L_18 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		Type_t * L_19 = InterfaceFuncInvoker0< Type_t * >::Invoke(0 /* System.Type System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ActivationType() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_18, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)));
		return L_19;
	}

IL_00bf:
	{
		Il2CppObject * L_20 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		Il2CppObject * L_21 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(5 /* System.Collections.IList System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ContextProperties() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_20, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)));
		return L_21;
	}

IL_00d0:
	{
		Il2CppObject * L_22 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		String_t* L_23 = InterfaceFuncInvoker0< String_t* >::Invoke(1 /* System.String System.Runtime.Remoting.Activation.IConstructionCallMessage::get_ActivationTypeName() */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_22, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)));
		return L_23;
	}

IL_00e1:
	{
		String_t* L_24 = ___key0;
		Il2CppObject * L_25 = MethodDictionary_GetMethodProperty_m4085857742(__this, L_24, /*hidden argument*/NULL);
		return L_25;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ConstructionCallDictionary::SetMethodProperty(System.String,System.Object)
extern Il2CppClass* ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var;
extern Il2CppClass* IActivator_t1538980900_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral1775101621;
extern Il2CppCodeGenString* _stringLiteral3900537226;
extern Il2CppCodeGenString* _stringLiteral1202959256;
extern Il2CppCodeGenString* _stringLiteral1733972134;
extern Il2CppCodeGenString* _stringLiteral3694332267;
extern Il2CppCodeGenString* _stringLiteral2244542343;
extern const uint32_t ConstructionCallDictionary_SetMethodProperty_m4066336487_MetadataUsageId;
extern "C"  void ConstructionCallDictionary_SetMethodProperty_m4066336487 (ConstructionCallDictionary_t2993650247 * __this, String_t* ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ConstructionCallDictionary_SetMethodProperty_m4066336487_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_00a5;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		Dictionary_2_t3986656710 * L_2 = ((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map24_8();
		if (L_2)
		{
			goto IL_005b;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 5, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral1775101621, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral3900537226, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral1202959256, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral1733972134, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral3694332267, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map24_8(L_9);
	}

IL_005b:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var);
		Dictionary_2_t3986656710 * L_10 = ((ConstructionCallDictionary_t2993650247_StaticFields*)ConstructionCallDictionary_t2993650247_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map24_8();
		String_t* L_11 = V_0;
		bool L_12 = Dictionary_2_TryGetValue_m2977303364(L_10, L_11, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_12)
		{
			goto IL_00a5;
		}
	}
	{
		int32_t L_13 = V_2;
		if (!L_13)
		{
			goto IL_007f;
		}
	}
	{
		int32_t L_14 = V_2;
		if ((((int32_t)L_14) == ((int32_t)1)))
		{
			goto IL_009a;
		}
	}
	{
		goto IL_00a5;
	}

IL_007f:
	{
		Il2CppObject * L_15 = ((MethodDictionary_t1742974787 *)__this)->get__message_1();
		Il2CppObject * L_16 = ___value1;
		InterfaceActionInvoker1< Il2CppObject * >::Invoke(3 /* System.Void System.Runtime.Remoting.Activation.IConstructionCallMessage::set_Activator(System.Runtime.Remoting.Activation.IActivator) */, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_15, IConstructionCallMessage_t2459197515_il2cpp_TypeInfo_var)), ((Il2CppObject *)Castclass(L_16, IActivator_t1538980900_il2cpp_TypeInfo_var)));
		goto IL_00b2;
	}

IL_009a:
	{
		ArgumentException_t3259014390 * L_17 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_17, _stringLiteral2244542343, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_17);
	}

IL_00a5:
	{
		String_t* L_18 = ___key0;
		Il2CppObject * L_19 = ___value1;
		MethodDictionary_SetMethodProperty_m1502558295(__this, L_18, L_19, /*hidden argument*/NULL);
		goto IL_00b2;
	}

IL_00b2:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.EnvoyTerminatorSink::.ctor()
extern "C"  void EnvoyTerminatorSink__ctor_m3818538535 (EnvoyTerminatorSink_t3043186997 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.EnvoyTerminatorSink::.cctor()
extern Il2CppClass* EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var;
extern const uint32_t EnvoyTerminatorSink__cctor_m297472550_MetadataUsageId;
extern "C"  void EnvoyTerminatorSink__cctor_m297472550 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (EnvoyTerminatorSink__cctor_m297472550_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		EnvoyTerminatorSink_t3043186997 * L_0 = (EnvoyTerminatorSink_t3043186997 *)il2cpp_codegen_object_new(EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var);
		EnvoyTerminatorSink__ctor_m3818538535(L_0, /*hidden argument*/NULL);
		((EnvoyTerminatorSink_t3043186997_StaticFields*)EnvoyTerminatorSink_t3043186997_il2cpp_TypeInfo_var->static_fields)->set_Instance_0(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.Header::.ctor(System.String,System.Object)
extern "C"  void Header__ctor_m2343509405 (Header_t2756440555 * __this, String_t* ____Name0, Il2CppObject * ____Value1, const MethodInfo* method)
{
	{
		String_t* L_0 = ____Name0;
		Il2CppObject * L_1 = ____Value1;
		Header__ctor_m2134155358(__this, L_0, L_1, (bool)1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.Header::.ctor(System.String,System.Object,System.Boolean)
extern "C"  void Header__ctor_m2134155358 (Header_t2756440555 * __this, String_t* ____Name0, Il2CppObject * ____Value1, bool ____MustUnderstand2, const MethodInfo* method)
{
	{
		String_t* L_0 = ____Name0;
		Il2CppObject * L_1 = ____Value1;
		bool L_2 = ____MustUnderstand2;
		Header__ctor_m1112388478(__this, L_0, L_1, L_2, (String_t*)NULL, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.Header::.ctor(System.String,System.Object,System.Boolean,System.String)
extern "C"  void Header__ctor_m1112388478 (Header_t2756440555 * __this, String_t* ____Name0, Il2CppObject * ____Value1, bool ____MustUnderstand2, String_t* ____HeaderNamespace3, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		String_t* L_0 = ____Name0;
		__this->set_Name_2(L_0);
		Il2CppObject * L_1 = ____Value1;
		__this->set_Value_3(L_1);
		bool L_2 = ____MustUnderstand2;
		__this->set_MustUnderstand_1(L_2);
		String_t* L_3 = ____HeaderNamespace3;
		__this->set_HeaderNamespace_0(L_3);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.HeaderHandler::.ctor(System.Object,System.IntPtr)
extern "C"  void HeaderHandler__ctor_m1188437685 (HeaderHandler_t324204131 * __this, Il2CppObject * ___object0, IntPtr_t ___method1, const MethodInfo* method)
{
	__this->set_method_ptr_0((Il2CppMethodPointer)((MethodInfo*)___method1.get_m_value_0())->methodPointer);
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Object System.Runtime.Remoting.Messaging.HeaderHandler::Invoke(System.Runtime.Remoting.Messaging.Header[])
extern "C"  Il2CppObject * HeaderHandler_Invoke_m560790415 (HeaderHandler_t324204131 * __this, HeaderU5BU5D_t2408360458* ___headers0, const MethodInfo* method)
{
	if(__this->get_prev_9() != NULL)
	{
		HeaderHandler_Invoke_m560790415((HeaderHandler_t324204131 *)__this->get_prev_9(),___headers0, method);
	}
	il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	bool ___methodIsStatic = MethodIsStatic((MethodInfo*)(__this->get_method_3().get_m_value_0()));
	if (__this->get_m_target_2() != NULL && ___methodIsStatic)
	{
		typedef Il2CppObject * (*FunctionPointerType) (Il2CppObject *, void* __this, HeaderU5BU5D_t2408360458* ___headers0, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(NULL,il2cpp_codegen_get_delegate_this(__this),___headers0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else if (__this->get_m_target_2() != NULL || ___methodIsStatic)
	{
		typedef Il2CppObject * (*FunctionPointerType) (void* __this, HeaderU5BU5D_t2408360458* ___headers0, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(il2cpp_codegen_get_delegate_this(__this),___headers0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
	else
	{
		typedef Il2CppObject * (*FunctionPointerType) (void* __this, const MethodInfo* method);
		return ((FunctionPointerType)__this->get_method_ptr_0())(___headers0,(MethodInfo*)(__this->get_method_3().get_m_value_0()));
	}
}
// System.IAsyncResult System.Runtime.Remoting.Messaging.HeaderHandler::BeginInvoke(System.Runtime.Remoting.Messaging.Header[],System.AsyncCallback,System.Object)
extern "C"  Il2CppObject * HeaderHandler_BeginInvoke_m3377516457 (HeaderHandler_t324204131 * __this, HeaderU5BU5D_t2408360458* ___headers0, AsyncCallback_t163412349 * ___callback1, Il2CppObject * ___object2, const MethodInfo* method)
{
	void *__d_args[2] = {0};
	__d_args[0] = ___headers0;
	return (Il2CppObject *)il2cpp_delegate_begin_invoke((Il2CppDelegate*)__this, __d_args, (Il2CppDelegate*)___callback1, (Il2CppObject*)___object2);
}
// System.Object System.Runtime.Remoting.Messaging.HeaderHandler::EndInvoke(System.IAsyncResult)
extern "C"  Il2CppObject * HeaderHandler_EndInvoke_m358364460 (HeaderHandler_t324204131 * __this, Il2CppObject * ___result0, const MethodInfo* method)
{
	Il2CppObject *__result = il2cpp_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
	return (Il2CppObject *)__result;
}
// System.Void System.Runtime.Remoting.Messaging.LogicalCallContext::.ctor()
extern Il2CppClass* CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var;
extern const uint32_t LogicalCallContext__ctor_m252561004_MetadataUsageId;
extern "C"  void LogicalCallContext__ctor_m252561004 (LogicalCallContext_t725724420 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LogicalCallContext__ctor_m252561004_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		CallContextRemotingData_t2648008188 * L_0 = (CallContextRemotingData_t2648008188 *)il2cpp_codegen_object_new(CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var);
		CallContextRemotingData__ctor_m3284361930(L_0, /*hidden argument*/NULL);
		__this->set__remotingData_1(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.LogicalCallContext::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2696048325;
extern const uint32_t LogicalCallContext__ctor_m3173272863_MetadataUsageId;
extern "C"  void LogicalCallContext__ctor_m3173272863 (LogicalCallContext_t725724420 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LogicalCallContext__ctor_m3173272863_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	SerializationEntry_t3485203212  V_0;
	memset(&V_0, 0, sizeof(V_0));
	SerializationInfoEnumerator_t589103770 * V_1 = NULL;
	{
		CallContextRemotingData_t2648008188 * L_0 = (CallContextRemotingData_t2648008188 *)il2cpp_codegen_object_new(CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var);
		CallContextRemotingData__ctor_m3284361930(L_0, /*hidden argument*/NULL);
		__this->set__remotingData_1(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_1 = ___info0;
		SerializationInfoEnumerator_t589103770 * L_2 = SerializationInfo_GetEnumerator_m2402005737(L_1, /*hidden argument*/NULL);
		V_1 = L_2;
		goto IL_0065;
	}

IL_001d:
	{
		SerializationInfoEnumerator_t589103770 * L_3 = V_1;
		SerializationEntry_t3485203212  L_4 = SerializationInfoEnumerator_get_Current_m173929557(L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		String_t* L_5 = SerializationEntry_get_Name_m3087969704((&V_0), /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_5, _stringLiteral2696048325, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0051;
		}
	}
	{
		Il2CppObject * L_7 = SerializationEntry_get_Value_m1628109884((&V_0), /*hidden argument*/NULL);
		__this->set__remotingData_1(((CallContextRemotingData_t2648008188 *)CastclassClass(L_7, CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var)));
		goto IL_0065;
	}

IL_0051:
	{
		String_t* L_8 = SerializationEntry_get_Name_m3087969704((&V_0), /*hidden argument*/NULL);
		Il2CppObject * L_9 = SerializationEntry_get_Value_m1628109884((&V_0), /*hidden argument*/NULL);
		LogicalCallContext_SetData_m2089833592(__this, L_8, L_9, /*hidden argument*/NULL);
	}

IL_0065:
	{
		SerializationInfoEnumerator_t589103770 * L_10 = V_1;
		bool L_11 = SerializationInfoEnumerator_MoveNext_m1876990879(L_10, /*hidden argument*/NULL);
		if (L_11)
		{
			goto IL_001d;
		}
	}
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.LogicalCallContext::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DictionaryEntry_t3048875398_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2696048325;
extern const uint32_t LogicalCallContext_GetObjectData_m104142736_MetadataUsageId;
extern "C"  void LogicalCallContext_GetObjectData_m104142736 (LogicalCallContext_t725724420 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LogicalCallContext_GetObjectData_m104142736_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		CallContextRemotingData_t2648008188 * L_1 = __this->get__remotingData_1();
		SerializationInfo_AddValue_m1740888931(L_0, _stringLiteral2696048325, L_1, /*hidden argument*/NULL);
		Hashtable_t909839986 * L_2 = __this->get__data_0();
		if (!L_2)
		{
			goto IL_0074;
		}
	}
	{
		Hashtable_t909839986 * L_3 = __this->get__data_0();
		Il2CppObject * L_4 = VirtFuncInvoker0< Il2CppObject * >::Invoke(28 /* System.Collections.IDictionaryEnumerator System.Collections.Hashtable::GetEnumerator() */, L_3);
		V_1 = L_4;
	}

IL_0028:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0052;
		}

IL_002d:
		{
			Il2CppObject * L_5 = V_1;
			Il2CppObject * L_6 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_5);
			V_0 = ((*(DictionaryEntry_t3048875398 *)((DictionaryEntry_t3048875398 *)UnBox (L_6, DictionaryEntry_t3048875398_il2cpp_TypeInfo_var))));
			SerializationInfo_t228987430 * L_7 = ___info0;
			Il2CppObject * L_8 = DictionaryEntry_get_Key_m3623293571((&V_0), /*hidden argument*/NULL);
			Il2CppObject * L_9 = DictionaryEntry_get_Value_m2812883243((&V_0), /*hidden argument*/NULL);
			SerializationInfo_AddValue_m1740888931(L_7, ((String_t*)CastclassSealed(L_8, String_t_il2cpp_TypeInfo_var)), L_9, /*hidden argument*/NULL);
		}

IL_0052:
		{
			Il2CppObject * L_10 = V_1;
			bool L_11 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_10);
			if (L_11)
			{
				goto IL_002d;
			}
		}

IL_005d:
		{
			IL2CPP_LEAVE(0x74, FINALLY_0062);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0062;
	}

FINALLY_0062:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_12 = V_1;
			V_2 = ((Il2CppObject *)IsInst(L_12, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_13 = V_2;
			if (L_13)
			{
				goto IL_006d;
			}
		}

IL_006c:
		{
			IL2CPP_END_FINALLY(98)
		}

IL_006d:
		{
			Il2CppObject * L_14 = V_2;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_14);
			IL2CPP_END_FINALLY(98)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(98)
	{
		IL2CPP_JUMP_TBL(0x74, IL_0074)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_0074:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.LogicalCallContext::SetData(System.String,System.Object)
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern const uint32_t LogicalCallContext_SetData_m2089833592_MetadataUsageId;
extern "C"  void LogicalCallContext_SetData_m2089833592 (LogicalCallContext_t725724420 * __this, String_t* ___name0, Il2CppObject * ___data1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LogicalCallContext_SetData_m2089833592_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Hashtable_t909839986 * L_0 = __this->get__data_0();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		Hashtable_t909839986 * L_1 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_1, /*hidden argument*/NULL);
		__this->set__data_0(L_1);
	}

IL_0016:
	{
		Hashtable_t909839986 * L_2 = __this->get__data_0();
		String_t* L_3 = ___name0;
		Il2CppObject * L_4 = ___data1;
		VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(23 /* System.Void System.Collections.Hashtable::set_Item(System.Object,System.Object) */, L_2, L_3, L_4);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.LogicalCallContext::Clone()
extern Il2CppClass* LogicalCallContext_t725724420_il2cpp_TypeInfo_var;
extern Il2CppClass* CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var;
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DictionaryEntry_t3048875398_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t LogicalCallContext_Clone_m2776857116_MetadataUsageId;
extern "C"  Il2CppObject * LogicalCallContext_Clone_m2776857116 (LogicalCallContext_t725724420 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (LogicalCallContext_Clone_m2776857116_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	LogicalCallContext_t725724420 * V_0 = NULL;
	DictionaryEntry_t3048875398  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Il2CppObject * V_2 = NULL;
	Il2CppObject * V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		LogicalCallContext_t725724420 * L_0 = (LogicalCallContext_t725724420 *)il2cpp_codegen_object_new(LogicalCallContext_t725724420_il2cpp_TypeInfo_var);
		LogicalCallContext__ctor_m252561004(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		LogicalCallContext_t725724420 * L_1 = V_0;
		CallContextRemotingData_t2648008188 * L_2 = __this->get__remotingData_1();
		Il2CppObject * L_3 = CallContextRemotingData_Clone_m2226242476(L_2, /*hidden argument*/NULL);
		L_1->set__remotingData_1(((CallContextRemotingData_t2648008188 *)CastclassClass(L_3, CallContextRemotingData_t2648008188_il2cpp_TypeInfo_var)));
		Hashtable_t909839986 * L_4 = __this->get__data_0();
		if (!L_4)
		{
			goto IL_008a;
		}
	}
	{
		LogicalCallContext_t725724420 * L_5 = V_0;
		Hashtable_t909839986 * L_6 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_6, /*hidden argument*/NULL);
		L_5->set__data_0(L_6);
		Hashtable_t909839986 * L_7 = __this->get__data_0();
		Il2CppObject * L_8 = VirtFuncInvoker0< Il2CppObject * >::Invoke(28 /* System.Collections.IDictionaryEnumerator System.Collections.Hashtable::GetEnumerator() */, L_7);
		V_2 = L_8;
	}

IL_003e:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0068;
		}

IL_0043:
		{
			Il2CppObject * L_9 = V_2;
			Il2CppObject * L_10 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_9);
			V_1 = ((*(DictionaryEntry_t3048875398 *)((DictionaryEntry_t3048875398 *)UnBox (L_10, DictionaryEntry_t3048875398_il2cpp_TypeInfo_var))));
			LogicalCallContext_t725724420 * L_11 = V_0;
			Hashtable_t909839986 * L_12 = L_11->get__data_0();
			Il2CppObject * L_13 = DictionaryEntry_get_Key_m3623293571((&V_1), /*hidden argument*/NULL);
			Il2CppObject * L_14 = DictionaryEntry_get_Value_m2812883243((&V_1), /*hidden argument*/NULL);
			VirtActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(23 /* System.Void System.Collections.Hashtable::set_Item(System.Object,System.Object) */, L_12, L_13, L_14);
		}

IL_0068:
		{
			Il2CppObject * L_15 = V_2;
			bool L_16 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_15);
			if (L_16)
			{
				goto IL_0043;
			}
		}

IL_0073:
		{
			IL2CPP_LEAVE(0x8A, FINALLY_0078);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0078;
	}

FINALLY_0078:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_17 = V_2;
			V_3 = ((Il2CppObject *)IsInst(L_17, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_18 = V_3;
			if (L_18)
			{
				goto IL_0083;
			}
		}

IL_0082:
		{
			IL2CPP_END_FINALLY(120)
		}

IL_0083:
		{
			Il2CppObject * L_19 = V_3;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_19);
			IL2CPP_END_FINALLY(120)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(120)
	{
		IL2CPP_JUMP_TBL(0x8A, IL_008a)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_008a:
	{
		LogicalCallContext_t725724420 * L_20 = V_0;
		return L_20;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::.ctor(System.Runtime.Remoting.Messaging.Header[])
extern "C"  void MethodCall__ctor_m646635320 (MethodCall_t2461541281 * __this, HeaderU5BU5D_t2408360458* ___h10, const MethodInfo* method)
{
	Header_t2756440555 * V_0 = NULL;
	HeaderU5BU5D_t2408360458* V_1 = NULL;
	int32_t V_2 = 0;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		VirtActionInvoker0::Invoke(18 /* System.Void System.Runtime.Remoting.Messaging.MethodCall::Init() */, __this);
		HeaderU5BU5D_t2408360458* L_0 = ___h10;
		if (!L_0)
		{
			goto IL_001a;
		}
	}
	{
		HeaderU5BU5D_t2408360458* L_1 = ___h10;
		if ((((int32_t)((int32_t)(((Il2CppArray *)L_1)->max_length)))))
		{
			goto IL_001b;
		}
	}

IL_001a:
	{
		return;
	}

IL_001b:
	{
		HeaderU5BU5D_t2408360458* L_2 = ___h10;
		V_1 = L_2;
		V_2 = 0;
		goto IL_003e;
	}

IL_0024:
	{
		HeaderU5BU5D_t2408360458* L_3 = V_1;
		int32_t L_4 = V_2;
		int32_t L_5 = L_4;
		Header_t2756440555 * L_6 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_5));
		V_0 = L_6;
		Header_t2756440555 * L_7 = V_0;
		String_t* L_8 = L_7->get_Name_2();
		Header_t2756440555 * L_9 = V_0;
		Il2CppObject * L_10 = L_9->get_Value_3();
		VirtActionInvoker2< String_t*, Il2CppObject * >::Invoke(13 /* System.Void System.Runtime.Remoting.Messaging.MethodCall::InitMethodProperty(System.String,System.Object) */, __this, L_8, L_10);
		int32_t L_11 = V_2;
		V_2 = ((int32_t)((int32_t)L_11+(int32_t)1));
	}

IL_003e:
	{
		int32_t L_12 = V_2;
		HeaderU5BU5D_t2408360458* L_13 = V_1;
		if ((((int32_t)L_12) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_13)->max_length)))))))
		{
			goto IL_0024;
		}
	}
	{
		MethodCall_ResolveMethod_m3858310828(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern "C"  void MethodCall__ctor_m4106494862 (MethodCall_t2461541281 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	SerializationEntry_t3485203212  V_0;
	memset(&V_0, 0, sizeof(V_0));
	SerializationInfoEnumerator_t589103770 * V_1 = NULL;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		VirtActionInvoker0::Invoke(18 /* System.Void System.Runtime.Remoting.Messaging.MethodCall::Init() */, __this);
		SerializationInfo_t228987430 * L_0 = ___info0;
		SerializationInfoEnumerator_t589103770 * L_1 = SerializationInfo_GetEnumerator_m2402005737(L_0, /*hidden argument*/NULL);
		V_1 = L_1;
		goto IL_0033;
	}

IL_0018:
	{
		SerializationInfoEnumerator_t589103770 * L_2 = V_1;
		SerializationEntry_t3485203212  L_3 = SerializationInfoEnumerator_get_Current_m173929557(L_2, /*hidden argument*/NULL);
		V_0 = L_3;
		String_t* L_4 = SerializationEntry_get_Name_m3087969704((&V_0), /*hidden argument*/NULL);
		Il2CppObject * L_5 = SerializationEntry_get_Value_m1628109884((&V_0), /*hidden argument*/NULL);
		VirtActionInvoker2< String_t*, Il2CppObject * >::Invoke(13 /* System.Void System.Runtime.Remoting.Messaging.MethodCall::InitMethodProperty(System.String,System.Object) */, __this, L_4, L_5);
	}

IL_0033:
	{
		SerializationInfoEnumerator_t589103770 * L_6 = V_1;
		bool L_7 = SerializationInfoEnumerator_MoveNext_m1876990879(L_6, /*hidden argument*/NULL);
		if (L_7)
		{
			goto IL_0018;
		}
	}
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::.ctor()
extern "C"  void MethodCall__ctor_m1871406663 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::System.Runtime.Remoting.Messaging.IInternalMessage.set_Uri(System.String)
extern "C"  void MethodCall_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m3499697771 (MethodCall_t2461541281 * __this, String_t* ___value0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___value0;
		MethodCall_set_Uri_m2512888818(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::InitMethodProperty(System.String,System.Object)
extern Il2CppClass* MethodCall_t2461541281_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* LogicalCallContext_t725724420_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral1469853933;
extern const uint32_t MethodCall_InitMethodProperty_m1719565089_MetadataUsageId;
extern "C"  void MethodCall_InitMethodProperty_m1719565089 (MethodCall_t2461541281 * __this, String_t* ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_InitMethodProperty_m1719565089_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_0107;
		}
	}
	{
		Dictionary_2_t3986656710 * L_2 = ((MethodCall_t2461541281_StaticFields*)MethodCall_t2461541281_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map1F_10();
		if (L_2)
		{
			goto IL_0073;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 7, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral3556527655, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral3237227266, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral1596268323, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral1408113411, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral1848363629, 4, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		Dictionary_2_Add_m1209957957(L_9, _stringLiteral977371278, 5, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_10 = V_1;
		Dictionary_2_Add_m1209957957(L_10, _stringLiteral1469853933, 6, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_11 = V_1;
		((MethodCall_t2461541281_StaticFields*)MethodCall_t2461541281_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map1F_10(L_11);
	}

IL_0073:
	{
		Dictionary_2_t3986656710 * L_12 = ((MethodCall_t2461541281_StaticFields*)MethodCall_t2461541281_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map1F_10();
		String_t* L_13 = V_0;
		bool L_14 = Dictionary_2_TryGetValue_m2977303364(L_12, L_13, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_14)
		{
			goto IL_0107;
		}
	}
	{
		int32_t L_15 = V_2;
		if (L_15 == 0)
		{
			goto IL_00ac;
		}
		if (L_15 == 1)
		{
			goto IL_00b9;
		}
		if (L_15 == 2)
		{
			goto IL_00c6;
		}
		if (L_15 == 3)
		{
			goto IL_00d3;
		}
		if (L_15 == 4)
		{
			goto IL_00e0;
		}
		if (L_15 == 5)
		{
			goto IL_00ed;
		}
		if (L_15 == 6)
		{
			goto IL_00fa;
		}
	}
	{
		goto IL_0107;
	}

IL_00ac:
	{
		Il2CppObject * L_16 = ___value1;
		__this->set__typeName_1(((String_t*)CastclassSealed(L_16, String_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00b9:
	{
		Il2CppObject * L_17 = ___value1;
		__this->set__methodName_2(((String_t*)CastclassSealed(L_17, String_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00c6:
	{
		Il2CppObject * L_18 = ___value1;
		__this->set__methodSignature_4(((TypeU5BU5D_t1664964607*)Castclass(L_18, TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var)));
		return;
	}

IL_00d3:
	{
		Il2CppObject * L_19 = ___value1;
		__this->set__args_3(((ObjectU5BU5D_t3614634134*)Castclass(L_19, ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var)));
		return;
	}

IL_00e0:
	{
		Il2CppObject * L_20 = ___value1;
		__this->set__callContext_6(((LogicalCallContext_t725724420 *)CastclassSealed(L_20, LogicalCallContext_t725724420_il2cpp_TypeInfo_var)));
		return;
	}

IL_00ed:
	{
		Il2CppObject * L_21 = ___value1;
		__this->set__uri_0(((String_t*)CastclassSealed(L_21, String_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00fa:
	{
		Il2CppObject * L_22 = ___value1;
		__this->set__genericArguments_7(((TypeU5BU5D_t1664964607*)Castclass(L_22, TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var)));
		return;
	}

IL_0107:
	{
		Il2CppObject * L_23 = VirtFuncInvoker0< Il2CppObject * >::Invoke(15 /* System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodCall::get_Properties() */, __this);
		String_t* L_24 = ___key0;
		Il2CppObject * L_25 = ___value1;
		InterfaceActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(1 /* System.Void System.Collections.IDictionary::set_Item(System.Object,System.Object) */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_23, L_24, L_25);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::GetObjectData(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DictionaryEntry_t3048875398_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral1469853933;
extern const uint32_t MethodCall_GetObjectData_m3044004255_MetadataUsageId;
extern "C"  void MethodCall_GetObjectData_m3044004255 (MethodCall_t2461541281 * __this, SerializationInfo_t228987430 * ___info0, StreamingContext_t1417235061  ___context1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_GetObjectData_m3044004255_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Il2CppObject * V_1 = NULL;
	Il2CppObject * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		SerializationInfo_t228987430 * L_0 = ___info0;
		String_t* L_1 = __this->get__typeName_1();
		SerializationInfo_AddValue_m1740888931(L_0, _stringLiteral3556527655, L_1, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_2 = ___info0;
		String_t* L_3 = __this->get__methodName_2();
		SerializationInfo_AddValue_m1740888931(L_2, _stringLiteral3237227266, L_3, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_4 = ___info0;
		TypeU5BU5D_t1664964607* L_5 = __this->get__methodSignature_4();
		SerializationInfo_AddValue_m1740888931(L_4, _stringLiteral1596268323, (Il2CppObject *)(Il2CppObject *)L_5, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_6 = ___info0;
		ObjectU5BU5D_t3614634134* L_7 = __this->get__args_3();
		SerializationInfo_AddValue_m1740888931(L_6, _stringLiteral1408113411, (Il2CppObject *)(Il2CppObject *)L_7, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_8 = ___info0;
		LogicalCallContext_t725724420 * L_9 = __this->get__callContext_6();
		SerializationInfo_AddValue_m1740888931(L_8, _stringLiteral1848363629, L_9, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_10 = ___info0;
		String_t* L_11 = __this->get__uri_0();
		SerializationInfo_AddValue_m1740888931(L_10, _stringLiteral977371278, L_11, /*hidden argument*/NULL);
		SerializationInfo_t228987430 * L_12 = ___info0;
		TypeU5BU5D_t1664964607* L_13 = __this->get__genericArguments_7();
		SerializationInfo_AddValue_m1740888931(L_12, _stringLiteral1469853933, (Il2CppObject *)(Il2CppObject *)L_13, /*hidden argument*/NULL);
		Il2CppObject * L_14 = __this->get_InternalProperties_9();
		if (!L_14)
		{
			goto IL_00da;
		}
	}
	{
		Il2CppObject * L_15 = __this->get_InternalProperties_9();
		Il2CppObject * L_16 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(3 /* System.Collections.IDictionaryEnumerator System.Collections.IDictionary::GetEnumerator() */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_15);
		V_1 = L_16;
	}

IL_008e:
	try
	{ // begin try (depth: 1)
		{
			goto IL_00b8;
		}

IL_0093:
		{
			Il2CppObject * L_17 = V_1;
			Il2CppObject * L_18 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_17);
			V_0 = ((*(DictionaryEntry_t3048875398 *)((DictionaryEntry_t3048875398 *)UnBox (L_18, DictionaryEntry_t3048875398_il2cpp_TypeInfo_var))));
			SerializationInfo_t228987430 * L_19 = ___info0;
			Il2CppObject * L_20 = DictionaryEntry_get_Key_m3623293571((&V_0), /*hidden argument*/NULL);
			Il2CppObject * L_21 = DictionaryEntry_get_Value_m2812883243((&V_0), /*hidden argument*/NULL);
			SerializationInfo_AddValue_m1740888931(L_19, ((String_t*)CastclassSealed(L_20, String_t_il2cpp_TypeInfo_var)), L_21, /*hidden argument*/NULL);
		}

IL_00b8:
		{
			Il2CppObject * L_22 = V_1;
			bool L_23 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_22);
			if (L_23)
			{
				goto IL_0093;
			}
		}

IL_00c3:
		{
			IL2CPP_LEAVE(0xDA, FINALLY_00c8);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_00c8;
	}

FINALLY_00c8:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_24 = V_1;
			V_2 = ((Il2CppObject *)IsInst(L_24, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_25 = V_2;
			if (L_25)
			{
				goto IL_00d3;
			}
		}

IL_00d2:
		{
			IL2CPP_END_FINALLY(200)
		}

IL_00d3:
		{
			Il2CppObject * L_26 = V_2;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_26);
			IL2CPP_END_FINALLY(200)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(200)
	{
		IL2CPP_JUMP_TBL(0xDA, IL_00da)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00da:
	{
		return;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.MethodCall::get_Args()
extern "C"  ObjectU5BU5D_t3614634134* MethodCall_get_Args_m1494813934 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get__args_3();
		return L_0;
	}
}
// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.MethodCall::get_LogicalCallContext()
extern Il2CppClass* LogicalCallContext_t725724420_il2cpp_TypeInfo_var;
extern const uint32_t MethodCall_get_LogicalCallContext_m3769562079_MetadataUsageId;
extern "C"  LogicalCallContext_t725724420 * MethodCall_get_LogicalCallContext_m3769562079 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_get_LogicalCallContext_m3769562079_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		LogicalCallContext_t725724420 * L_0 = __this->get__callContext_6();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		LogicalCallContext_t725724420 * L_1 = (LogicalCallContext_t725724420 *)il2cpp_codegen_object_new(LogicalCallContext_t725724420_il2cpp_TypeInfo_var);
		LogicalCallContext__ctor_m252561004(L_1, /*hidden argument*/NULL);
		__this->set__callContext_6(L_1);
	}

IL_0016:
	{
		LogicalCallContext_t725724420 * L_2 = __this->get__callContext_6();
		return L_2;
	}
}
// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.MethodCall::get_MethodBase()
extern "C"  MethodBase_t904190842 * MethodCall_get_MethodBase_m688041003 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		MethodBase_t904190842 * L_0 = __this->get__methodBase_5();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		MethodCall_ResolveMethod_m3858310828(__this, /*hidden argument*/NULL);
	}

IL_0011:
	{
		MethodBase_t904190842 * L_1 = __this->get__methodBase_5();
		return L_1;
	}
}
// System.String System.Runtime.Remoting.Messaging.MethodCall::get_MethodName()
extern "C"  String_t* MethodCall_get_MethodName_m257326115 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__methodName_2();
		if (L_0)
		{
			goto IL_001c;
		}
	}
	{
		MethodBase_t904190842 * L_1 = __this->get__methodBase_5();
		String_t* L_2 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_1);
		__this->set__methodName_2(L_2);
	}

IL_001c:
	{
		String_t* L_3 = __this->get__methodName_2();
		return L_3;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodCall::get_MethodSignature()
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t MethodCall_get_MethodSignature_m2288901594_MetadataUsageId;
extern "C"  Il2CppObject * MethodCall_get_MethodSignature_m2288901594 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_get_MethodSignature_m2288901594_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get__methodSignature_4();
		if (L_0)
		{
			goto IL_0054;
		}
	}
	{
		MethodBase_t904190842 * L_1 = __this->get__methodBase_5();
		if (!L_1)
		{
			goto IL_0054;
		}
	}
	{
		MethodBase_t904190842 * L_2 = __this->get__methodBase_5();
		ParameterInfoU5BU5D_t2275869610* L_3 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_2);
		V_0 = L_3;
		ParameterInfoU5BU5D_t2275869610* L_4 = V_0;
		__this->set__methodSignature_4(((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length)))))));
		V_1 = 0;
		goto IL_004b;
	}

IL_0037:
	{
		TypeU5BU5D_t1664964607* L_5 = __this->get__methodSignature_4();
		int32_t L_6 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_7 = V_0;
		int32_t L_8 = V_1;
		int32_t L_9 = L_8;
		ParameterInfo_t2249040075 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		Type_t * L_11 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_10);
		ArrayElementTypeCheck (L_5, L_11);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(L_6), (Type_t *)L_11);
		int32_t L_12 = V_1;
		V_1 = ((int32_t)((int32_t)L_12+(int32_t)1));
	}

IL_004b:
	{
		int32_t L_13 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_14 = V_0;
		if ((((int32_t)L_13) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_14)->max_length)))))))
		{
			goto IL_0037;
		}
	}

IL_0054:
	{
		TypeU5BU5D_t1664964607* L_15 = __this->get__methodSignature_4();
		return (Il2CppObject *)L_15;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodCall::get_Properties()
extern "C"  Il2CppObject * MethodCall_get_Properties_m1893707917 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_ExternalProperties_8();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		VirtActionInvoker0::Invoke(16 /* System.Void System.Runtime.Remoting.Messaging.MethodCall::InitDictionary() */, __this);
	}

IL_0011:
	{
		Il2CppObject * L_1 = __this->get_ExternalProperties_8();
		return L_1;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::InitDictionary()
extern Il2CppClass* MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var;
extern const uint32_t MethodCall_InitDictionary_m4270429537_MetadataUsageId;
extern "C"  void MethodCall_InitDictionary_m4270429537 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_InitDictionary_m4270429537_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	MethodCallDictionary_t1516131009 * V_0 = NULL;
	{
		MethodCallDictionary_t1516131009 * L_0 = (MethodCallDictionary_t1516131009 *)il2cpp_codegen_object_new(MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var);
		MethodCallDictionary__ctor_m2731713924(L_0, __this, /*hidden argument*/NULL);
		V_0 = L_0;
		MethodCallDictionary_t1516131009 * L_1 = V_0;
		__this->set_ExternalProperties_8(L_1);
		MethodCallDictionary_t1516131009 * L_2 = V_0;
		Il2CppObject * L_3 = MethodDictionary_GetInternalProperties_m1562637947(L_2, /*hidden argument*/NULL);
		__this->set_InternalProperties_9(L_3);
		return;
	}
}
// System.String System.Runtime.Remoting.Messaging.MethodCall::get_TypeName()
extern "C"  String_t* MethodCall_get_TypeName_m2413432542 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__typeName_1();
		if (L_0)
		{
			goto IL_0021;
		}
	}
	{
		MethodBase_t904190842 * L_1 = __this->get__methodBase_5();
		Type_t * L_2 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_1);
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(15 /* System.String System.Type::get_AssemblyQualifiedName() */, L_2);
		__this->set__typeName_1(L_3);
	}

IL_0021:
	{
		String_t* L_4 = __this->get__typeName_1();
		return L_4;
	}
}
// System.String System.Runtime.Remoting.Messaging.MethodCall::get_Uri()
extern "C"  String_t* MethodCall_get_Uri_m1781226377 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__uri_0();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::set_Uri(System.String)
extern "C"  void MethodCall_set_Uri_m2512888818 (MethodCall_t2461541281 * __this, String_t* ___value0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set__uri_0(L_0);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::Init()
extern "C"  void MethodCall_Init_m3987198685 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCall::ResolveMethod()
extern Il2CppClass* RemotingServices_t2399536837_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingException_t109604560_il2cpp_TypeInfo_var;
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodInfo_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral455075110;
extern Il2CppCodeGenString* _stringLiteral372029317;
extern Il2CppCodeGenString* _stringLiteral2435341252;
extern Il2CppCodeGenString* _stringLiteral1786372059;
extern Il2CppCodeGenString* _stringLiteral2882540552;
extern Il2CppCodeGenString* _stringLiteral4180726204;
extern Il2CppCodeGenString* _stringLiteral372029307;
extern Il2CppCodeGenString* _stringLiteral2060850031;
extern Il2CppCodeGenString* _stringLiteral137777514;
extern Il2CppCodeGenString* _stringLiteral3555361447;
extern const uint32_t MethodCall_ResolveMethod_m3858310828_MetadataUsageId;
extern "C"  void MethodCall_ResolveMethod_m3858310828 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_ResolveMethod_m3858310828_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Type_t * V_0 = NULL;
	String_t* V_1 = NULL;
	Type_t * V_2 = NULL;
	String_t* G_B5_0 = NULL;
	{
		String_t* L_0 = __this->get__uri_0();
		if (!L_0)
		{
			goto IL_0171;
		}
	}
	{
		String_t* L_1 = __this->get__uri_0();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		Type_t * L_2 = RemotingServices_GetServerTypeForUri_m3261408713(NULL /*static, unused*/, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		Type_t * L_3 = V_0;
		if (L_3)
		{
			goto IL_0064;
		}
	}
	{
		String_t* L_4 = __this->get__typeName_1();
		if (!L_4)
		{
			goto IL_0042;
		}
	}
	{
		String_t* L_5 = __this->get__typeName_1();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_6 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral455075110, L_5, _stringLiteral372029317, /*hidden argument*/NULL);
		G_B5_0 = L_6;
		goto IL_0047;
	}

IL_0042:
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_7 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		G_B5_0 = L_7;
	}

IL_0047:
	{
		V_1 = G_B5_0;
		String_t* L_8 = V_1;
		String_t* L_9 = __this->get__uri_0();
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_10 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral2435341252, L_8, _stringLiteral1786372059, L_9, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_11 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_11, L_10, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_11);
	}

IL_0064:
	{
		String_t* L_12 = __this->get__typeName_1();
		Type_t * L_13 = V_0;
		Type_t * L_14 = MethodCall_CastTo_m2551807722(__this, L_12, L_13, /*hidden argument*/NULL);
		V_2 = L_14;
		Type_t * L_15 = V_2;
		if (L_15)
		{
			goto IL_00b3;
		}
	}
	{
		StringU5BU5D_t1642385972* L_16 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)5));
		ArrayElementTypeCheck (L_16, _stringLiteral2882540552);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral2882540552);
		StringU5BU5D_t1642385972* L_17 = L_16;
		String_t* L_18 = __this->get__typeName_1();
		ArrayElementTypeCheck (L_17, L_18);
		(L_17)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)L_18);
		StringU5BU5D_t1642385972* L_19 = L_17;
		ArrayElementTypeCheck (L_19, _stringLiteral4180726204);
		(L_19)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral4180726204);
		StringU5BU5D_t1642385972* L_20 = L_19;
		Type_t * L_21 = V_0;
		String_t* L_22 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_21);
		ArrayElementTypeCheck (L_20, L_22);
		(L_20)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)L_22);
		StringU5BU5D_t1642385972* L_23 = L_20;
		ArrayElementTypeCheck (L_23, _stringLiteral372029307);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral372029307);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_24 = String_Concat_m626692867(NULL /*static, unused*/, L_23, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_25 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_25, L_24, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_25);
	}

IL_00b3:
	{
		Type_t * L_26 = V_2;
		String_t* L_27 = __this->get__methodName_2();
		TypeU5BU5D_t1664964607* L_28 = __this->get__methodSignature_4();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		MethodBase_t904190842 * L_29 = RemotingServices_GetMethodBaseFromName_m3271095947(NULL /*static, unused*/, L_26, L_27, L_28, /*hidden argument*/NULL);
		__this->set__methodBase_5(L_29);
		MethodBase_t904190842 * L_30 = __this->get__methodBase_5();
		if (L_30)
		{
			goto IL_0104;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_31 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)4));
		ArrayElementTypeCheck (L_31, _stringLiteral2060850031);
		(L_31)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral2060850031);
		ObjectU5BU5D_t3614634134* L_32 = L_31;
		String_t* L_33 = __this->get__methodName_2();
		ArrayElementTypeCheck (L_32, L_33);
		(L_32)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_33);
		ObjectU5BU5D_t3614634134* L_34 = L_32;
		ArrayElementTypeCheck (L_34, _stringLiteral137777514);
		(L_34)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral137777514);
		ObjectU5BU5D_t3614634134* L_35 = L_34;
		Type_t * L_36 = V_2;
		ArrayElementTypeCheck (L_35, L_36);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_36);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_37 = String_Concat_m3881798623(NULL /*static, unused*/, L_35, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_38 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_38, L_37, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_38);
	}

IL_0104:
	{
		Type_t * L_39 = V_2;
		Type_t * L_40 = V_0;
		if ((((Il2CppObject*)(Type_t *)L_39) == ((Il2CppObject*)(Type_t *)L_40)))
		{
			goto IL_016c;
		}
	}
	{
		Type_t * L_41 = V_2;
		bool L_42 = Type_get_IsInterface_m3583817465(L_41, /*hidden argument*/NULL);
		if (!L_42)
		{
			goto IL_016c;
		}
	}
	{
		Type_t * L_43 = V_0;
		bool L_44 = Type_get_IsInterface_m3583817465(L_43, /*hidden argument*/NULL);
		if (L_44)
		{
			goto IL_016c;
		}
	}
	{
		Type_t * L_45 = V_0;
		MethodBase_t904190842 * L_46 = __this->get__methodBase_5();
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		MethodBase_t904190842 * L_47 = RemotingServices_GetVirtualMethod_m3767482873(NULL /*static, unused*/, L_45, L_46, /*hidden argument*/NULL);
		__this->set__methodBase_5(L_47);
		MethodBase_t904190842 * L_48 = __this->get__methodBase_5();
		if (L_48)
		{
			goto IL_016c;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_49 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)4));
		ArrayElementTypeCheck (L_49, _stringLiteral2060850031);
		(L_49)->SetAt(static_cast<il2cpp_array_size_t>(0), (Il2CppObject *)_stringLiteral2060850031);
		ObjectU5BU5D_t3614634134* L_50 = L_49;
		String_t* L_51 = __this->get__methodName_2();
		ArrayElementTypeCheck (L_50, L_51);
		(L_50)->SetAt(static_cast<il2cpp_array_size_t>(1), (Il2CppObject *)L_51);
		ObjectU5BU5D_t3614634134* L_52 = L_50;
		ArrayElementTypeCheck (L_52, _stringLiteral137777514);
		(L_52)->SetAt(static_cast<il2cpp_array_size_t>(2), (Il2CppObject *)_stringLiteral137777514);
		ObjectU5BU5D_t3614634134* L_53 = L_52;
		Type_t * L_54 = V_0;
		ArrayElementTypeCheck (L_53, L_54);
		(L_53)->SetAt(static_cast<il2cpp_array_size_t>(3), (Il2CppObject *)L_54);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_55 = String_Concat_m3881798623(NULL /*static, unused*/, L_53, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_56 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_56, L_55, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_56);
	}

IL_016c:
	{
		goto IL_01a9;
	}

IL_0171:
	{
		IL2CPP_RUNTIME_CLASS_INIT(RemotingServices_t2399536837_il2cpp_TypeInfo_var);
		MethodBase_t904190842 * L_57 = RemotingServices_GetMethodBaseFromMethodMessage_m716430067(NULL /*static, unused*/, __this, /*hidden argument*/NULL);
		__this->set__methodBase_5(L_57);
		MethodBase_t904190842 * L_58 = __this->get__methodBase_5();
		if (L_58)
		{
			goto IL_01a9;
		}
	}
	{
		String_t* L_59 = __this->get__methodName_2();
		String_t* L_60 = MethodCall_get_TypeName_m2413432542(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_61 = String_Concat_m1561703559(NULL /*static, unused*/, _stringLiteral2060850031, L_59, _stringLiteral137777514, L_60, /*hidden argument*/NULL);
		RemotingException_t109604560 * L_62 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_62, L_61, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_62);
	}

IL_01a9:
	{
		MethodBase_t904190842 * L_63 = __this->get__methodBase_5();
		bool L_64 = VirtFuncInvoker0< bool >::Invoke(29 /* System.Boolean System.Reflection.MethodBase::get_IsGenericMethod() */, L_63);
		if (!L_64)
		{
			goto IL_01fb;
		}
	}
	{
		MethodBase_t904190842 * L_65 = __this->get__methodBase_5();
		bool L_66 = VirtFuncInvoker0< bool >::Invoke(27 /* System.Boolean System.Reflection.MethodBase::get_ContainsGenericParameters() */, L_65);
		if (!L_66)
		{
			goto IL_01fb;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_67 = MethodCall_get_GenericArguments_m3765959301(__this, /*hidden argument*/NULL);
		if (L_67)
		{
			goto IL_01df;
		}
	}
	{
		RemotingException_t109604560 * L_68 = (RemotingException_t109604560 *)il2cpp_codegen_object_new(RemotingException_t109604560_il2cpp_TypeInfo_var);
		RemotingException__ctor_m3568495070(L_68, _stringLiteral3555361447, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_68);
	}

IL_01df:
	{
		MethodBase_t904190842 * L_69 = __this->get__methodBase_5();
		TypeU5BU5D_t1664964607* L_70 = MethodCall_get_GenericArguments_m3765959301(__this, /*hidden argument*/NULL);
		MethodInfo_t * L_71 = VirtFuncInvoker1< MethodInfo_t *, TypeU5BU5D_t1664964607* >::Invoke(32 /* System.Reflection.MethodInfo System.Reflection.MethodInfo::MakeGenericMethod(System.Type[]) */, ((MethodInfo_t *)CastclassClass(L_69, MethodInfo_t_il2cpp_TypeInfo_var)), L_70);
		__this->set__methodBase_5(L_71);
	}

IL_01fb:
	{
		return;
	}
}
// System.Type System.Runtime.Remoting.Messaging.MethodCall::CastTo(System.String,System.Type)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t MethodCall_CastTo_m2551807722_MetadataUsageId;
extern "C"  Type_t * MethodCall_CastTo_m2551807722 (MethodCall_t2461541281 * __this, String_t* ___clientType0, Type_t * ___serverType1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_CastTo_m2551807722_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Type_t * V_0 = NULL;
	TypeU5BU5D_t1664964607* V_1 = NULL;
	Type_t * V_2 = NULL;
	TypeU5BU5D_t1664964607* V_3 = NULL;
	int32_t V_4 = 0;
	{
		String_t* L_0 = ___clientType0;
		String_t* L_1 = MethodCall_GetTypeNameFromAssemblyQualifiedName_m3601734922(NULL /*static, unused*/, L_0, /*hidden argument*/NULL);
		___clientType0 = L_1;
		String_t* L_2 = ___clientType0;
		Type_t * L_3 = ___serverType1;
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_3);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_5 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_2, L_4, /*hidden argument*/NULL);
		if (!L_5)
		{
			goto IL_001b;
		}
	}
	{
		Type_t * L_6 = ___serverType1;
		return L_6;
	}

IL_001b:
	{
		Type_t * L_7 = ___serverType1;
		Type_t * L_8 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Type::get_BaseType() */, L_7);
		V_0 = L_8;
		goto IL_0041;
	}

IL_0027:
	{
		String_t* L_9 = ___clientType0;
		Type_t * L_10 = V_0;
		String_t* L_11 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_10);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_12 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_9, L_11, /*hidden argument*/NULL);
		if (!L_12)
		{
			goto IL_003a;
		}
	}
	{
		Type_t * L_13 = V_0;
		return L_13;
	}

IL_003a:
	{
		Type_t * L_14 = V_0;
		Type_t * L_15 = VirtFuncInvoker0< Type_t * >::Invoke(17 /* System.Type System.Type::get_BaseType() */, L_14);
		V_0 = L_15;
	}

IL_0041:
	{
		Type_t * L_16 = V_0;
		if (L_16)
		{
			goto IL_0027;
		}
	}
	{
		Type_t * L_17 = ___serverType1;
		TypeU5BU5D_t1664964607* L_18 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(39 /* System.Type[] System.Type::GetInterfaces() */, L_17);
		V_1 = L_18;
		TypeU5BU5D_t1664964607* L_19 = V_1;
		V_3 = L_19;
		V_4 = 0;
		goto IL_0076;
	}

IL_0058:
	{
		TypeU5BU5D_t1664964607* L_20 = V_3;
		int32_t L_21 = V_4;
		int32_t L_22 = L_21;
		Type_t * L_23 = (L_20)->GetAt(static_cast<il2cpp_array_size_t>(L_22));
		V_2 = L_23;
		String_t* L_24 = ___clientType0;
		Type_t * L_25 = V_2;
		String_t* L_26 = VirtFuncInvoker0< String_t* >::Invoke(18 /* System.String System.Type::get_FullName() */, L_25);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_27 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_24, L_26, /*hidden argument*/NULL);
		if (!L_27)
		{
			goto IL_0070;
		}
	}
	{
		Type_t * L_28 = V_2;
		return L_28;
	}

IL_0070:
	{
		int32_t L_29 = V_4;
		V_4 = ((int32_t)((int32_t)L_29+(int32_t)1));
	}

IL_0076:
	{
		int32_t L_30 = V_4;
		TypeU5BU5D_t1664964607* L_31 = V_3;
		if ((((int32_t)L_30) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_31)->max_length)))))))
		{
			goto IL_0058;
		}
	}
	{
		return (Type_t *)NULL;
	}
}
// System.String System.Runtime.Remoting.Messaging.MethodCall::GetTypeNameFromAssemblyQualifiedName(System.String)
extern Il2CppCodeGenString* _stringLiteral522332368;
extern const uint32_t MethodCall_GetTypeNameFromAssemblyQualifiedName_m3601734922_MetadataUsageId;
extern "C"  String_t* MethodCall_GetTypeNameFromAssemblyQualifiedName_m3601734922 (Il2CppObject * __this /* static, unused */, String_t* ___aqname0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCall_GetTypeNameFromAssemblyQualifiedName_m3601734922_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t G_B2_0 = 0;
	String_t* G_B2_1 = NULL;
	int32_t G_B1_0 = 0;
	String_t* G_B1_1 = NULL;
	int32_t G_B3_0 = 0;
	int32_t G_B3_1 = 0;
	String_t* G_B3_2 = NULL;
	{
		String_t* L_0 = ___aqname0;
		int32_t L_1 = String_IndexOf_m4251815737(L_0, _stringLiteral522332368, /*hidden argument*/NULL);
		V_0 = L_1;
		String_t* L_2 = ___aqname0;
		int32_t L_3 = V_0;
		G_B1_0 = ((int32_t)44);
		G_B1_1 = L_2;
		if ((!(((uint32_t)L_3) == ((uint32_t)(-1)))))
		{
			G_B2_0 = ((int32_t)44);
			G_B2_1 = L_2;
			goto IL_001c;
		}
	}
	{
		G_B3_0 = 0;
		G_B3_1 = G_B1_0;
		G_B3_2 = G_B1_1;
		goto IL_001f;
	}

IL_001c:
	{
		int32_t L_4 = V_0;
		G_B3_0 = ((int32_t)((int32_t)L_4+(int32_t)2));
		G_B3_1 = G_B2_0;
		G_B3_2 = G_B2_1;
	}

IL_001f:
	{
		int32_t L_5 = String_IndexOf_m3890362537(G_B3_2, G_B3_1, G_B3_0, /*hidden argument*/NULL);
		V_1 = L_5;
		int32_t L_6 = V_1;
		if ((((int32_t)L_6) == ((int32_t)(-1))))
		{
			goto IL_003b;
		}
	}
	{
		String_t* L_7 = ___aqname0;
		int32_t L_8 = V_1;
		String_t* L_9 = String_Substring_m12482732(L_7, 0, L_8, /*hidden argument*/NULL);
		String_t* L_10 = String_Trim_m2668767713(L_9, /*hidden argument*/NULL);
		___aqname0 = L_10;
	}

IL_003b:
	{
		String_t* L_11 = ___aqname0;
		return L_11;
	}
}
// System.Type[] System.Runtime.Remoting.Messaging.MethodCall::get_GenericArguments()
extern "C"  TypeU5BU5D_t1664964607* MethodCall_get_GenericArguments_m3765959301 (MethodCall_t2461541281 * __this, const MethodInfo* method)
{
	TypeU5BU5D_t1664964607* V_0 = NULL;
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get__genericArguments_7();
		if (!L_0)
		{
			goto IL_0012;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_1 = __this->get__genericArguments_7();
		return L_1;
	}

IL_0012:
	{
		MethodBase_t904190842 * L_2 = MethodCall_get_MethodBase_m688041003(__this, /*hidden argument*/NULL);
		TypeU5BU5D_t1664964607* L_3 = VirtFuncInvoker0< TypeU5BU5D_t1664964607* >::Invoke(26 /* System.Type[] System.Reflection.MethodBase::GetGenericArguments() */, L_2);
		TypeU5BU5D_t1664964607* L_4 = L_3;
		V_0 = L_4;
		__this->set__genericArguments_7(L_4);
		TypeU5BU5D_t1664964607* L_5 = V_0;
		return L_5;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCallDictionary::.ctor(System.Runtime.Remoting.Messaging.IMethodMessage)
extern Il2CppClass* MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var;
extern const uint32_t MethodCallDictionary__ctor_m2731713924_MetadataUsageId;
extern "C"  void MethodCallDictionary__ctor_m2731713924 (MethodCallDictionary_t1516131009 * __this, Il2CppObject * ___message0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCallDictionary__ctor_m2731713924_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___message0;
		MethodDictionary__ctor_m184006744(__this, L_0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_1 = ((MethodCallDictionary_t1516131009_StaticFields*)MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var->static_fields)->get_InternalKeys_6();
		MethodDictionary_set_MethodKeys_m3180307551(__this, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodCallDictionary::.cctor()
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern const uint32_t MethodCallDictionary__cctor_m1513361784_MetadataUsageId;
extern "C"  void MethodCallDictionary__cctor_m1513361784 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodCallDictionary__cctor_m1513361784_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		StringU5BU5D_t1642385972* L_0 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)6));
		ArrayElementTypeCheck (L_0, _stringLiteral977371278);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral977371278);
		StringU5BU5D_t1642385972* L_1 = L_0;
		ArrayElementTypeCheck (L_1, _stringLiteral3237227266);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3237227266);
		StringU5BU5D_t1642385972* L_2 = L_1;
		ArrayElementTypeCheck (L_2, _stringLiteral3556527655);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral3556527655);
		StringU5BU5D_t1642385972* L_3 = L_2;
		ArrayElementTypeCheck (L_3, _stringLiteral1596268323);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)_stringLiteral1596268323);
		StringU5BU5D_t1642385972* L_4 = L_3;
		ArrayElementTypeCheck (L_4, _stringLiteral1408113411);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral1408113411);
		StringU5BU5D_t1642385972* L_5 = L_4;
		ArrayElementTypeCheck (L_5, _stringLiteral1848363629);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(5), (String_t*)_stringLiteral1848363629);
		((MethodCallDictionary_t1516131009_StaticFields*)MethodCallDictionary_t1516131009_il2cpp_TypeInfo_var->static_fields)->set_InternalKeys_6(L_5);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::.ctor(System.Runtime.Remoting.Messaging.IMethodMessage)
extern "C"  void MethodDictionary__ctor_m184006744 (MethodDictionary_t1742974787 * __this, Il2CppObject * ___message0, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Il2CppObject * L_0 = ___message0;
		__this->set__message_1(L_0);
		return;
	}
}
// System.Collections.IEnumerator System.Runtime.Remoting.Messaging.MethodDictionary::System.Collections.IEnumerable.GetEnumerator()
extern Il2CppClass* DictionaryEnumerator_t492828146_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m1794586762_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m1794586762 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_System_Collections_IEnumerable_GetEnumerator_m1794586762_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		DictionaryEnumerator_t492828146 * L_0 = (DictionaryEnumerator_t492828146 *)il2cpp_codegen_object_new(DictionaryEnumerator_t492828146_il2cpp_TypeInfo_var);
		DictionaryEnumerator__ctor_m558641851(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::set_MethodKeys(System.String[])
extern "C"  void MethodDictionary_set_MethodKeys_m3180307551 (MethodDictionary_t1742974787 * __this, StringU5BU5D_t1642385972* ___value0, const MethodInfo* method)
{
	{
		StringU5BU5D_t1642385972* L_0 = ___value0;
		__this->set__methodKeys_2(L_0);
		return;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodDictionary::AllocInternalProperties()
extern Il2CppClass* Hashtable_t909839986_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_AllocInternalProperties_m3261295876_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_AllocInternalProperties_m3261295876 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_AllocInternalProperties_m3261295876_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		__this->set__ownProperties_3((bool)1);
		Hashtable_t909839986 * L_0 = (Hashtable_t909839986 *)il2cpp_codegen_object_new(Hashtable_t909839986_il2cpp_TypeInfo_var);
		Hashtable__ctor_m1884964176(L_0, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodDictionary::GetInternalProperties()
extern "C"  Il2CppObject * MethodDictionary_GetInternalProperties_m1562637947 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get__internalProperties_0();
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		Il2CppObject * L_1 = VirtFuncInvoker0< Il2CppObject * >::Invoke(14 /* System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodDictionary::AllocInternalProperties() */, __this);
		__this->set__internalProperties_0(L_1);
	}

IL_0017:
	{
		Il2CppObject * L_2 = __this->get__internalProperties_0();
		return L_2;
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.MethodDictionary::IsOverridenKey(System.String)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_IsOverridenKey_m3922224650_MetadataUsageId;
extern "C"  bool MethodDictionary_IsOverridenKey_m3922224650 (MethodDictionary_t1742974787 * __this, String_t* ___key0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_IsOverridenKey_m3922224650_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	StringU5BU5D_t1642385972* V_1 = NULL;
	int32_t V_2 = 0;
	{
		bool L_0 = __this->get__ownProperties_3();
		if (!L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (bool)0;
	}

IL_000d:
	{
		StringU5BU5D_t1642385972* L_1 = __this->get__methodKeys_2();
		V_1 = L_1;
		V_2 = 0;
		goto IL_0031;
	}

IL_001b:
	{
		StringU5BU5D_t1642385972* L_2 = V_1;
		int32_t L_3 = V_2;
		int32_t L_4 = L_3;
		String_t* L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_0 = L_5;
		String_t* L_6 = ___key0;
		String_t* L_7 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_8 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_6, L_7, /*hidden argument*/NULL);
		if (!L_8)
		{
			goto IL_002d;
		}
	}
	{
		return (bool)1;
	}

IL_002d:
	{
		int32_t L_9 = V_2;
		V_2 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_0031:
	{
		int32_t L_10 = V_2;
		StringU5BU5D_t1642385972* L_11 = V_1;
		if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
		{
			goto IL_001b;
		}
	}
	{
		return (bool)0;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary::get_Item(System.Object)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_get_Item_m3352300532_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_get_Item_m3352300532 (MethodDictionary_t1742974787 * __this, Il2CppObject * ___key0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_get_Item_m3352300532_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	{
		Il2CppObject * L_0 = ___key0;
		V_0 = ((String_t*)CastclassSealed(L_0, String_t_il2cpp_TypeInfo_var));
		V_1 = 0;
		goto IL_002d;
	}

IL_000e:
	{
		StringU5BU5D_t1642385972* L_1 = __this->get__methodKeys_2();
		int32_t L_2 = V_1;
		int32_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		String_t* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0029;
		}
	}
	{
		String_t* L_7 = V_0;
		Il2CppObject * L_8 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(15 /* System.Object System.Runtime.Remoting.Messaging.MethodDictionary::GetMethodProperty(System.String) */, __this, L_7);
		return L_8;
	}

IL_0029:
	{
		int32_t L_9 = V_1;
		V_1 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_002d:
	{
		int32_t L_10 = V_1;
		StringU5BU5D_t1642385972* L_11 = __this->get__methodKeys_2();
		if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
		{
			goto IL_000e;
		}
	}
	{
		Il2CppObject * L_12 = __this->get__internalProperties_0();
		if (!L_12)
		{
			goto IL_0053;
		}
	}
	{
		Il2CppObject * L_13 = __this->get__internalProperties_0();
		Il2CppObject * L_14 = ___key0;
		Il2CppObject * L_15 = InterfaceFuncInvoker1< Il2CppObject *, Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IDictionary::get_Item(System.Object) */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_13, L_14);
		return L_15;
	}

IL_0053:
	{
		return NULL;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::set_Item(System.Object,System.Object)
extern "C"  void MethodDictionary_set_Item_m3475146889 (MethodDictionary_t1742974787 * __this, Il2CppObject * ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = ___key0;
		Il2CppObject * L_1 = ___value1;
		MethodDictionary_Add_m1424332128(__this, L_0, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary::GetMethodProperty(System.String)
extern Il2CppClass* MethodDictionary_t1742974787_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* IMethodMessage_t1899389025_il2cpp_TypeInfo_var;
extern Il2CppClass* IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral1387442157;
extern Il2CppCodeGenString* _stringLiteral1592770018;
extern const uint32_t MethodDictionary_GetMethodProperty_m4085857742_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_GetMethodProperty_m4085857742 (MethodDictionary_t1742974787 * __this, String_t* ___key0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_GetMethodProperty_m4085857742_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_0126;
		}
	}
	{
		Dictionary_2_t3986656710 * L_2 = ((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map21_4();
		if (L_2)
		{
			goto IL_007f;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 8, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral977371278, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral3237227266, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral3556527655, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral1596268323, 3, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral1848363629, 4, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		Dictionary_2_Add_m1209957957(L_9, _stringLiteral1408113411, 5, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_10 = V_1;
		Dictionary_2_Add_m1209957957(L_10, _stringLiteral1387442157, 6, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_11 = V_1;
		Dictionary_2_Add_m1209957957(L_11, _stringLiteral1592770018, 7, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_12 = V_1;
		((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map21_4(L_12);
	}

IL_007f:
	{
		Dictionary_2_t3986656710 * L_13 = ((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map21_4();
		String_t* L_14 = V_0;
		bool L_15 = Dictionary_2_TryGetValue_m2977303364(L_13, L_14, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_15)
		{
			goto IL_0126;
		}
	}
	{
		int32_t L_16 = V_2;
		if (L_16 == 0)
		{
			goto IL_00bc;
		}
		if (L_16 == 1)
		{
			goto IL_00c8;
		}
		if (L_16 == 2)
		{
			goto IL_00d4;
		}
		if (L_16 == 3)
		{
			goto IL_00e0;
		}
		if (L_16 == 4)
		{
			goto IL_00ec;
		}
		if (L_16 == 5)
		{
			goto IL_00f8;
		}
		if (L_16 == 6)
		{
			goto IL_0104;
		}
		if (L_16 == 7)
		{
			goto IL_0115;
		}
	}
	{
		goto IL_0126;
	}

IL_00bc:
	{
		Il2CppObject * L_17 = __this->get__message_1();
		String_t* L_18 = InterfaceFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Runtime.Remoting.Messaging.IMethodMessage::get_Uri() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_17);
		return L_18;
	}

IL_00c8:
	{
		Il2CppObject * L_19 = __this->get__message_1();
		String_t* L_20 = InterfaceFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Runtime.Remoting.Messaging.IMethodMessage::get_MethodName() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_19);
		return L_20;
	}

IL_00d4:
	{
		Il2CppObject * L_21 = __this->get__message_1();
		String_t* L_22 = InterfaceFuncInvoker0< String_t* >::Invoke(5 /* System.String System.Runtime.Remoting.Messaging.IMethodMessage::get_TypeName() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_21);
		return L_22;
	}

IL_00e0:
	{
		Il2CppObject * L_23 = __this->get__message_1();
		Il2CppObject * L_24 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(4 /* System.Object System.Runtime.Remoting.Messaging.IMethodMessage::get_MethodSignature() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_23);
		return L_24;
	}

IL_00ec:
	{
		Il2CppObject * L_25 = __this->get__message_1();
		LogicalCallContext_t725724420 * L_26 = InterfaceFuncInvoker0< LogicalCallContext_t725724420 * >::Invoke(1 /* System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.IMethodMessage::get_LogicalCallContext() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_25);
		return L_26;
	}

IL_00f8:
	{
		Il2CppObject * L_27 = __this->get__message_1();
		ObjectU5BU5D_t3614634134* L_28 = InterfaceFuncInvoker0< ObjectU5BU5D_t3614634134* >::Invoke(0 /* System.Object[] System.Runtime.Remoting.Messaging.IMethodMessage::get_Args() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_27);
		return (Il2CppObject *)L_28;
	}

IL_0104:
	{
		Il2CppObject * L_29 = __this->get__message_1();
		ObjectU5BU5D_t3614634134* L_30 = InterfaceFuncInvoker0< ObjectU5BU5D_t3614634134* >::Invoke(1 /* System.Object[] System.Runtime.Remoting.Messaging.IMethodReturnMessage::get_OutArgs() */, IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_29, IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var)));
		return (Il2CppObject *)L_30;
	}

IL_0115:
	{
		Il2CppObject * L_31 = __this->get__message_1();
		Il2CppObject * L_32 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(2 /* System.Object System.Runtime.Remoting.Messaging.IMethodReturnMessage::get_ReturnValue() */, IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_31, IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var)));
		return L_32;
	}

IL_0126:
	{
		return NULL;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::SetMethodProperty(System.String,System.Object)
extern Il2CppClass* MethodDictionary_t1742974787_il2cpp_TypeInfo_var;
extern Il2CppClass* Dictionary_2_t3986656710_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* IInternalMessage_t1080632089_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const MethodInfo* Dictionary_2__ctor_m2118310873_MethodInfo_var;
extern const MethodInfo* Dictionary_2_Add_m1209957957_MethodInfo_var;
extern const MethodInfo* Dictionary_2_TryGetValue_m2977303364_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern Il2CppCodeGenString* _stringLiteral1387442157;
extern Il2CppCodeGenString* _stringLiteral1592770018;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1408113411;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral2244542343;
extern const uint32_t MethodDictionary_SetMethodProperty_m1502558295_MetadataUsageId;
extern "C"  void MethodDictionary_SetMethodProperty_m1502558295 (MethodDictionary_t1742974787 * __this, String_t* ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_SetMethodProperty_m1502558295_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	Dictionary_2_t3986656710 * V_1 = NULL;
	int32_t V_2 = 0;
	{
		String_t* L_0 = ___key0;
		V_0 = L_0;
		String_t* L_1 = V_0;
		if (!L_1)
		{
			goto IL_00cb;
		}
	}
	{
		Dictionary_2_t3986656710 * L_2 = ((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map22_5();
		if (L_2)
		{
			goto IL_007f;
		}
	}
	{
		Dictionary_2_t3986656710 * L_3 = (Dictionary_2_t3986656710 *)il2cpp_codegen_object_new(Dictionary_2_t3986656710_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m2118310873(L_3, 8, /*hidden argument*/Dictionary_2__ctor_m2118310873_MethodInfo_var);
		V_1 = L_3;
		Dictionary_2_t3986656710 * L_4 = V_1;
		Dictionary_2_Add_m1209957957(L_4, _stringLiteral1848363629, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_5 = V_1;
		Dictionary_2_Add_m1209957957(L_5, _stringLiteral1387442157, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_6 = V_1;
		Dictionary_2_Add_m1209957957(L_6, _stringLiteral1592770018, 0, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_7 = V_1;
		Dictionary_2_Add_m1209957957(L_7, _stringLiteral3237227266, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_8 = V_1;
		Dictionary_2_Add_m1209957957(L_8, _stringLiteral3556527655, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_9 = V_1;
		Dictionary_2_Add_m1209957957(L_9, _stringLiteral1596268323, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_10 = V_1;
		Dictionary_2_Add_m1209957957(L_10, _stringLiteral1408113411, 1, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_11 = V_1;
		Dictionary_2_Add_m1209957957(L_11, _stringLiteral977371278, 2, /*hidden argument*/Dictionary_2_Add_m1209957957_MethodInfo_var);
		Dictionary_2_t3986656710 * L_12 = V_1;
		((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->set_U3CU3Ef__switchU24map22_5(L_12);
	}

IL_007f:
	{
		Dictionary_2_t3986656710 * L_13 = ((MethodDictionary_t1742974787_StaticFields*)MethodDictionary_t1742974787_il2cpp_TypeInfo_var->static_fields)->get_U3CU3Ef__switchU24map22_5();
		String_t* L_14 = V_0;
		bool L_15 = Dictionary_2_TryGetValue_m2977303364(L_13, L_14, (&V_2), /*hidden argument*/Dictionary_2_TryGetValue_m2977303364_MethodInfo_var);
		if (!L_15)
		{
			goto IL_00cb;
		}
	}
	{
		int32_t L_16 = V_2;
		if (L_16 == 0)
		{
			goto IL_00a8;
		}
		if (L_16 == 1)
		{
			goto IL_00a9;
		}
		if (L_16 == 2)
		{
			goto IL_00b4;
		}
	}
	{
		goto IL_00cb;
	}

IL_00a8:
	{
		return;
	}

IL_00a9:
	{
		ArgumentException_t3259014390 * L_17 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_17, _stringLiteral2244542343, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_17);
	}

IL_00b4:
	{
		Il2CppObject * L_18 = __this->get__message_1();
		Il2CppObject * L_19 = ___value1;
		InterfaceActionInvoker1< String_t* >::Invoke(0 /* System.Void System.Runtime.Remoting.Messaging.IInternalMessage::set_Uri(System.String) */, IInternalMessage_t1080632089_il2cpp_TypeInfo_var, ((Il2CppObject *)Castclass(L_18, IInternalMessage_t1080632089_il2cpp_TypeInfo_var)), ((String_t*)CastclassSealed(L_19, String_t_il2cpp_TypeInfo_var)));
		return;
	}

IL_00cb:
	{
		return;
	}
}
// System.Collections.ICollection System.Runtime.Remoting.Messaging.MethodDictionary::get_Values()
extern Il2CppClass* ArrayList_t4252133567_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern Il2CppClass* DictionaryEntry_t3048875398_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDisposable_t2427283555_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_get_Values_m3868590366_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_get_Values_m3868590366 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_get_Values_m3868590366_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ArrayList_t4252133567 * V_0 = NULL;
	int32_t V_1 = 0;
	DictionaryEntry_t3048875398  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Il2CppObject * V_3 = NULL;
	Il2CppObject * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		ArrayList_t4252133567 * L_0 = (ArrayList_t4252133567 *)il2cpp_codegen_object_new(ArrayList_t4252133567_il2cpp_TypeInfo_var);
		ArrayList__ctor_m4012174379(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		V_1 = 0;
		goto IL_0026;
	}

IL_000d:
	{
		ArrayList_t4252133567 * L_1 = V_0;
		StringU5BU5D_t1642385972* L_2 = __this->get__methodKeys_2();
		int32_t L_3 = V_1;
		int32_t L_4 = L_3;
		String_t* L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		Il2CppObject * L_6 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(15 /* System.Object System.Runtime.Remoting.Messaging.MethodDictionary::GetMethodProperty(System.String) */, __this, L_5);
		VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_1, L_6);
		int32_t L_7 = V_1;
		V_1 = ((int32_t)((int32_t)L_7+(int32_t)1));
	}

IL_0026:
	{
		int32_t L_8 = V_1;
		StringU5BU5D_t1642385972* L_9 = __this->get__methodKeys_2();
		if ((((int32_t)L_8) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_9)->max_length)))))))
		{
			goto IL_000d;
		}
	}
	{
		Il2CppObject * L_10 = __this->get__internalProperties_0();
		if (!L_10)
		{
			goto IL_00a6;
		}
	}
	{
		Il2CppObject * L_11 = __this->get__internalProperties_0();
		Il2CppObject * L_12 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(3 /* System.Collections.IDictionaryEnumerator System.Collections.IDictionary::GetEnumerator() */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_11);
		V_3 = L_12;
	}

IL_004b:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0081;
		}

IL_0050:
		{
			Il2CppObject * L_13 = V_3;
			Il2CppObject * L_14 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.Collections.IEnumerator::get_Current() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_13);
			V_2 = ((*(DictionaryEntry_t3048875398 *)((DictionaryEntry_t3048875398 *)UnBox (L_14, DictionaryEntry_t3048875398_il2cpp_TypeInfo_var))));
			Il2CppObject * L_15 = DictionaryEntry_get_Key_m3623293571((&V_2), /*hidden argument*/NULL);
			bool L_16 = MethodDictionary_IsOverridenKey_m3922224650(__this, ((String_t*)CastclassSealed(L_15, String_t_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
			if (L_16)
			{
				goto IL_0081;
			}
		}

IL_0073:
		{
			ArrayList_t4252133567 * L_17 = V_0;
			Il2CppObject * L_18 = DictionaryEntry_get_Value_m2812883243((&V_2), /*hidden argument*/NULL);
			VirtFuncInvoker1< int32_t, Il2CppObject * >::Invoke(30 /* System.Int32 System.Collections.ArrayList::Add(System.Object) */, L_17, L_18);
		}

IL_0081:
		{
			Il2CppObject * L_19 = V_3;
			bool L_20 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_19);
			if (L_20)
			{
				goto IL_0050;
			}
		}

IL_008c:
		{
			IL2CPP_LEAVE(0xA6, FINALLY_0091);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t1927440687 *)e.ex;
		goto FINALLY_0091;
	}

FINALLY_0091:
	{ // begin finally (depth: 1)
		{
			Il2CppObject * L_21 = V_3;
			V_4 = ((Il2CppObject *)IsInst(L_21, IDisposable_t2427283555_il2cpp_TypeInfo_var));
			Il2CppObject * L_22 = V_4;
			if (L_22)
			{
				goto IL_009e;
			}
		}

IL_009d:
		{
			IL2CPP_END_FINALLY(145)
		}

IL_009e:
		{
			Il2CppObject * L_23 = V_4;
			InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t2427283555_il2cpp_TypeInfo_var, L_23);
			IL2CPP_END_FINALLY(145)
		}
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(145)
	{
		IL2CPP_JUMP_TBL(0xA6, IL_00a6)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t1927440687 *)
	}

IL_00a6:
	{
		ArrayList_t4252133567 * L_24 = V_0;
		return L_24;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::Add(System.Object,System.Object)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_Add_m1424332128_MetadataUsageId;
extern "C"  void MethodDictionary_Add_m1424332128 (MethodDictionary_t1742974787 * __this, Il2CppObject * ___key0, Il2CppObject * ___value1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_Add_m1424332128_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	{
		Il2CppObject * L_0 = ___key0;
		V_0 = ((String_t*)CastclassSealed(L_0, String_t_il2cpp_TypeInfo_var));
		V_1 = 0;
		goto IL_002e;
	}

IL_000e:
	{
		StringU5BU5D_t1642385972* L_1 = __this->get__methodKeys_2();
		int32_t L_2 = V_1;
		int32_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		String_t* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_002a;
		}
	}
	{
		String_t* L_7 = V_0;
		Il2CppObject * L_8 = ___value1;
		VirtActionInvoker2< String_t*, Il2CppObject * >::Invoke(16 /* System.Void System.Runtime.Remoting.Messaging.MethodDictionary::SetMethodProperty(System.String,System.Object) */, __this, L_7, L_8);
		return;
	}

IL_002a:
	{
		int32_t L_9 = V_1;
		V_1 = ((int32_t)((int32_t)L_9+(int32_t)1));
	}

IL_002e:
	{
		int32_t L_10 = V_1;
		StringU5BU5D_t1642385972* L_11 = __this->get__methodKeys_2();
		if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_11)->max_length)))))))
		{
			goto IL_000e;
		}
	}
	{
		Il2CppObject * L_12 = __this->get__internalProperties_0();
		if (L_12)
		{
			goto IL_0053;
		}
	}
	{
		Il2CppObject * L_13 = VirtFuncInvoker0< Il2CppObject * >::Invoke(14 /* System.Collections.IDictionary System.Runtime.Remoting.Messaging.MethodDictionary::AllocInternalProperties() */, __this);
		__this->set__internalProperties_0(L_13);
	}

IL_0053:
	{
		Il2CppObject * L_14 = __this->get__internalProperties_0();
		Il2CppObject * L_15 = ___key0;
		Il2CppObject * L_16 = ___value1;
		InterfaceActionInvoker2< Il2CppObject *, Il2CppObject * >::Invoke(1 /* System.Void System.Collections.IDictionary::set_Item(System.Object,System.Object) */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_14, L_15, L_16);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::Remove(System.Object)
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* ArgumentException_t3259014390_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2244542343;
extern const uint32_t MethodDictionary_Remove_m3965014965_MetadataUsageId;
extern "C"  void MethodDictionary_Remove_m3965014965 (MethodDictionary_t1742974787 * __this, Il2CppObject * ___key0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_Remove_m3965014965_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	{
		Il2CppObject * L_0 = ___key0;
		V_0 = ((String_t*)CastclassSealed(L_0, String_t_il2cpp_TypeInfo_var));
		V_1 = 0;
		goto IL_0030;
	}

IL_000e:
	{
		StringU5BU5D_t1642385972* L_1 = __this->get__methodKeys_2();
		int32_t L_2 = V_1;
		int32_t L_3 = L_2;
		String_t* L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		String_t* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		bool L_6 = String_op_Equality_m1790663636(NULL /*static, unused*/, L_4, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_002c;
		}
	}
	{
		ArgumentException_t3259014390 * L_7 = (ArgumentException_t3259014390 *)il2cpp_codegen_object_new(ArgumentException_t3259014390_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m3739475201(L_7, _stringLiteral2244542343, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7);
	}

IL_002c:
	{
		int32_t L_8 = V_1;
		V_1 = ((int32_t)((int32_t)L_8+(int32_t)1));
	}

IL_0030:
	{
		int32_t L_9 = V_1;
		StringU5BU5D_t1642385972* L_10 = __this->get__methodKeys_2();
		if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length)))))))
		{
			goto IL_000e;
		}
	}
	{
		Il2CppObject * L_11 = __this->get__internalProperties_0();
		if (!L_11)
		{
			goto IL_0055;
		}
	}
	{
		Il2CppObject * L_12 = __this->get__internalProperties_0();
		Il2CppObject * L_13 = ___key0;
		InterfaceActionInvoker1< Il2CppObject * >::Invoke(4 /* System.Void System.Collections.IDictionary::Remove(System.Object) */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_12, L_13);
	}

IL_0055:
	{
		return;
	}
}
// System.Int32 System.Runtime.Remoting.Messaging.MethodDictionary::get_Count()
extern Il2CppClass* ICollection_t91669223_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_get_Count_m3214848709_MetadataUsageId;
extern "C"  int32_t MethodDictionary_get_Count_m3214848709 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_get_Count_m3214848709_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = __this->get__internalProperties_0();
		if (!L_0)
		{
			goto IL_0020;
		}
	}
	{
		Il2CppObject * L_1 = __this->get__internalProperties_0();
		int32_t L_2 = InterfaceFuncInvoker0< int32_t >::Invoke(0 /* System.Int32 System.Collections.ICollection::get_Count() */, ICollection_t91669223_il2cpp_TypeInfo_var, L_1);
		StringU5BU5D_t1642385972* L_3 = __this->get__methodKeys_2();
		return ((int32_t)((int32_t)L_2+(int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length))))));
	}

IL_0020:
	{
		StringU5BU5D_t1642385972* L_4 = __this->get__methodKeys_2();
		return (((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length))));
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.MethodDictionary::get_IsSynchronized()
extern "C"  bool MethodDictionary_get_IsSynchronized_m800297790 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	{
		return (bool)0;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary::get_SyncRoot()
extern "C"  Il2CppObject * MethodDictionary_get_SyncRoot_m673971424 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	{
		return __this;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary::CopyTo(System.Array,System.Int32)
extern Il2CppClass* ICollection_t91669223_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_CopyTo_m1721788774_MetadataUsageId;
extern "C"  void MethodDictionary_CopyTo_m1721788774 (MethodDictionary_t1742974787 * __this, Il2CppArray * ___array0, int32_t ___index1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_CopyTo_m1721788774_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = MethodDictionary_get_Values_m3868590366(__this, /*hidden argument*/NULL);
		Il2CppArray * L_1 = ___array0;
		int32_t L_2 = ___index1;
		InterfaceActionInvoker2< Il2CppArray *, int32_t >::Invoke(3 /* System.Void System.Collections.ICollection::CopyTo(System.Array,System.Int32) */, ICollection_t91669223_il2cpp_TypeInfo_var, L_0, L_1, L_2);
		return;
	}
}
// System.Collections.IDictionaryEnumerator System.Runtime.Remoting.Messaging.MethodDictionary::GetEnumerator()
extern Il2CppClass* DictionaryEnumerator_t492828146_il2cpp_TypeInfo_var;
extern const uint32_t MethodDictionary_GetEnumerator_m2834961193_MetadataUsageId;
extern "C"  Il2CppObject * MethodDictionary_GetEnumerator_m2834961193 (MethodDictionary_t1742974787 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodDictionary_GetEnumerator_m2834961193_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		DictionaryEnumerator_t492828146 * L_0 = (DictionaryEnumerator_t492828146 *)il2cpp_codegen_object_new(DictionaryEnumerator_t492828146_il2cpp_TypeInfo_var);
		DictionaryEnumerator__ctor_m558641851(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::.ctor(System.Runtime.Remoting.Messaging.MethodDictionary)
extern Il2CppClass* IDictionary_t596158605_il2cpp_TypeInfo_var;
extern const uint32_t DictionaryEnumerator__ctor_m558641851_MetadataUsageId;
extern "C"  void DictionaryEnumerator__ctor_m558641851 (DictionaryEnumerator_t492828146 * __this, MethodDictionary_t1742974787 * ___methodDictionary0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DictionaryEnumerator__ctor_m558641851_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	Il2CppObject * V_0 = NULL;
	DictionaryEnumerator_t492828146 * G_B2_0 = NULL;
	DictionaryEnumerator_t492828146 * G_B1_0 = NULL;
	Il2CppObject * G_B3_0 = NULL;
	DictionaryEnumerator_t492828146 * G_B3_1 = NULL;
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		MethodDictionary_t1742974787 * L_0 = ___methodDictionary0;
		__this->set__methodDictionary_0(L_0);
		MethodDictionary_t1742974787 * L_1 = __this->get__methodDictionary_0();
		Il2CppObject * L_2 = L_1->get__internalProperties_0();
		G_B1_0 = __this;
		if (!L_2)
		{
			G_B2_0 = __this;
			goto IL_0035;
		}
	}
	{
		MethodDictionary_t1742974787 * L_3 = __this->get__methodDictionary_0();
		Il2CppObject * L_4 = L_3->get__internalProperties_0();
		Il2CppObject * L_5 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(3 /* System.Collections.IDictionaryEnumerator System.Collections.IDictionary::GetEnumerator() */, IDictionary_t596158605_il2cpp_TypeInfo_var, L_4);
		V_0 = L_5;
		Il2CppObject * L_6 = V_0;
		G_B3_0 = L_6;
		G_B3_1 = G_B1_0;
		goto IL_0036;
	}

IL_0035:
	{
		G_B3_0 = ((Il2CppObject *)(NULL));
		G_B3_1 = G_B2_0;
	}

IL_0036:
	{
		G_B3_1->set__hashtableEnum_1(G_B3_0);
		__this->set__posMethod_2((-1));
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::get_Current()
extern "C"  Il2CppObject * DictionaryEnumerator_get_Current_m2512101479 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		DictionaryEntry_t3048875398  L_0 = DictionaryEnumerator_get_Entry_m1597857786(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		Il2CppObject * L_1 = DictionaryEntry_get_Value_m2812883243((&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Boolean System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::MoveNext()
extern Il2CppClass* IDictionaryEnumerator_t259680273_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern const uint32_t DictionaryEnumerator_MoveNext_m866747030_MetadataUsageId;
extern "C"  bool DictionaryEnumerator_MoveNext_m866747030 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DictionaryEnumerator_MoveNext_m866747030_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		int32_t L_0 = __this->get__posMethod_2();
		if ((((int32_t)L_0) == ((int32_t)((int32_t)-2))))
		{
			goto IL_003d;
		}
	}
	{
		int32_t L_1 = __this->get__posMethod_2();
		__this->set__posMethod_2(((int32_t)((int32_t)L_1+(int32_t)1)));
		int32_t L_2 = __this->get__posMethod_2();
		MethodDictionary_t1742974787 * L_3 = __this->get__methodDictionary_0();
		StringU5BU5D_t1642385972* L_4 = L_3->get__methodKeys_2();
		if ((((int32_t)L_2) >= ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length)))))))
		{
			goto IL_0035;
		}
	}
	{
		return (bool)1;
	}

IL_0035:
	{
		__this->set__posMethod_2(((int32_t)-2));
	}

IL_003d:
	{
		Il2CppObject * L_5 = __this->get__hashtableEnum_1();
		if (L_5)
		{
			goto IL_004a;
		}
	}
	{
		return (bool)0;
	}

IL_004a:
	{
		goto IL_0071;
	}

IL_004f:
	{
		MethodDictionary_t1742974787 * L_6 = __this->get__methodDictionary_0();
		Il2CppObject * L_7 = __this->get__hashtableEnum_1();
		Il2CppObject * L_8 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(1 /* System.Object System.Collections.IDictionaryEnumerator::get_Key() */, IDictionaryEnumerator_t259680273_il2cpp_TypeInfo_var, L_7);
		bool L_9 = MethodDictionary_IsOverridenKey_m3922224650(L_6, ((String_t*)CastclassSealed(L_8, String_t_il2cpp_TypeInfo_var)), /*hidden argument*/NULL);
		if (L_9)
		{
			goto IL_0071;
		}
	}
	{
		return (bool)1;
	}

IL_0071:
	{
		Il2CppObject * L_10 = __this->get__hashtableEnum_1();
		bool L_11 = InterfaceFuncInvoker0< bool >::Invoke(1 /* System.Boolean System.Collections.IEnumerator::MoveNext() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_10);
		if (L_11)
		{
			goto IL_004f;
		}
	}
	{
		return (bool)0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::Reset()
extern Il2CppClass* IEnumerator_t1466026749_il2cpp_TypeInfo_var;
extern const uint32_t DictionaryEnumerator_Reset_m388016887_MetadataUsageId;
extern "C"  void DictionaryEnumerator_Reset_m388016887 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DictionaryEnumerator_Reset_m388016887_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		__this->set__posMethod_2((-1));
		Il2CppObject * L_0 = __this->get__hashtableEnum_1();
		InterfaceActionInvoker0::Invoke(2 /* System.Void System.Collections.IEnumerator::Reset() */, IEnumerator_t1466026749_il2cpp_TypeInfo_var, L_0);
		return;
	}
}
// System.Collections.DictionaryEntry System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::get_Entry()
extern Il2CppClass* InvalidOperationException_t721527559_il2cpp_TypeInfo_var;
extern Il2CppClass* IDictionaryEnumerator_t259680273_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral3264437177;
extern const uint32_t DictionaryEnumerator_get_Entry_m1597857786_MetadataUsageId;
extern "C"  DictionaryEntry_t3048875398  DictionaryEnumerator_get_Entry_m1597857786 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (DictionaryEnumerator_get_Entry_m1597857786_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		int32_t L_0 = __this->get__posMethod_2();
		if ((((int32_t)L_0) < ((int32_t)0)))
		{
			goto IL_0041;
		}
	}
	{
		MethodDictionary_t1742974787 * L_1 = __this->get__methodDictionary_0();
		StringU5BU5D_t1642385972* L_2 = L_1->get__methodKeys_2();
		int32_t L_3 = __this->get__posMethod_2();
		int32_t L_4 = L_3;
		String_t* L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		MethodDictionary_t1742974787 * L_6 = __this->get__methodDictionary_0();
		MethodDictionary_t1742974787 * L_7 = __this->get__methodDictionary_0();
		StringU5BU5D_t1642385972* L_8 = L_7->get__methodKeys_2();
		int32_t L_9 = __this->get__posMethod_2();
		int32_t L_10 = L_9;
		String_t* L_11 = (L_8)->GetAt(static_cast<il2cpp_array_size_t>(L_10));
		Il2CppObject * L_12 = VirtFuncInvoker1< Il2CppObject *, String_t* >::Invoke(15 /* System.Object System.Runtime.Remoting.Messaging.MethodDictionary::GetMethodProperty(System.String) */, L_6, L_11);
		DictionaryEntry_t3048875398  L_13;
		memset(&L_13, 0, sizeof(L_13));
		DictionaryEntry__ctor_m2901884110(&L_13, L_5, L_12, /*hidden argument*/NULL);
		return L_13;
	}

IL_0041:
	{
		int32_t L_14 = __this->get__posMethod_2();
		if ((((int32_t)L_14) == ((int32_t)(-1))))
		{
			goto IL_0058;
		}
	}
	{
		Il2CppObject * L_15 = __this->get__hashtableEnum_1();
		if (L_15)
		{
			goto IL_0063;
		}
	}

IL_0058:
	{
		InvalidOperationException_t721527559 * L_16 = (InvalidOperationException_t721527559 *)il2cpp_codegen_object_new(InvalidOperationException_t721527559_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m2801133788(L_16, _stringLiteral3264437177, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_16);
	}

IL_0063:
	{
		Il2CppObject * L_17 = __this->get__hashtableEnum_1();
		DictionaryEntry_t3048875398  L_18 = InterfaceFuncInvoker0< DictionaryEntry_t3048875398  >::Invoke(0 /* System.Collections.DictionaryEntry System.Collections.IDictionaryEnumerator::get_Entry() */, IDictionaryEnumerator_t259680273_il2cpp_TypeInfo_var, L_17);
		return L_18;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::get_Key()
extern "C"  Il2CppObject * DictionaryEnumerator_get_Key_m984277209 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		DictionaryEntry_t3048875398  L_0 = DictionaryEnumerator_get_Entry_m1597857786(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		Il2CppObject * L_1 = DictionaryEntry_get_Key_m3623293571((&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MethodDictionary/DictionaryEnumerator::get_Value()
extern "C"  Il2CppObject * DictionaryEnumerator_get_Value_m1915638953 (DictionaryEnumerator_t492828146 * __this, const MethodInfo* method)
{
	DictionaryEntry_t3048875398  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		DictionaryEntry_t3048875398  L_0 = DictionaryEnumerator_get_Entry_m1597857786(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		Il2CppObject * L_1 = DictionaryEntry_get_Value_m2812883243((&V_0), /*hidden argument*/NULL);
		return L_1;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodReturnDictionary::.ctor(System.Runtime.Remoting.Messaging.IMethodReturnMessage)
extern Il2CppClass* IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var;
extern const uint32_t MethodReturnDictionary__ctor_m756139344_MetadataUsageId;
extern "C"  void MethodReturnDictionary__ctor_m756139344 (MethodReturnDictionary_t981009581 * __this, Il2CppObject * ___message0, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodReturnDictionary__ctor_m756139344_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Il2CppObject * L_0 = ___message0;
		MethodDictionary__ctor_m184006744(__this, L_0, /*hidden argument*/NULL);
		Il2CppObject * L_1 = ___message0;
		Exception_t1927440687 * L_2 = InterfaceFuncInvoker0< Exception_t1927440687 * >::Invoke(0 /* System.Exception System.Runtime.Remoting.Messaging.IMethodReturnMessage::get_Exception() */, IMethodReturnMessage_t323645523_il2cpp_TypeInfo_var, L_1);
		if (L_2)
		{
			goto IL_0022;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_3 = ((MethodReturnDictionary_t981009581_StaticFields*)MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var->static_fields)->get_InternalReturnKeys_6();
		MethodDictionary_set_MethodKeys_m3180307551(__this, L_3, /*hidden argument*/NULL);
		goto IL_002d;
	}

IL_0022:
	{
		IL2CPP_RUNTIME_CLASS_INIT(MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var);
		StringU5BU5D_t1642385972* L_4 = ((MethodReturnDictionary_t981009581_StaticFields*)MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var->static_fields)->get_InternalExceptionKeys_7();
		MethodDictionary_set_MethodKeys_m3180307551(__this, L_4, /*hidden argument*/NULL);
	}

IL_002d:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MethodReturnDictionary::.cctor()
extern Il2CppClass* StringU5BU5D_t1642385972_il2cpp_TypeInfo_var;
extern Il2CppClass* MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral977371278;
extern Il2CppCodeGenString* _stringLiteral3237227266;
extern Il2CppCodeGenString* _stringLiteral3556527655;
extern Il2CppCodeGenString* _stringLiteral1596268323;
extern Il2CppCodeGenString* _stringLiteral1387442157;
extern Il2CppCodeGenString* _stringLiteral1592770018;
extern Il2CppCodeGenString* _stringLiteral1848363629;
extern const uint32_t MethodReturnDictionary__cctor_m1570567266_MetadataUsageId;
extern "C"  void MethodReturnDictionary__cctor_m1570567266 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MethodReturnDictionary__cctor_m1570567266_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		StringU5BU5D_t1642385972* L_0 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)7));
		ArrayElementTypeCheck (L_0, _stringLiteral977371278);
		(L_0)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral977371278);
		StringU5BU5D_t1642385972* L_1 = L_0;
		ArrayElementTypeCheck (L_1, _stringLiteral3237227266);
		(L_1)->SetAt(static_cast<il2cpp_array_size_t>(1), (String_t*)_stringLiteral3237227266);
		StringU5BU5D_t1642385972* L_2 = L_1;
		ArrayElementTypeCheck (L_2, _stringLiteral3556527655);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(2), (String_t*)_stringLiteral3556527655);
		StringU5BU5D_t1642385972* L_3 = L_2;
		ArrayElementTypeCheck (L_3, _stringLiteral1596268323);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(3), (String_t*)_stringLiteral1596268323);
		StringU5BU5D_t1642385972* L_4 = L_3;
		ArrayElementTypeCheck (L_4, _stringLiteral1387442157);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(4), (String_t*)_stringLiteral1387442157);
		StringU5BU5D_t1642385972* L_5 = L_4;
		ArrayElementTypeCheck (L_5, _stringLiteral1592770018);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(5), (String_t*)_stringLiteral1592770018);
		StringU5BU5D_t1642385972* L_6 = L_5;
		ArrayElementTypeCheck (L_6, _stringLiteral1848363629);
		(L_6)->SetAt(static_cast<il2cpp_array_size_t>(6), (String_t*)_stringLiteral1848363629);
		((MethodReturnDictionary_t981009581_StaticFields*)MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var->static_fields)->set_InternalReturnKeys_6(L_6);
		StringU5BU5D_t1642385972* L_7 = ((StringU5BU5D_t1642385972*)SZArrayNew(StringU5BU5D_t1642385972_il2cpp_TypeInfo_var, (uint32_t)1));
		ArrayElementTypeCheck (L_7, _stringLiteral1848363629);
		(L_7)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)_stringLiteral1848363629);
		((MethodReturnDictionary_t981009581_StaticFields*)MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var->static_fields)->set_InternalExceptionKeys_7(L_7);
		return;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.MonoMethodMessage::get_Args()
extern "C"  ObjectU5BU5D_t3614634134* MonoMethodMessage_get_Args_m1959227626 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get_args_1();
		return L_0;
	}
}
// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.MonoMethodMessage::get_LogicalCallContext()
extern "C"  LogicalCallContext_t725724420 * MonoMethodMessage_get_LogicalCallContext_m2551132077 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		LogicalCallContext_t725724420 * L_0 = __this->get_ctx_3();
		return L_0;
	}
}
// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.MonoMethodMessage::get_MethodBase()
extern "C"  MethodBase_t904190842 * MonoMethodMessage_get_MethodBase_m218894245 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		MonoMethod_t * L_0 = __this->get_method_0();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.Messaging.MonoMethodMessage::get_MethodName()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethodMessage_get_MethodName_m3580519713_MetadataUsageId;
extern "C"  String_t* MonoMethodMessage_get_MethodName_m3580519713 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MonoMethodMessage_get_MethodName_m3580519713_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		MonoMethod_t * L_0 = __this->get_method_0();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_1 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		return L_1;
	}

IL_0011:
	{
		MonoMethod_t * L_2 = __this->get_method_0();
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MonoMethod::get_Name() */, L_2);
		return L_3;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MonoMethodMessage::get_MethodSignature()
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethodMessage_get_MethodSignature_m1059683822_MetadataUsageId;
extern "C"  Il2CppObject * MonoMethodMessage_get_MethodSignature_m1059683822 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MonoMethodMessage_get_MethodSignature_m1059683822_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	{
		TypeU5BU5D_t1664964607* L_0 = __this->get_methodSignature_7();
		if (L_0)
		{
			goto IL_0049;
		}
	}
	{
		MonoMethod_t * L_1 = __this->get_method_0();
		ParameterInfoU5BU5D_t2275869610* L_2 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MonoMethod::GetParameters() */, L_1);
		V_0 = L_2;
		ParameterInfoU5BU5D_t2275869610* L_3 = V_0;
		__this->set_methodSignature_7(((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_3)->max_length)))))));
		V_1 = 0;
		goto IL_0040;
	}

IL_002c:
	{
		TypeU5BU5D_t1664964607* L_4 = __this->get_methodSignature_7();
		int32_t L_5 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_6 = V_0;
		int32_t L_7 = V_1;
		int32_t L_8 = L_7;
		ParameterInfo_t2249040075 * L_9 = (L_6)->GetAt(static_cast<il2cpp_array_size_t>(L_8));
		Type_t * L_10 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_9);
		ArrayElementTypeCheck (L_4, L_10);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(L_5), (Type_t *)L_10);
		int32_t L_11 = V_1;
		V_1 = ((int32_t)((int32_t)L_11+(int32_t)1));
	}

IL_0040:
	{
		int32_t L_12 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_13 = V_0;
		if ((((int32_t)L_12) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_13)->max_length)))))))
		{
			goto IL_002c;
		}
	}

IL_0049:
	{
		TypeU5BU5D_t1664964607* L_14 = __this->get_methodSignature_7();
		return (Il2CppObject *)L_14;
	}
}
// System.String System.Runtime.Remoting.Messaging.MonoMethodMessage::get_TypeName()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethodMessage_get_TypeName_m2991947474_MetadataUsageId;
extern "C"  String_t* MonoMethodMessage_get_TypeName_m2991947474 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MonoMethodMessage_get_TypeName_m2991947474_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		MonoMethod_t * L_0 = __this->get_method_0();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_1 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		return L_1;
	}

IL_0011:
	{
		MonoMethod_t * L_2 = __this->get_method_0();
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MonoMethod::get_DeclaringType() */, L_2);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(15 /* System.String System.Type::get_AssemblyQualifiedName() */, L_3);
		return L_4;
	}
}
// System.String System.Runtime.Remoting.Messaging.MonoMethodMessage::get_Uri()
extern "C"  String_t* MonoMethodMessage_get_Uri_m846021167 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get_uri_6();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.MonoMethodMessage::set_Uri(System.String)
extern "C"  void MonoMethodMessage_set_Uri_m3218581120 (MonoMethodMessage_t771543475 * __this, String_t* ___value0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_uri_6(L_0);
		return;
	}
}
// System.Exception System.Runtime.Remoting.Messaging.MonoMethodMessage::get_Exception()
extern "C"  Exception_t1927440687 * MonoMethodMessage_get_Exception_m112694486 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = __this->get_exc_5();
		return L_0;
	}
}
// System.Int32 System.Runtime.Remoting.Messaging.MonoMethodMessage::get_OutArgCount()
extern "C"  int32_t MonoMethodMessage_get_OutArgCount_m1571045627 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	int32_t V_0 = 0;
	uint8_t V_1 = 0x0;
	ByteU5BU5D_t3397334013* V_2 = NULL;
	int32_t V_3 = 0;
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get_args_1();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return 0;
	}

IL_000d:
	{
		V_0 = 0;
		ByteU5BU5D_t3397334013* L_1 = __this->get_arg_types_2();
		V_2 = L_1;
		V_3 = 0;
		goto IL_0031;
	}

IL_001d:
	{
		ByteU5BU5D_t3397334013* L_2 = V_2;
		int32_t L_3 = V_3;
		int32_t L_4 = L_3;
		uint8_t L_5 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_1 = L_5;
		uint8_t L_6 = V_1;
		if (!((int32_t)((int32_t)L_6&(int32_t)2)))
		{
			goto IL_002d;
		}
	}
	{
		int32_t L_7 = V_0;
		V_0 = ((int32_t)((int32_t)L_7+(int32_t)1));
	}

IL_002d:
	{
		int32_t L_8 = V_3;
		V_3 = ((int32_t)((int32_t)L_8+(int32_t)1));
	}

IL_0031:
	{
		int32_t L_9 = V_3;
		ByteU5BU5D_t3397334013* L_10 = V_2;
		if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_10)->max_length)))))))
		{
			goto IL_001d;
		}
	}
	{
		int32_t L_11 = V_0;
		return L_11;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.MonoMethodMessage::get_OutArgs()
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t MonoMethodMessage_get_OutArgs_m1006158834_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* MonoMethodMessage_get_OutArgs_m1006158834 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (MonoMethodMessage_get_OutArgs_m1006158834_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	int32_t V_2 = 0;
	ObjectU5BU5D_t3614634134* V_3 = NULL;
	uint8_t V_4 = 0x0;
	ByteU5BU5D_t3397334013* V_5 = NULL;
	int32_t V_6 = 0;
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get_args_1();
		if (L_0)
		{
			goto IL_000d;
		}
	}
	{
		return (ObjectU5BU5D_t3614634134*)NULL;
	}

IL_000d:
	{
		int32_t L_1 = MonoMethodMessage_get_OutArgCount_m1571045627(__this, /*hidden argument*/NULL);
		V_2 = L_1;
		int32_t L_2 = V_2;
		V_3 = ((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_2));
		int32_t L_3 = 0;
		V_1 = L_3;
		V_0 = L_3;
		ByteU5BU5D_t3397334013* L_4 = __this->get_arg_types_2();
		V_5 = L_4;
		V_6 = 0;
		goto IL_0058;
	}

IL_002f:
	{
		ByteU5BU5D_t3397334013* L_5 = V_5;
		int32_t L_6 = V_6;
		int32_t L_7 = L_6;
		uint8_t L_8 = (L_5)->GetAt(static_cast<il2cpp_array_size_t>(L_7));
		V_4 = L_8;
		uint8_t L_9 = V_4;
		if (!((int32_t)((int32_t)L_9&(int32_t)2)))
		{
			goto IL_004e;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_10 = V_3;
		int32_t L_11 = V_1;
		int32_t L_12 = L_11;
		V_1 = ((int32_t)((int32_t)L_12+(int32_t)1));
		ObjectU5BU5D_t3614634134* L_13 = __this->get_args_1();
		int32_t L_14 = V_0;
		int32_t L_15 = L_14;
		Il2CppObject * L_16 = (L_13)->GetAt(static_cast<il2cpp_array_size_t>(L_15));
		ArrayElementTypeCheck (L_10, L_16);
		(L_10)->SetAt(static_cast<il2cpp_array_size_t>(L_12), (Il2CppObject *)L_16);
	}

IL_004e:
	{
		int32_t L_17 = V_0;
		V_0 = ((int32_t)((int32_t)L_17+(int32_t)1));
		int32_t L_18 = V_6;
		V_6 = ((int32_t)((int32_t)L_18+(int32_t)1));
	}

IL_0058:
	{
		int32_t L_19 = V_6;
		ByteU5BU5D_t3397334013* L_20 = V_5;
		if ((((int32_t)L_19) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_20)->max_length)))))))
		{
			goto IL_002f;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_21 = V_3;
		return L_21;
	}
}
// System.Object System.Runtime.Remoting.Messaging.MonoMethodMessage::get_ReturnValue()
extern "C"  Il2CppObject * MonoMethodMessage_get_ReturnValue_m3408856672 (MonoMethodMessage_t771543475 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get_rval_4();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ObjRefSurrogate::.ctor()
extern "C"  void ObjRefSurrogate__ctor_m3732637940 (ObjRefSurrogate_t3912784830 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.ObjRefSurrogate::SetObjectData(System.Object,System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext,System.Runtime.Serialization.ISurrogateSelector)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1313090288;
extern const uint32_t ObjRefSurrogate_SetObjectData_m1873902916_MetadataUsageId;
extern "C"  Il2CppObject * ObjRefSurrogate_SetObjectData_m1873902916 (ObjRefSurrogate_t3912784830 * __this, Il2CppObject * ___obj0, SerializationInfo_t228987430 * ___si1, StreamingContext_t1417235061  ___sc2, Il2CppObject * ___selector3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ObjRefSurrogate_SetObjectData_m1873902916_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m836173213(L_0, _stringLiteral1313090288, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void System.Runtime.Remoting.Messaging.RemotingSurrogate::.ctor()
extern "C"  void RemotingSurrogate__ctor_m4143261101 (RemotingSurrogate_t3248446683 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Object System.Runtime.Remoting.Messaging.RemotingSurrogate::SetObjectData(System.Object,System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext,System.Runtime.Serialization.ISurrogateSelector)
extern Il2CppClass* NotSupportedException_t1793819818_il2cpp_TypeInfo_var;
extern const uint32_t RemotingSurrogate_SetObjectData_m2594388993_MetadataUsageId;
extern "C"  Il2CppObject * RemotingSurrogate_SetObjectData_m2594388993 (RemotingSurrogate_t3248446683 * __this, Il2CppObject * ___obj0, SerializationInfo_t228987430 * ___si1, StreamingContext_t1417235061  ___sc2, Il2CppObject * ___selector3, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (RemotingSurrogate_SetObjectData_m2594388993_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		NotSupportedException_t1793819818 * L_0 = (NotSupportedException_t1793819818 *)il2cpp_codegen_object_new(NotSupportedException_t1793819818_il2cpp_TypeInfo_var);
		NotSupportedException__ctor_m3232764727(L_0, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_0);
	}
}
// System.Void System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::.ctor()
extern "C"  void RemotingSurrogateSelector__ctor_m88962884 (RemotingSurrogateSelector_t2821375126 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::.cctor()
extern const Il2CppType* ObjRef_t318414488_0_0_0_var;
extern Il2CppClass* Type_t_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjRefSurrogate_t3912784830_il2cpp_TypeInfo_var;
extern Il2CppClass* RemotingSurrogate_t3248446683_il2cpp_TypeInfo_var;
extern const uint32_t RemotingSurrogateSelector__cctor_m1175279223_MetadataUsageId;
extern "C"  void RemotingSurrogateSelector__cctor_m1175279223 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (RemotingSurrogateSelector__cctor_m1175279223_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(Type_t_il2cpp_TypeInfo_var);
		Type_t * L_0 = Type_GetTypeFromHandle_m432505302(NULL /*static, unused*/, LoadTypeToken(ObjRef_t318414488_0_0_0_var), /*hidden argument*/NULL);
		((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->set_s_cachedTypeObjRef_0(L_0);
		ObjRefSurrogate_t3912784830 * L_1 = (ObjRefSurrogate_t3912784830 *)il2cpp_codegen_object_new(ObjRefSurrogate_t3912784830_il2cpp_TypeInfo_var);
		ObjRefSurrogate__ctor_m3732637940(L_1, /*hidden argument*/NULL);
		((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->set__objRefSurrogate_1(L_1);
		RemotingSurrogate_t3248446683 * L_2 = (RemotingSurrogate_t3248446683 *)il2cpp_codegen_object_new(RemotingSurrogate_t3248446683_il2cpp_TypeInfo_var);
		RemotingSurrogate__ctor_m4143261101(L_2, /*hidden argument*/NULL);
		((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->set__objRemotingSurrogate_2(L_2);
		return;
	}
}
// System.Runtime.Serialization.ISerializationSurrogate System.Runtime.Remoting.Messaging.RemotingSurrogateSelector::GetSurrogate(System.Type,System.Runtime.Serialization.StreamingContext,System.Runtime.Serialization.ISurrogateSelector&)
extern Il2CppClass* RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var;
extern Il2CppClass* ISurrogateSelector_t1912587528_il2cpp_TypeInfo_var;
extern const uint32_t RemotingSurrogateSelector_GetSurrogate_m3879132231_MetadataUsageId;
extern "C"  Il2CppObject * RemotingSurrogateSelector_GetSurrogate_m3879132231 (RemotingSurrogateSelector_t2821375126 * __this, Type_t * ___type0, StreamingContext_t1417235061  ___context1, Il2CppObject ** ___ssout2, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (RemotingSurrogateSelector_GetSurrogate_m3879132231_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Type_t * L_0 = ___type0;
		bool L_1 = Type_get_IsMarshalByRef_m863073076(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_0014;
		}
	}
	{
		Il2CppObject ** L_2 = ___ssout2;
		*((Il2CppObject **)(L_2)) = (Il2CppObject *)__this;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_2), (Il2CppObject *)__this);
		IL2CPP_RUNTIME_CLASS_INIT(RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var);
		RemotingSurrogate_t3248446683 * L_3 = ((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->get__objRemotingSurrogate_2();
		return L_3;
	}

IL_0014:
	{
		IL2CPP_RUNTIME_CLASS_INIT(RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var);
		Type_t * L_4 = ((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->get_s_cachedTypeObjRef_0();
		Type_t * L_5 = ___type0;
		bool L_6 = VirtFuncInvoker1< bool, Type_t * >::Invoke(40 /* System.Boolean System.Type::IsAssignableFrom(System.Type) */, L_4, L_5);
		if (!L_6)
		{
			goto IL_002d;
		}
	}
	{
		Il2CppObject ** L_7 = ___ssout2;
		*((Il2CppObject **)(L_7)) = (Il2CppObject *)__this;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_7), (Il2CppObject *)__this);
		IL2CPP_RUNTIME_CLASS_INIT(RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var);
		ObjRefSurrogate_t3912784830 * L_8 = ((RemotingSurrogateSelector_t2821375126_StaticFields*)RemotingSurrogateSelector_t2821375126_il2cpp_TypeInfo_var->static_fields)->get__objRefSurrogate_1();
		return L_8;
	}

IL_002d:
	{
		Il2CppObject * L_9 = __this->get__next_3();
		if (!L_9)
		{
			goto IL_0047;
		}
	}
	{
		Il2CppObject * L_10 = __this->get__next_3();
		Type_t * L_11 = ___type0;
		StreamingContext_t1417235061  L_12 = ___context1;
		Il2CppObject ** L_13 = ___ssout2;
		Il2CppObject * L_14 = InterfaceFuncInvoker3< Il2CppObject *, Type_t *, StreamingContext_t1417235061 , Il2CppObject ** >::Invoke(0 /* System.Runtime.Serialization.ISerializationSurrogate System.Runtime.Serialization.ISurrogateSelector::GetSurrogate(System.Type,System.Runtime.Serialization.StreamingContext,System.Runtime.Serialization.ISurrogateSelector&) */, ISurrogateSelector_t1912587528_il2cpp_TypeInfo_var, L_10, L_11, L_12, L_13);
		return L_14;
	}

IL_0047:
	{
		Il2CppObject ** L_15 = ___ssout2;
		*((Il2CppObject **)(L_15)) = (Il2CppObject *)NULL;
		Il2CppCodeGenWriteBarrier((Il2CppObject **)(L_15), (Il2CppObject *)NULL);
		return (Il2CppObject *)NULL;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ReturnMessage::.ctor(System.Object,System.Object[],System.Int32,System.Runtime.Remoting.Messaging.LogicalCallContext,System.Runtime.Remoting.Messaging.IMethodCallMessage)
extern Il2CppClass* IMethodMessage_t1899389025_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage__ctor_m4106714265_MetadataUsageId;
extern "C"  void ReturnMessage__ctor_m4106714265 (ReturnMessage_t3411975905 * __this, Il2CppObject * ___ret0, ObjectU5BU5D_t3614634134* ___outArgs1, int32_t ___outArgsCount2, LogicalCallContext_t725724420 * ___callCtx3, Il2CppObject * ___mcm4, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage__ctor_m4106714265_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Il2CppObject * L_0 = ___ret0;
		__this->set__returnValue_4(L_0);
		ObjectU5BU5D_t3614634134* L_1 = ___outArgs1;
		__this->set__args_1(L_1);
		int32_t L_2 = ___outArgsCount2;
		__this->set__outArgsCount_2(L_2);
		LogicalCallContext_t725724420 * L_3 = ___callCtx3;
		__this->set__callCtx_3(L_3);
		Il2CppObject * L_4 = ___mcm4;
		if (!L_4)
		{
			goto IL_0044;
		}
	}
	{
		Il2CppObject * L_5 = ___mcm4;
		String_t* L_6 = InterfaceFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Runtime.Remoting.Messaging.IMethodMessage::get_Uri() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_5);
		__this->set__uri_5(L_6);
		Il2CppObject * L_7 = ___mcm4;
		MethodBase_t904190842 * L_8 = InterfaceFuncInvoker0< MethodBase_t904190842 * >::Invoke(2 /* System.Reflection.MethodBase System.Runtime.Remoting.Messaging.IMethodMessage::get_MethodBase() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_7);
		__this->set__methodBase_7(L_8);
	}

IL_0044:
	{
		ObjectU5BU5D_t3614634134* L_9 = __this->get__args_1();
		if (L_9)
		{
			goto IL_005b;
		}
	}
	{
		int32_t L_10 = ___outArgsCount2;
		__this->set__args_1(((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)L_10)));
	}

IL_005b:
	{
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ReturnMessage::.ctor(System.Exception,System.Runtime.Remoting.Messaging.IMethodCallMessage)
extern Il2CppClass* IMethodMessage_t1899389025_il2cpp_TypeInfo_var;
extern Il2CppClass* ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage__ctor_m3419006532_MetadataUsageId;
extern "C"  void ReturnMessage__ctor_m3419006532 (ReturnMessage_t3411975905 * __this, Exception_t1927440687 * ___e0, Il2CppObject * ___mcm1, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage__ctor_m3419006532_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		Exception_t1927440687 * L_0 = ___e0;
		__this->set__exception_6(L_0);
		Il2CppObject * L_1 = ___mcm1;
		if (!L_1)
		{
			goto IL_002b;
		}
	}
	{
		Il2CppObject * L_2 = ___mcm1;
		MethodBase_t904190842 * L_3 = InterfaceFuncInvoker0< MethodBase_t904190842 * >::Invoke(2 /* System.Reflection.MethodBase System.Runtime.Remoting.Messaging.IMethodMessage::get_MethodBase() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_2);
		__this->set__methodBase_7(L_3);
		Il2CppObject * L_4 = ___mcm1;
		LogicalCallContext_t725724420 * L_5 = InterfaceFuncInvoker0< LogicalCallContext_t725724420 * >::Invoke(1 /* System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.IMethodMessage::get_LogicalCallContext() */, IMethodMessage_t1899389025_il2cpp_TypeInfo_var, L_4);
		__this->set__callCtx_3(L_5);
	}

IL_002b:
	{
		__this->set__args_1(((ObjectU5BU5D_t3614634134*)SZArrayNew(ObjectU5BU5D_t3614634134_il2cpp_TypeInfo_var, (uint32_t)0)));
		return;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ReturnMessage::System.Runtime.Remoting.Messaging.IInternalMessage.set_Uri(System.String)
extern "C"  void ReturnMessage_System_Runtime_Remoting_Messaging_IInternalMessage_set_Uri_m2928464087 (ReturnMessage_t3411975905 * __this, String_t* ___value0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___value0;
		ReturnMessage_set_Uri_m961888476(__this, L_0, /*hidden argument*/NULL);
		return;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.ReturnMessage::get_Args()
extern "C"  ObjectU5BU5D_t3614634134* ReturnMessage_get_Args_m658290258 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get__args_1();
		return L_0;
	}
}
// System.Runtime.Remoting.Messaging.LogicalCallContext System.Runtime.Remoting.Messaging.ReturnMessage::get_LogicalCallContext()
extern Il2CppClass* LogicalCallContext_t725724420_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage_get_LogicalCallContext_m2158420703_MetadataUsageId;
extern "C"  LogicalCallContext_t725724420 * ReturnMessage_get_LogicalCallContext_m2158420703 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage_get_LogicalCallContext_m2158420703_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		LogicalCallContext_t725724420 * L_0 = __this->get__callCtx_3();
		if (L_0)
		{
			goto IL_0016;
		}
	}
	{
		LogicalCallContext_t725724420 * L_1 = (LogicalCallContext_t725724420 *)il2cpp_codegen_object_new(LogicalCallContext_t725724420_il2cpp_TypeInfo_var);
		LogicalCallContext__ctor_m252561004(L_1, /*hidden argument*/NULL);
		__this->set__callCtx_3(L_1);
	}

IL_0016:
	{
		LogicalCallContext_t725724420 * L_2 = __this->get__callCtx_3();
		return L_2;
	}
}
// System.Reflection.MethodBase System.Runtime.Remoting.Messaging.ReturnMessage::get_MethodBase()
extern "C"  MethodBase_t904190842 * ReturnMessage_get_MethodBase_m1666108195 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		MethodBase_t904190842 * L_0 = __this->get__methodBase_7();
		return L_0;
	}
}
// System.String System.Runtime.Remoting.Messaging.ReturnMessage::get_MethodName()
extern "C"  String_t* ReturnMessage_get_MethodName_m2437275403 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		MethodBase_t904190842 * L_0 = __this->get__methodBase_7();
		if (!L_0)
		{
			goto IL_0027;
		}
	}
	{
		String_t* L_1 = __this->get__methodName_8();
		if (L_1)
		{
			goto IL_0027;
		}
	}
	{
		MethodBase_t904190842 * L_2 = __this->get__methodBase_7();
		String_t* L_3 = VirtFuncInvoker0< String_t* >::Invoke(8 /* System.String System.Reflection.MemberInfo::get_Name() */, L_2);
		__this->set__methodName_8(L_3);
	}

IL_0027:
	{
		String_t* L_4 = __this->get__methodName_8();
		return L_4;
	}
}
// System.Object System.Runtime.Remoting.Messaging.ReturnMessage::get_MethodSignature()
extern Il2CppClass* TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage_get_MethodSignature_m776269126_MetadataUsageId;
extern "C"  Il2CppObject * ReturnMessage_get_MethodSignature_m776269126 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage_get_MethodSignature_m776269126_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	ParameterInfoU5BU5D_t2275869610* V_0 = NULL;
	int32_t V_1 = 0;
	{
		MethodBase_t904190842 * L_0 = __this->get__methodBase_7();
		if (!L_0)
		{
			goto IL_0054;
		}
	}
	{
		TypeU5BU5D_t1664964607* L_1 = __this->get__methodSignature_9();
		if (L_1)
		{
			goto IL_0054;
		}
	}
	{
		MethodBase_t904190842 * L_2 = __this->get__methodBase_7();
		ParameterInfoU5BU5D_t2275869610* L_3 = VirtFuncInvoker0< ParameterInfoU5BU5D_t2275869610* >::Invoke(14 /* System.Reflection.ParameterInfo[] System.Reflection.MethodBase::GetParameters() */, L_2);
		V_0 = L_3;
		ParameterInfoU5BU5D_t2275869610* L_4 = V_0;
		__this->set__methodSignature_9(((TypeU5BU5D_t1664964607*)SZArrayNew(TypeU5BU5D_t1664964607_il2cpp_TypeInfo_var, (uint32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_4)->max_length)))))));
		V_1 = 0;
		goto IL_004b;
	}

IL_0037:
	{
		TypeU5BU5D_t1664964607* L_5 = __this->get__methodSignature_9();
		int32_t L_6 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_7 = V_0;
		int32_t L_8 = V_1;
		int32_t L_9 = L_8;
		ParameterInfo_t2249040075 * L_10 = (L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
		Type_t * L_11 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.ParameterInfo::get_ParameterType() */, L_10);
		ArrayElementTypeCheck (L_5, L_11);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(L_6), (Type_t *)L_11);
		int32_t L_12 = V_1;
		V_1 = ((int32_t)((int32_t)L_12+(int32_t)1));
	}

IL_004b:
	{
		int32_t L_13 = V_1;
		ParameterInfoU5BU5D_t2275869610* L_14 = V_0;
		if ((((int32_t)L_13) < ((int32_t)(((int32_t)((int32_t)(((Il2CppArray *)L_14)->max_length)))))))
		{
			goto IL_0037;
		}
	}

IL_0054:
	{
		TypeU5BU5D_t1664964607* L_15 = __this->get__methodSignature_9();
		return (Il2CppObject *)L_15;
	}
}
// System.Collections.IDictionary System.Runtime.Remoting.Messaging.ReturnMessage::get_Properties()
extern Il2CppClass* MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage_get_Properties_m531965085_MetadataUsageId;
extern "C"  Il2CppObject * ReturnMessage_get_Properties_m531965085 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage_get_Properties_m531965085_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		MethodReturnDictionary_t981009581 * L_0 = __this->get__properties_11();
		if (L_0)
		{
			goto IL_0017;
		}
	}
	{
		MethodReturnDictionary_t981009581 * L_1 = (MethodReturnDictionary_t981009581 *)il2cpp_codegen_object_new(MethodReturnDictionary_t981009581_il2cpp_TypeInfo_var);
		MethodReturnDictionary__ctor_m756139344(L_1, __this, /*hidden argument*/NULL);
		__this->set__properties_11(L_1);
	}

IL_0017:
	{
		MethodReturnDictionary_t981009581 * L_2 = __this->get__properties_11();
		return L_2;
	}
}
// System.String System.Runtime.Remoting.Messaging.ReturnMessage::get_TypeName()
extern "C"  String_t* ReturnMessage_get_TypeName_m2348641442 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		MethodBase_t904190842 * L_0 = __this->get__methodBase_7();
		if (!L_0)
		{
			goto IL_002c;
		}
	}
	{
		String_t* L_1 = __this->get__typeName_10();
		if (L_1)
		{
			goto IL_002c;
		}
	}
	{
		MethodBase_t904190842 * L_2 = __this->get__methodBase_7();
		Type_t * L_3 = VirtFuncInvoker0< Type_t * >::Invoke(6 /* System.Type System.Reflection.MemberInfo::get_DeclaringType() */, L_2);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(15 /* System.String System.Type::get_AssemblyQualifiedName() */, L_3);
		__this->set__typeName_10(L_4);
	}

IL_002c:
	{
		String_t* L_5 = __this->get__typeName_10();
		return L_5;
	}
}
// System.String System.Runtime.Remoting.Messaging.ReturnMessage::get_Uri()
extern "C"  String_t* ReturnMessage_get_Uri_m2275427705 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		String_t* L_0 = __this->get__uri_5();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ReturnMessage::set_Uri(System.String)
extern "C"  void ReturnMessage_set_Uri_m961888476 (ReturnMessage_t3411975905 * __this, String_t* ___value0, const MethodInfo* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set__uri_5(L_0);
		return;
	}
}
// System.Exception System.Runtime.Remoting.Messaging.ReturnMessage::get_Exception()
extern "C"  Exception_t1927440687 * ReturnMessage_get_Exception_m3015034974 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		Exception_t1927440687 * L_0 = __this->get__exception_6();
		return L_0;
	}
}
// System.Object[] System.Runtime.Remoting.Messaging.ReturnMessage::get_OutArgs()
extern Il2CppClass* ArgInfo_t688271106_il2cpp_TypeInfo_var;
extern const uint32_t ReturnMessage_get_OutArgs_m299904174_MetadataUsageId;
extern "C"  ObjectU5BU5D_t3614634134* ReturnMessage_get_OutArgs_m299904174 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodIntialized;
	if (!s_Il2CppMethodIntialized)
	{
		il2cpp_codegen_initialize_method (ReturnMessage_get_OutArgs_m299904174_MetadataUsageId);
		s_Il2CppMethodIntialized = true;
	}
	{
		ObjectU5BU5D_t3614634134* L_0 = __this->get__outArgs_0();
		if (L_0)
		{
			goto IL_004a;
		}
	}
	{
		ObjectU5BU5D_t3614634134* L_1 = __this->get__args_1();
		if (!L_1)
		{
			goto IL_004a;
		}
	}
	{
		ArgInfo_t688271106 * L_2 = __this->get__inArgInfo_12();
		if (L_2)
		{
			goto IL_0033;
		}
	}
	{
		MethodBase_t904190842 * L_3 = ReturnMessage_get_MethodBase_m1666108195(__this, /*hidden argument*/NULL);
		ArgInfo_t688271106 * L_4 = (ArgInfo_t688271106 *)il2cpp_codegen_object_new(ArgInfo_t688271106_il2cpp_TypeInfo_var);
		ArgInfo__ctor_m3787931268(L_4, L_3, 1, /*hidden argument*/NULL);
		__this->set__inArgInfo_12(L_4);
	}

IL_0033:
	{
		ArgInfo_t688271106 * L_5 = __this->get__inArgInfo_12();
		ObjectU5BU5D_t3614634134* L_6 = __this->get__args_1();
		ObjectU5BU5D_t3614634134* L_7 = ArgInfo_GetInOutArgs_m3184132151(L_5, L_6, /*hidden argument*/NULL);
		__this->set__outArgs_0(L_7);
	}

IL_004a:
	{
		ObjectU5BU5D_t3614634134* L_8 = __this->get__outArgs_0();
		return L_8;
	}
}
// System.Object System.Runtime.Remoting.Messaging.ReturnMessage::get_ReturnValue()
extern "C"  Il2CppObject * ReturnMessage_get_ReturnValue_m3076211800 (ReturnMessage_t3411975905 * __this, const MethodInfo* method)
{
	{
		Il2CppObject * L_0 = __this->get__returnValue_4();
		return L_0;
	}
}
// System.Void System.Runtime.Remoting.Messaging.ServerContextTerminatorSink::.ctor()
extern "C"  void ServerContextTerminatorSink__ctor_m2130310560 (ServerContextTerminatorSink_t1054294306 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
