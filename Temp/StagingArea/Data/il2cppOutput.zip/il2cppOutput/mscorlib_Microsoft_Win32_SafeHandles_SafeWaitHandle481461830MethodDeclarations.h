﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Microsoft.Win32.SafeHandles.SafeWaitHandle
struct SafeWaitHandle_t481461830;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_IntPtr2504060609.h"

// System.Void Microsoft.Win32.SafeHandles.SafeWaitHandle::.ctor(System.IntPtr,System.Boolean)
extern "C"  void SafeWaitHandle__ctor_m1710231470 (SafeWaitHandle_t481461830 * __this, IntPtr_t ___existingHandle0, bool ___ownsHandle1, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean Microsoft.Win32.SafeHandles.SafeWaitHandle::ReleaseHandle()
extern "C"  bool SafeWaitHandle_ReleaseHandle_m634725016 (SafeWaitHandle_t481461830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
