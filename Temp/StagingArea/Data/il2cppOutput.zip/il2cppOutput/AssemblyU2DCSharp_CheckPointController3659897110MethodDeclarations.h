﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// CheckPointController
struct CheckPointController_t3659897110;
// UnityEngine.Collider2D
struct Collider2D_t646061738;

#include "codegen/il2cpp-codegen.h"
#include "UnityEngine_UnityEngine_Collider2D646061738.h"

// System.Void CheckPointController::.ctor()
extern "C"  void CheckPointController__ctor_m1792091381 (CheckPointController_t3659897110 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void CheckPointController::Start()
extern "C"  void CheckPointController_Start_m269525653 (CheckPointController_t3659897110 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void CheckPointController::Update()
extern "C"  void CheckPointController_Update_m2798027668 (CheckPointController_t3659897110 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void CheckPointController::OnTriggerEnter2D(UnityEngine.Collider2D)
extern "C"  void CheckPointController_OnTriggerEnter2D_m2617349309 (CheckPointController_t3659897110 * __this, Collider2D_t646061738 * ___other0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
