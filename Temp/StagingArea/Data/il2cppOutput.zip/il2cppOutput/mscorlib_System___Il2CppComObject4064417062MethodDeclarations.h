﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// System.__Il2CppComObject
struct Il2CppComObject;

#include "codegen/il2cpp-codegen.h"

// System.Void System.__Il2CppComObject::Finalize()
extern "C"  void __Il2CppComObject_Finalize_m1489232385 (Il2CppComObject * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
