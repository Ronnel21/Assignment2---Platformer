﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Runtime_Remoting_Messaging_StackBu1613771438.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapAttr1982224933.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapFiel3073759685.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapMeth2381910676.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapPara2780084514.h"
#include "mscorlib_System_Runtime_Remoting_Metadata_SoapType3444503085.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_ProxyAttr4031752430.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_Transpare3836393972.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_RealProxy298428346.h"
#include "mscorlib_System_Runtime_Remoting_Proxies_RemotingP2419155897.h"
#include "mscorlib_System_Runtime_Remoting_Services_Tracking3722365321.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedClientTy4060499430.h"
#include "mscorlib_System_Runtime_Remoting_ActivatedServiceT3934090848.h"
#include "mscorlib_System_Runtime_Remoting_EnvoyInfo815109115.h"
#include "mscorlib_System_Runtime_Remoting_Identity3647548000.h"
#include "mscorlib_System_Runtime_Remoting_ClientIdentity2254682501.h"
#include "mscorlib_System_Runtime_Remoting_InternalRemotingS3953136710.h"
#include "mscorlib_System_Runtime_Remoting_ObjRef318414488.h"
#include "mscorlib_System_Runtime_Remoting_RemotingConfigurat438177651.h"
#include "mscorlib_System_Runtime_Remoting_ConfigHandler2180714860.h"
#include "mscorlib_System_Runtime_Remoting_ChannelData1489610737.h"
#include "mscorlib_System_Runtime_Remoting_ProviderData2518653487.h"
#include "mscorlib_System_Runtime_Remoting_FormatterData12176916.h"
#include "mscorlib_System_Runtime_Remoting_RemotingException109604560.h"
#include "mscorlib_System_Runtime_Remoting_RemotingServices2399536837.h"
#include "mscorlib_System_Runtime_Remoting_ServerIdentity1656058977.h"
#include "mscorlib_System_Runtime_Remoting_ClientActivatedId1467784146.h"
#include "mscorlib_System_Runtime_Remoting_SingletonIdentity164722255.h"
#include "mscorlib_System_Runtime_Remoting_SingleCallIdentit3377680076.h"
#include "mscorlib_System_Runtime_Remoting_SoapServices3397513225.h"
#include "mscorlib_System_Runtime_Remoting_SoapServices_TypeIn59877052.h"
#include "mscorlib_System_Runtime_Remoting_TypeEntry3321373506.h"
#include "mscorlib_System_Runtime_Remoting_TypeInfo942537562.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownClientTy3314744170.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownObjectMo2630225581.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownServiceT1712728956.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B2351345412.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B2209278355.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_Bi141209596.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B3869872702.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_Bi419818242.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B1866979105.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B4119335253.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B1476095226.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B3000156221.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_B3123371156.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_Fo999493661.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_Fo943306207.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_T1182459634.h"
#include "mscorlib_System_Runtime_Serialization_FormatterConv764140214.h"
#include "mscorlib_System_Runtime_Serialization_FormatterSer3161112612.h"
#include "mscorlib_System_Runtime_Serialization_ObjectManage2645893724.h"
#include "mscorlib_System_Runtime_Serialization_BaseFixupRec3171032996.h"
#include "mscorlib_System_Runtime_Serialization_ArrayFixupRe1994227600.h"
#include "mscorlib_System_Runtime_Serialization_MultiArrayFix691510385.h"
#include "mscorlib_System_Runtime_Serialization_FixupRecord1044204179.h"
#include "mscorlib_System_Runtime_Serialization_DelayedFixup1033808295.h"
#include "mscorlib_System_Runtime_Serialization_ObjectRecord1923758778.h"
#include "mscorlib_System_Runtime_Serialization_ObjectRecord4134110382.h"
#include "mscorlib_System_Runtime_Serialization_OnDeserializ3172265744.h"
#include "mscorlib_System_Runtime_Serialization_OnDeserializi484921187.h"
#include "mscorlib_System_Runtime_Serialization_OnSerialized3742956097.h"
#include "mscorlib_System_Runtime_Serialization_OnSerializin2011372116.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio3985864818.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio2797915342.h"
#include "mscorlib_System_Runtime_Serialization_Serialization362827733.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio3485203212.h"
#include "mscorlib_System_Runtime_Serialization_Serialization753258759.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430.h"
#include "mscorlib_System_Runtime_Serialization_Serialization589103770.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon1417235061.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon4264247603.h"
#include "mscorlib_System_Security_Cryptography_X509Certifica283079845.h"
#include "mscorlib_System_Security_Cryptography_X509Certific1216946873.h"
#include "mscorlib_System_Security_Cryptography_AsymmetricAlg784058677.h"
#include "mscorlib_System_Security_Cryptography_AsymmetricKe3339648384.h"
#include "mscorlib_System_Security_Cryptography_AsymmetricSi3580832979.h"
#include "mscorlib_System_Security_Cryptography_AsymmetricSi4058014248.h"
#include "mscorlib_System_Security_Cryptography_Base64Consta4112722312.h"
#include "mscorlib_System_Security_Cryptography_CipherMode162592484.h"
#include "mscorlib_System_Security_Cryptography_CryptoConfig896479599.h"
#include "mscorlib_System_Security_Cryptography_Cryptographi3349726436.h"
#include "mscorlib_System_Security_Cryptography_Cryptographi4184064416.h"
#include "mscorlib_System_Security_Cryptography_CspParameters46065560.h"
#include "mscorlib_System_Security_Cryptography_CspProviderFl105264000.h"
#include "mscorlib_System_Security_Cryptography_DES1353513560.h"
#include "mscorlib_System_Security_Cryptography_DESTransform179750796.h"
#include "mscorlib_System_Security_Cryptography_DESCryptoServ933603253.h"
#include "mscorlib_System_Security_Cryptography_DSA903174880.h"
#include "mscorlib_System_Security_Cryptography_DSACryptoSer2915171657.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize500 = { sizeof (StackBuilderSink_t1613771438), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable500[2] = 
{
	StackBuilderSink_t1613771438::get_offset_of__target_0(),
	StackBuilderSink_t1613771438::get_offset_of__rp_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize501 = { sizeof (SoapAttribute_t1982224933), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable501[3] = 
{
	SoapAttribute_t1982224933::get_offset_of__useAttribute_0(),
	SoapAttribute_t1982224933::get_offset_of_ProtXmlNamespace_1(),
	SoapAttribute_t1982224933::get_offset_of_ReflectInfo_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize502 = { sizeof (SoapFieldAttribute_t3073759685), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable502[2] = 
{
	SoapFieldAttribute_t3073759685::get_offset_of__elementName_3(),
	SoapFieldAttribute_t3073759685::get_offset_of__isElement_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize503 = { sizeof (SoapMethodAttribute_t2381910676), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable503[6] = 
{
	SoapMethodAttribute_t2381910676::get_offset_of__responseElement_3(),
	SoapMethodAttribute_t2381910676::get_offset_of__responseNamespace_4(),
	SoapMethodAttribute_t2381910676::get_offset_of__returnElement_5(),
	SoapMethodAttribute_t2381910676::get_offset_of__soapAction_6(),
	SoapMethodAttribute_t2381910676::get_offset_of__useAttribute_7(),
	SoapMethodAttribute_t2381910676::get_offset_of__namespace_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize504 = { sizeof (SoapParameterAttribute_t2780084514), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize505 = { sizeof (SoapTypeAttribute_t3444503085), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable505[7] = 
{
	SoapTypeAttribute_t3444503085::get_offset_of__useAttribute_3(),
	SoapTypeAttribute_t3444503085::get_offset_of__xmlElementName_4(),
	SoapTypeAttribute_t3444503085::get_offset_of__xmlNamespace_5(),
	SoapTypeAttribute_t3444503085::get_offset_of__xmlTypeName_6(),
	SoapTypeAttribute_t3444503085::get_offset_of__xmlTypeNamespace_7(),
	SoapTypeAttribute_t3444503085::get_offset_of__isType_8(),
	SoapTypeAttribute_t3444503085::get_offset_of__isElement_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize506 = { sizeof (ProxyAttribute_t4031752430), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize507 = { sizeof (TransparentProxy_t3836393972), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable507[1] = 
{
	TransparentProxy_t3836393972::get_offset_of__rp_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize508 = { sizeof (RealProxy_t298428346), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable508[5] = 
{
	RealProxy_t298428346::get_offset_of_class_to_proxy_0(),
	RealProxy_t298428346::get_offset_of__targetDomainId_1(),
	RealProxy_t298428346::get_offset_of__targetUri_2(),
	RealProxy_t298428346::get_offset_of__objectIdentity_3(),
	RealProxy_t298428346::get_offset_of__objTP_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize509 = { sizeof (RemotingProxy_t2419155897), -1, sizeof(RemotingProxy_t2419155897_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable509[5] = 
{
	RemotingProxy_t2419155897_StaticFields::get_offset_of__cache_GetTypeMethod_5(),
	RemotingProxy_t2419155897_StaticFields::get_offset_of__cache_GetHashCodeMethod_6(),
	RemotingProxy_t2419155897::get_offset_of__sink_7(),
	RemotingProxy_t2419155897::get_offset_of__hasEnvoySink_8(),
	RemotingProxy_t2419155897::get_offset_of__ctorCall_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize510 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize511 = { sizeof (TrackingServices_t3722365321), -1, sizeof(TrackingServices_t3722365321_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable511[1] = 
{
	TrackingServices_t3722365321_StaticFields::get_offset_of__handlers_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize512 = { sizeof (ActivatedClientTypeEntry_t4060499430), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable512[2] = 
{
	ActivatedClientTypeEntry_t4060499430::get_offset_of_applicationUrl_2(),
	ActivatedClientTypeEntry_t4060499430::get_offset_of_obj_type_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize513 = { sizeof (ActivatedServiceTypeEntry_t3934090848), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable513[1] = 
{
	ActivatedServiceTypeEntry_t3934090848::get_offset_of_obj_type_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize514 = { sizeof (EnvoyInfo_t815109115), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable514[1] = 
{
	EnvoyInfo_t815109115::get_offset_of_envoySinks_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize515 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize516 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize517 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize518 = { sizeof (Identity_t3647548000), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable518[7] = 
{
	Identity_t3647548000::get_offset_of__objectUri_0(),
	Identity_t3647548000::get_offset_of__channelSink_1(),
	Identity_t3647548000::get_offset_of__envoySink_2(),
	Identity_t3647548000::get_offset_of__clientDynamicProperties_3(),
	Identity_t3647548000::get_offset_of__serverDynamicProperties_4(),
	Identity_t3647548000::get_offset_of__objRef_5(),
	Identity_t3647548000::get_offset_of__disposed_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize519 = { sizeof (ClientIdentity_t2254682501), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable519[1] = 
{
	ClientIdentity_t2254682501::get_offset_of__proxyReference_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize520 = { sizeof (InternalRemotingServices_t3953136710), -1, sizeof(InternalRemotingServices_t3953136710_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable520[1] = 
{
	InternalRemotingServices_t3953136710_StaticFields::get_offset_of__soapAttributes_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize521 = { sizeof (ObjRef_t318414488), -1, sizeof(ObjRef_t318414488_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable521[9] = 
{
	ObjRef_t318414488::get_offset_of_channel_info_0(),
	ObjRef_t318414488::get_offset_of_uri_1(),
	ObjRef_t318414488::get_offset_of_typeInfo_2(),
	ObjRef_t318414488::get_offset_of_envoyInfo_3(),
	ObjRef_t318414488::get_offset_of_flags_4(),
	ObjRef_t318414488::get_offset_of__serverType_5(),
	ObjRef_t318414488_StaticFields::get_offset_of_MarshalledObjectRef_6(),
	ObjRef_t318414488_StaticFields::get_offset_of_WellKnowObjectRef_7(),
	ObjRef_t318414488_StaticFields::get_offset_of_U3CU3Ef__switchU24map26_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize522 = { sizeof (RemotingConfiguration_t438177651), -1, sizeof(RemotingConfiguration_t438177651_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable522[13] = 
{
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_applicationID_0(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_applicationName_1(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_processGuid_2(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_defaultConfigRead_3(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_defaultDelayedConfigRead_4(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of__errorMode_5(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_wellKnownClientEntries_6(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_activatedClientEntries_7(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_wellKnownServiceEntries_8(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_activatedServiceEntries_9(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_channelTemplates_10(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_clientProviderTemplates_11(),
	RemotingConfiguration_t438177651_StaticFields::get_offset_of_serverProviderTemplates_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize523 = { sizeof (ConfigHandler_t2180714860), -1, sizeof(ConfigHandler_t2180714860_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable523[10] = 
{
	ConfigHandler_t2180714860::get_offset_of_typeEntries_0(),
	ConfigHandler_t2180714860::get_offset_of_channelInstances_1(),
	ConfigHandler_t2180714860::get_offset_of_currentChannel_2(),
	ConfigHandler_t2180714860::get_offset_of_currentProviderData_3(),
	ConfigHandler_t2180714860::get_offset_of_currentClientUrl_4(),
	ConfigHandler_t2180714860::get_offset_of_appName_5(),
	ConfigHandler_t2180714860::get_offset_of_currentXmlPath_6(),
	ConfigHandler_t2180714860::get_offset_of_onlyDelayedChannels_7(),
	ConfigHandler_t2180714860_StaticFields::get_offset_of_U3CU3Ef__switchU24map27_8(),
	ConfigHandler_t2180714860_StaticFields::get_offset_of_U3CU3Ef__switchU24map28_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize524 = { sizeof (ChannelData_t1489610737), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable524[7] = 
{
	ChannelData_t1489610737::get_offset_of_Ref_0(),
	ChannelData_t1489610737::get_offset_of_Type_1(),
	ChannelData_t1489610737::get_offset_of_Id_2(),
	ChannelData_t1489610737::get_offset_of_DelayLoadAsClientChannel_3(),
	ChannelData_t1489610737::get_offset_of__serverProviders_4(),
	ChannelData_t1489610737::get_offset_of__clientProviders_5(),
	ChannelData_t1489610737::get_offset_of__customProperties_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize525 = { sizeof (ProviderData_t2518653487), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable525[5] = 
{
	ProviderData_t2518653487::get_offset_of_Ref_0(),
	ProviderData_t2518653487::get_offset_of_Type_1(),
	ProviderData_t2518653487::get_offset_of_Id_2(),
	ProviderData_t2518653487::get_offset_of_CustomProperties_3(),
	ProviderData_t2518653487::get_offset_of_CustomData_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize526 = { sizeof (FormatterData_t12176916), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize527 = { sizeof (RemotingException_t109604560), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize528 = { sizeof (RemotingServices_t2399536837), -1, sizeof(RemotingServices_t2399536837_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable528[8] = 
{
	RemotingServices_t2399536837_StaticFields::get_offset_of_uri_hash_0(),
	RemotingServices_t2399536837_StaticFields::get_offset_of__serializationFormatter_1(),
	RemotingServices_t2399536837_StaticFields::get_offset_of__deserializationFormatter_2(),
	RemotingServices_t2399536837_StaticFields::get_offset_of_app_id_3(),
	RemotingServices_t2399536837_StaticFields::get_offset_of_next_id_4(),
	RemotingServices_t2399536837_StaticFields::get_offset_of_methodBindings_5(),
	RemotingServices_t2399536837_StaticFields::get_offset_of_FieldSetterMethod_6(),
	RemotingServices_t2399536837_StaticFields::get_offset_of_FieldGetterMethod_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize529 = { sizeof (ServerIdentity_t1656058977), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable529[3] = 
{
	ServerIdentity_t1656058977::get_offset_of__objectType_7(),
	ServerIdentity_t1656058977::get_offset_of__serverObject_8(),
	ServerIdentity_t1656058977::get_offset_of__context_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize530 = { sizeof (ClientActivatedIdentity_t1467784146), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize531 = { sizeof (SingletonIdentity_t164722255), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize532 = { sizeof (SingleCallIdentity_t3377680076), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize533 = { sizeof (SoapServices_t3397513225), -1, sizeof(SoapServices_t3397513225_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable533[5] = 
{
	SoapServices_t3397513225_StaticFields::get_offset_of__xmlTypes_0(),
	SoapServices_t3397513225_StaticFields::get_offset_of__xmlElements_1(),
	SoapServices_t3397513225_StaticFields::get_offset_of__soapActions_2(),
	SoapServices_t3397513225_StaticFields::get_offset_of__soapActionsMethods_3(),
	SoapServices_t3397513225_StaticFields::get_offset_of__typeInfos_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize534 = { sizeof (TypeInfo_t59877052), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable534[2] = 
{
	TypeInfo_t59877052::get_offset_of_Attributes_0(),
	TypeInfo_t59877052::get_offset_of_Elements_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize535 = { sizeof (TypeEntry_t3321373506), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable535[2] = 
{
	TypeEntry_t3321373506::get_offset_of_assembly_name_0(),
	TypeEntry_t3321373506::get_offset_of_type_name_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize536 = { sizeof (TypeInfo_t942537562), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable536[3] = 
{
	TypeInfo_t942537562::get_offset_of_serverType_0(),
	TypeInfo_t942537562::get_offset_of_serverHierarchy_1(),
	TypeInfo_t942537562::get_offset_of_interfacesImplemented_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize537 = { sizeof (WellKnownClientTypeEntry_t3314744170), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable537[3] = 
{
	WellKnownClientTypeEntry_t3314744170::get_offset_of_obj_type_2(),
	WellKnownClientTypeEntry_t3314744170::get_offset_of_obj_url_3(),
	WellKnownClientTypeEntry_t3314744170::get_offset_of_app_url_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize538 = { sizeof (WellKnownObjectMode_t2630225581)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable538[3] = 
{
	WellKnownObjectMode_t2630225581::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize539 = { sizeof (WellKnownServiceTypeEntry_t1712728956), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable539[3] = 
{
	WellKnownServiceTypeEntry_t1712728956::get_offset_of_obj_type_2(),
	WellKnownServiceTypeEntry_t1712728956::get_offset_of_obj_uri_3(),
	WellKnownServiceTypeEntry_t1712728956::get_offset_of_obj_mode_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize540 = { sizeof (BinaryCommon_t2351345412), -1, sizeof(BinaryCommon_t2351345412_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable540[4] = 
{
	BinaryCommon_t2351345412_StaticFields::get_offset_of_BinaryHeader_0(),
	BinaryCommon_t2351345412_StaticFields::get_offset_of__typeCodesToType_1(),
	BinaryCommon_t2351345412_StaticFields::get_offset_of__typeCodeMap_2(),
	BinaryCommon_t2351345412_StaticFields::get_offset_of_UseReflectionSerialization_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize541 = { sizeof (BinaryElement_t2209278355)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable541[24] = 
{
	BinaryElement_t2209278355::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize542 = { sizeof (TypeTag_t141209596)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable542[9] = 
{
	TypeTag_t141209596::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize543 = { sizeof (MethodFlags_t3869872702)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable543[11] = 
{
	MethodFlags_t3869872702::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize544 = { sizeof (ReturnTypeTag_t419818242)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable544[5] = 
{
	ReturnTypeTag_t419818242::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize545 = { sizeof (BinaryFormatter_t1866979105), -1, sizeof(BinaryFormatter_t1866979105_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable545[7] = 
{
	BinaryFormatter_t1866979105::get_offset_of_assembly_format_0(),
	BinaryFormatter_t1866979105::get_offset_of_binder_1(),
	BinaryFormatter_t1866979105::get_offset_of_context_2(),
	BinaryFormatter_t1866979105::get_offset_of_surrogate_selector_3(),
	BinaryFormatter_t1866979105::get_offset_of_type_format_4(),
	BinaryFormatter_t1866979105::get_offset_of_filter_level_5(),
	BinaryFormatter_t1866979105_StaticFields::get_offset_of_U3CDefaultSurrogateSelectorU3Ek__BackingField_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize546 = { sizeof (MessageFormatter_t4119335253), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize547 = { sizeof (ObjectReader_t1476095226), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable547[12] = 
{
	ObjectReader_t1476095226::get_offset_of__surrogateSelector_0(),
	ObjectReader_t1476095226::get_offset_of__context_1(),
	ObjectReader_t1476095226::get_offset_of__binder_2(),
	ObjectReader_t1476095226::get_offset_of__filterLevel_3(),
	ObjectReader_t1476095226::get_offset_of__manager_4(),
	ObjectReader_t1476095226::get_offset_of__registeredAssemblies_5(),
	ObjectReader_t1476095226::get_offset_of__typeMetadataCache_6(),
	ObjectReader_t1476095226::get_offset_of__lastObject_7(),
	ObjectReader_t1476095226::get_offset_of__lastObjectID_8(),
	ObjectReader_t1476095226::get_offset_of__rootObjectID_9(),
	ObjectReader_t1476095226::get_offset_of_arrayBuffer_10(),
	ObjectReader_t1476095226::get_offset_of_ArrayBufferLength_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize548 = { sizeof (TypeMetadata_t3000156221), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable548[6] = 
{
	TypeMetadata_t3000156221::get_offset_of_Type_0(),
	TypeMetadata_t3000156221::get_offset_of_MemberTypes_1(),
	TypeMetadata_t3000156221::get_offset_of_MemberNames_2(),
	TypeMetadata_t3000156221::get_offset_of_MemberInfos_3(),
	TypeMetadata_t3000156221::get_offset_of_FieldCount_4(),
	TypeMetadata_t3000156221::get_offset_of_NeedsSerializationInfo_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize549 = { sizeof (ArrayNullFiller_t3123371156), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable549[1] = 
{
	ArrayNullFiller_t3123371156::get_offset_of_NullCount_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize550 = { sizeof (FormatterAssemblyStyle_t999493661)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable550[3] = 
{
	FormatterAssemblyStyle_t999493661::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize551 = { sizeof (FormatterTypeStyle_t943306207)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable551[4] = 
{
	FormatterTypeStyle_t943306207::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize552 = { sizeof (TypeFilterLevel_t1182459634)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable552[3] = 
{
	TypeFilterLevel_t1182459634::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize553 = { sizeof (FormatterConverter_t764140214), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize554 = { sizeof (FormatterServices_t3161112612), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize555 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize556 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize557 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize558 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize559 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize560 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize561 = { sizeof (ObjectManager_t2645893724), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable561[9] = 
{
	ObjectManager_t2645893724::get_offset_of__objectRecordChain_0(),
	ObjectManager_t2645893724::get_offset_of__lastObjectRecord_1(),
	ObjectManager_t2645893724::get_offset_of__deserializedRecords_2(),
	ObjectManager_t2645893724::get_offset_of__onDeserializedCallbackRecords_3(),
	ObjectManager_t2645893724::get_offset_of__objectRecords_4(),
	ObjectManager_t2645893724::get_offset_of__finalFixup_5(),
	ObjectManager_t2645893724::get_offset_of__selector_6(),
	ObjectManager_t2645893724::get_offset_of__context_7(),
	ObjectManager_t2645893724::get_offset_of__registeredObjectsCount_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize562 = { sizeof (BaseFixupRecord_t3171032996), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable562[4] = 
{
	BaseFixupRecord_t3171032996::get_offset_of_ObjectToBeFixed_0(),
	BaseFixupRecord_t3171032996::get_offset_of_ObjectRequired_1(),
	BaseFixupRecord_t3171032996::get_offset_of_NextSameContainer_2(),
	BaseFixupRecord_t3171032996::get_offset_of_NextSameRequired_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize563 = { sizeof (ArrayFixupRecord_t1994227600), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable563[1] = 
{
	ArrayFixupRecord_t1994227600::get_offset_of__index_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize564 = { sizeof (MultiArrayFixupRecord_t691510385), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable564[1] = 
{
	MultiArrayFixupRecord_t691510385::get_offset_of__indices_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize565 = { sizeof (FixupRecord_t1044204179), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable565[1] = 
{
	FixupRecord_t1044204179::get_offset_of__member_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize566 = { sizeof (DelayedFixupRecord_t1033808295), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable566[1] = 
{
	DelayedFixupRecord_t1033808295::get_offset_of__memberName_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize567 = { sizeof (ObjectRecordStatus_t1923758778)+ sizeof (Il2CppObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable567[5] = 
{
	ObjectRecordStatus_t1923758778::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize568 = { sizeof (ObjectRecord_t4134110382), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable568[13] = 
{
	ObjectRecord_t4134110382::get_offset_of_Status_0(),
	ObjectRecord_t4134110382::get_offset_of_OriginalObject_1(),
	ObjectRecord_t4134110382::get_offset_of_ObjectInstance_2(),
	ObjectRecord_t4134110382::get_offset_of_ObjectID_3(),
	ObjectRecord_t4134110382::get_offset_of_Info_4(),
	ObjectRecord_t4134110382::get_offset_of_IdOfContainingObj_5(),
	ObjectRecord_t4134110382::get_offset_of_Surrogate_6(),
	ObjectRecord_t4134110382::get_offset_of_SurrogateSelector_7(),
	ObjectRecord_t4134110382::get_offset_of_Member_8(),
	ObjectRecord_t4134110382::get_offset_of_ArrayIndex_9(),
	ObjectRecord_t4134110382::get_offset_of_FixupChainAsContainer_10(),
	ObjectRecord_t4134110382::get_offset_of_FixupChainAsRequired_11(),
	ObjectRecord_t4134110382::get_offset_of_Next_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize569 = { sizeof (OnDeserializedAttribute_t3172265744), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize570 = { sizeof (OnDeserializingAttribute_t484921187), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize571 = { sizeof (OnSerializedAttribute_t3742956097), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize572 = { sizeof (OnSerializingAttribute_t2011372116), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize573 = { sizeof (SerializationBinder_t3985864818), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize574 = { sizeof (SerializationCallbacks_t2797915342), -1, sizeof(SerializationCallbacks_t2797915342_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable574[6] = 
{
	SerializationCallbacks_t2797915342::get_offset_of_onSerializingList_0(),
	SerializationCallbacks_t2797915342::get_offset_of_onSerializedList_1(),
	SerializationCallbacks_t2797915342::get_offset_of_onDeserializingList_2(),
	SerializationCallbacks_t2797915342::get_offset_of_onDeserializedList_3(),
	SerializationCallbacks_t2797915342_StaticFields::get_offset_of_cache_4(),
	SerializationCallbacks_t2797915342_StaticFields::get_offset_of_cache_lock_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize575 = { sizeof (CallbackHandler_t362827733), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize576 = { sizeof (SerializationEntry_t3485203212)+ sizeof (Il2CppObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable576[3] = 
{
	SerializationEntry_t3485203212::get_offset_of_name_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SerializationEntry_t3485203212::get_offset_of_objectType_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	SerializationEntry_t3485203212::get_offset_of_value_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize577 = { sizeof (SerializationException_t753258759), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize578 = { sizeof (SerializationInfo_t228987430), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable578[5] = 
{
	SerializationInfo_t228987430::get_offset_of_serialized_0(),
	SerializationInfo_t228987430::get_offset_of_values_1(),
	SerializationInfo_t228987430::get_offset_of_assemblyName_2(),
	SerializationInfo_t228987430::get_offset_of_fullTypeName_3(),
	SerializationInfo_t228987430::get_offset_of_converter_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize579 = { sizeof (SerializationInfoEnumerator_t589103770), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable579[1] = 
{
	SerializationInfoEnumerator_t589103770::get_offset_of_enumerator_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize580 = { sizeof (StreamingContext_t1417235061)+ sizeof (Il2CppObject), sizeof(StreamingContext_t1417235061_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable580[2] = 
{
	StreamingContext_t1417235061::get_offset_of_state_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	StreamingContext_t1417235061::get_offset_of_additional_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize581 = { sizeof (StreamingContextStates_t4264247603)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable581[10] = 
{
	StreamingContextStates_t4264247603::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize582 = { sizeof (X509Certificate_t283079845), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable582[5] = 
{
	X509Certificate_t283079845::get_offset_of_x509_0(),
	X509Certificate_t283079845::get_offset_of_hideDates_1(),
	X509Certificate_t283079845::get_offset_of_cachedCertificateHash_2(),
	X509Certificate_t283079845::get_offset_of_issuer_name_3(),
	X509Certificate_t283079845::get_offset_of_subject_name_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize583 = { sizeof (X509KeyStorageFlags_t1216946873)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable583[7] = 
{
	X509KeyStorageFlags_t1216946873::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize584 = { sizeof (AsymmetricAlgorithm_t784058677), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable584[2] = 
{
	AsymmetricAlgorithm_t784058677::get_offset_of_KeySizeValue_0(),
	AsymmetricAlgorithm_t784058677::get_offset_of_LegalKeySizesValue_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize585 = { sizeof (AsymmetricKeyExchangeFormatter_t3339648384), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize586 = { sizeof (AsymmetricSignatureDeformatter_t3580832979), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize587 = { sizeof (AsymmetricSignatureFormatter_t4058014248), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize588 = { sizeof (Base64Constants_t4112722312), -1, sizeof(Base64Constants_t4112722312_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable588[2] = 
{
	Base64Constants_t4112722312_StaticFields::get_offset_of_EncodeTable_0(),
	Base64Constants_t4112722312_StaticFields::get_offset_of_DecodeTable_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize589 = { sizeof (CipherMode_t162592484)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable589[6] = 
{
	CipherMode_t162592484::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize590 = { sizeof (CryptoConfig_t896479599), -1, sizeof(CryptoConfig_t896479599_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable590[3] = 
{
	CryptoConfig_t896479599_StaticFields::get_offset_of_lockObject_0(),
	CryptoConfig_t896479599_StaticFields::get_offset_of_algorithms_1(),
	CryptoConfig_t896479599_StaticFields::get_offset_of_oid_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize591 = { sizeof (CryptographicException_t3349726436), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize592 = { sizeof (CryptographicUnexpectedOperationException_t4184064416), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize593 = { sizeof (CspParameters_t46065560), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable593[5] = 
{
	CspParameters_t46065560::get_offset_of__Flags_0(),
	CspParameters_t46065560::get_offset_of_KeyContainerName_1(),
	CspParameters_t46065560::get_offset_of_KeyNumber_2(),
	CspParameters_t46065560::get_offset_of_ProviderName_3(),
	CspParameters_t46065560::get_offset_of_ProviderType_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize594 = { sizeof (CspProviderFlags_t105264000)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable594[9] = 
{
	CspProviderFlags_t105264000::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize595 = { sizeof (DES_t1353513560), -1, sizeof(DES_t1353513560_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable595[2] = 
{
	DES_t1353513560_StaticFields::get_offset_of_weakKeys_10(),
	DES_t1353513560_StaticFields::get_offset_of_semiWeakKeys_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize596 = { sizeof (DESTransform_t179750796), -1, sizeof(DESTransform_t179750796_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable596[13] = 
{
	DESTransform_t179750796_StaticFields::get_offset_of_KEY_BIT_SIZE_12(),
	DESTransform_t179750796_StaticFields::get_offset_of_KEY_BYTE_SIZE_13(),
	DESTransform_t179750796_StaticFields::get_offset_of_BLOCK_BIT_SIZE_14(),
	DESTransform_t179750796_StaticFields::get_offset_of_BLOCK_BYTE_SIZE_15(),
	DESTransform_t179750796::get_offset_of_keySchedule_16(),
	DESTransform_t179750796::get_offset_of_byteBuff_17(),
	DESTransform_t179750796::get_offset_of_dwordBuff_18(),
	DESTransform_t179750796_StaticFields::get_offset_of_spBoxes_19(),
	DESTransform_t179750796_StaticFields::get_offset_of_PC1_20(),
	DESTransform_t179750796_StaticFields::get_offset_of_leftRotTotal_21(),
	DESTransform_t179750796_StaticFields::get_offset_of_PC2_22(),
	DESTransform_t179750796_StaticFields::get_offset_of_ipTab_23(),
	DESTransform_t179750796_StaticFields::get_offset_of_fpTab_24(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize597 = { sizeof (DESCryptoServiceProvider_t933603253), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize598 = { sizeof (DSA_t903174880), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize599 = { sizeof (DSACryptoServiceProvider_t2915171657), -1, sizeof(DSACryptoServiceProvider_t2915171657_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable599[7] = 
{
	DSACryptoServiceProvider_t2915171657::get_offset_of_store_2(),
	DSACryptoServiceProvider_t2915171657::get_offset_of_persistKey_3(),
	DSACryptoServiceProvider_t2915171657::get_offset_of_persisted_4(),
	DSACryptoServiceProvider_t2915171657::get_offset_of_privateKeyExportable_5(),
	DSACryptoServiceProvider_t2915171657::get_offset_of_m_disposed_6(),
	DSACryptoServiceProvider_t2915171657::get_offset_of_dsa_7(),
	DSACryptoServiceProvider_t2915171657_StaticFields::get_offset_of_useMachineKeyStore_8(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
