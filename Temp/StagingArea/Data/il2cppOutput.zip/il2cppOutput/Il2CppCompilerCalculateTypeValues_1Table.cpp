﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>


#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator2636657155.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator_581002487.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator_169451053.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator1556892101.h"
#include "mscorlib_System_Globalization_SortKey1270563137.h"
#include "mscorlib_Mono_Globalization_Unicode_SortKeyBuffer1759538423.h"
#include "mscorlib_Mono_Math_Prime_Generator_PrimeGeneratorB1053438167.h"
#include "mscorlib_Mono_Math_Prime_Generator_SequentialSearch463670656.h"
#include "mscorlib_Mono_Math_Prime_ConfidenceFactor1997037801.h"
#include "mscorlib_Mono_Math_Prime_PrimalityTests3283102398.h"
#include "mscorlib_Mono_Math_BigInteger925946152.h"
#include "mscorlib_Mono_Math_BigInteger_Sign874893935.h"
#include "mscorlib_Mono_Math_BigInteger_ModulusRing80355991.h"
#include "mscorlib_Mono_Math_BigInteger_Kernel1353186455.h"
#include "mscorlib_Mono_Security_Cryptography_CryptoConvert4146607874.h"
#include "mscorlib_Mono_Security_Cryptography_KeyBuilder3965881084.h"
#include "mscorlib_Mono_Security_Cryptography_BlockProcessor3158419191.h"
#include "mscorlib_Mono_Security_Cryptography_DSAManaged892502321.h"
#include "mscorlib_Mono_Security_Cryptography_DSAManaged_Key2001522803.h"
#include "mscorlib_Mono_Security_Cryptography_KeyPairPersist3637935872.h"
#include "mscorlib_Mono_Security_Cryptography_MACAlgorithm2739465458.h"
#include "mscorlib_Mono_Security_Cryptography_PKCS13312870480.h"
#include "mscorlib_Mono_Security_Cryptography_PKCS82103016899.h"
#include "mscorlib_Mono_Security_Cryptography_PKCS8_PrivateKey92917103.h"
#include "mscorlib_Mono_Security_Cryptography_PKCS8_Encrypte1722354997.h"
#include "mscorlib_Mono_Security_Cryptography_RSAManaged3034748747.h"
#include "mscorlib_Mono_Security_Cryptography_RSAManaged_KeyG108853709.h"
#include "mscorlib_Mono_Security_Cryptography_SymmetricTrans1394030013.h"
#include "mscorlib_Mono_Security_X509_SafeBag2166702855.h"
#include "mscorlib_Mono_Security_X509_PKCS121362584794.h"
#include "mscorlib_Mono_Security_X509_PKCS12_DeriveBytes1740753016.h"
#include "mscorlib_Mono_Security_X509_X501349661534.h"
#include "mscorlib_Mono_Security_X509_X509Certificate324051957.h"
#include "mscorlib_Mono_Security_X509_X509CertificateCollect3592472865.h"
#include "mscorlib_Mono_Security_X509_X509CertificateCollect3487770522.h"
#include "mscorlib_Mono_Security_X509_X509Extension1439760127.h"
#include "mscorlib_Mono_Security_X509_X509ExtensionCollectio1640144839.h"
#include "mscorlib_Mono_Security_ASN1924533535.h"
#include "mscorlib_Mono_Security_ASN1Convert3301846396.h"
#include "mscorlib_Mono_Security_BitConverterLE2825370260.h"
#include "mscorlib_Mono_Security_PKCS73223261922.h"
#include "mscorlib_Mono_Security_PKCS7_ContentInfo1443605387.h"
#include "mscorlib_Mono_Security_PKCS7_EncryptedData2656813772.h"
#include "mscorlib_Mono_Security_StrongName117835354.h"
#include "mscorlib_Mono_Xml_SecurityParser30730985.h"
#include "mscorlib_Mono_Xml_SmallXmlParser3549787957.h"
#include "mscorlib_Mono_Xml_SmallXmlParser_AttrListImpl4015491015.h"
#include "mscorlib_Mono_Xml_SmallXmlParserException2094031034.h"
#include "mscorlib_Mono_Runtime530188530.h"
#include "mscorlib_System_Collections_Generic_Link2723257478.h"
#include "mscorlib_System_Collections_Generic_KeyNotFoundExc1722175009.h"
#include "mscorlib_System_Collections_ArrayList4252133567.h"
#include "mscorlib_System_Collections_ArrayList_SimpleEnumera579048438.h"
#include "mscorlib_System_Collections_ArrayList_ArrayListWra3918858854.h"
#include "mscorlib_System_Collections_ArrayList_Synchronized3317806524.h"
#include "mscorlib_System_Collections_ArrayList_FixedSizeArr3816042801.h"
#include "mscorlib_System_Collections_ArrayList_ReadOnlyArra4044524772.h"
#include "mscorlib_System_Collections_BitArray4180138994.h"
#include "mscorlib_System_Collections_BitArray_BitArrayEnume4029388769.h"
#include "mscorlib_System_Collections_CaseInsensitiveComparer157661140.h"
#include "mscorlib_System_Collections_CaseInsensitiveHashCod2307530285.h"
#include "mscorlib_System_Collections_CollectionBase1101587467.h"
#include "mscorlib_System_Collections_CollectionDebuggerView1643796100.h"
#include "mscorlib_System_Collections_Comparer3673668605.h"
#include "mscorlib_System_Collections_DictionaryEntry3048875398.h"
#include "mscorlib_System_Collections_Hashtable909839986.h"
#include "mscorlib_System_Collections_Hashtable_Slot2022531261.h"
#include "mscorlib_System_Collections_Hashtable_KeyMarker4029226070.h"
#include "mscorlib_System_Collections_Hashtable_EnumeratorMo2734922732.h"
#include "mscorlib_System_Collections_Hashtable_Enumerator2466348361.h"
#include "mscorlib_System_Collections_Hashtable_HashKeys187688763.h"
#include "mscorlib_System_Collections_Hashtable_HashValues2390200547.h"
#include "mscorlib_System_Collections_Hashtable_SyncHashtabl1343674558.h"



#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize100 = { sizeof (Context_t2636657155)+ sizeof (Il2CppObject), sizeof(Context_t2636657155_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable100[8] = 
{
	Context_t2636657155::get_offset_of_Option_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_NeverMatchFlags_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_AlwaysMatchFlags_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_Buffer1_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_Buffer2_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_PrevCode_5() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_PrevSortKey_6() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Context_t2636657155::get_offset_of_QuickCheckPossible_7() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize101 = { sizeof (PreviousInfo_t581002487)+ sizeof (Il2CppObject), sizeof(PreviousInfo_t581002487_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable101[2] = 
{
	PreviousInfo_t581002487::get_offset_of_Code_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	PreviousInfo_t581002487::get_offset_of_SortKey_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize102 = { sizeof (Escape_t169451053)+ sizeof (Il2CppObject), sizeof(Escape_t169451053_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable102[5] = 
{
	Escape_t169451053::get_offset_of_Source_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Escape_t169451053::get_offset_of_Index_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Escape_t169451053::get_offset_of_Start_2() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Escape_t169451053::get_offset_of_End_3() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Escape_t169451053::get_offset_of_Optional_4() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize103 = { sizeof (ExtenderType_t1556892101)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable103[6] = 
{
	ExtenderType_t1556892101::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize104 = { sizeof (SortKey_t1270563137), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable104[4] = 
{
	SortKey_t1270563137::get_offset_of_source_0(),
	SortKey_t1270563137::get_offset_of_options_1(),
	SortKey_t1270563137::get_offset_of_key_2(),
	SortKey_t1270563137::get_offset_of_lcid_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize105 = { sizeof (SortKeyBuffer_t1759538423), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable105[22] = 
{
	SortKeyBuffer_t1759538423::get_offset_of_l1_0(),
	SortKeyBuffer_t1759538423::get_offset_of_l2_1(),
	SortKeyBuffer_t1759538423::get_offset_of_l3_2(),
	SortKeyBuffer_t1759538423::get_offset_of_l4s_3(),
	SortKeyBuffer_t1759538423::get_offset_of_l4t_4(),
	SortKeyBuffer_t1759538423::get_offset_of_l4k_5(),
	SortKeyBuffer_t1759538423::get_offset_of_l4w_6(),
	SortKeyBuffer_t1759538423::get_offset_of_l5_7(),
	SortKeyBuffer_t1759538423::get_offset_of_l1b_8(),
	SortKeyBuffer_t1759538423::get_offset_of_l2b_9(),
	SortKeyBuffer_t1759538423::get_offset_of_l3b_10(),
	SortKeyBuffer_t1759538423::get_offset_of_l4sb_11(),
	SortKeyBuffer_t1759538423::get_offset_of_l4tb_12(),
	SortKeyBuffer_t1759538423::get_offset_of_l4kb_13(),
	SortKeyBuffer_t1759538423::get_offset_of_l4wb_14(),
	SortKeyBuffer_t1759538423::get_offset_of_l5b_15(),
	SortKeyBuffer_t1759538423::get_offset_of_source_16(),
	SortKeyBuffer_t1759538423::get_offset_of_processLevel2_17(),
	SortKeyBuffer_t1759538423::get_offset_of_frenchSort_18(),
	SortKeyBuffer_t1759538423::get_offset_of_frenchSorted_19(),
	SortKeyBuffer_t1759538423::get_offset_of_lcid_20(),
	SortKeyBuffer_t1759538423::get_offset_of_options_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize106 = { sizeof (PrimeGeneratorBase_t1053438167), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize107 = { sizeof (SequentialSearchPrimeGeneratorBase_t463670656), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize108 = { sizeof (ConfidenceFactor_t1997037801)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable108[7] = 
{
	ConfidenceFactor_t1997037801::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize109 = { sizeof (PrimalityTests_t3283102398), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize110 = { sizeof (BigInteger_t925946152), -1, sizeof(BigInteger_t925946152_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable110[4] = 
{
	BigInteger_t925946152::get_offset_of_length_0(),
	BigInteger_t925946152::get_offset_of_data_1(),
	BigInteger_t925946152_StaticFields::get_offset_of_smallPrimes_2(),
	BigInteger_t925946152_StaticFields::get_offset_of_rng_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize111 = { sizeof (Sign_t874893935)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable111[4] = 
{
	Sign_t874893935::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize112 = { sizeof (ModulusRing_t80355991), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable112[2] = 
{
	ModulusRing_t80355991::get_offset_of_mod_0(),
	ModulusRing_t80355991::get_offset_of_constant_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize113 = { sizeof (Kernel_t1353186455), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize114 = { sizeof (CryptoConvert_t4146607874), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize115 = { sizeof (KeyBuilder_t3965881084), -1, sizeof(KeyBuilder_t3965881084_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable115[1] = 
{
	KeyBuilder_t3965881084_StaticFields::get_offset_of_rng_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize116 = { sizeof (BlockProcessor_t3158419191), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable116[4] = 
{
	BlockProcessor_t3158419191::get_offset_of_transform_0(),
	BlockProcessor_t3158419191::get_offset_of_block_1(),
	BlockProcessor_t3158419191::get_offset_of_blockSize_2(),
	BlockProcessor_t3158419191::get_offset_of_blockCount_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize117 = { sizeof (DSAManaged_t892502321), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable117[13] = 
{
	DSAManaged_t892502321::get_offset_of_keypairGenerated_2(),
	DSAManaged_t892502321::get_offset_of_m_disposed_3(),
	DSAManaged_t892502321::get_offset_of_p_4(),
	DSAManaged_t892502321::get_offset_of_q_5(),
	DSAManaged_t892502321::get_offset_of_g_6(),
	DSAManaged_t892502321::get_offset_of_x_7(),
	DSAManaged_t892502321::get_offset_of_y_8(),
	DSAManaged_t892502321::get_offset_of_j_9(),
	DSAManaged_t892502321::get_offset_of_seed_10(),
	DSAManaged_t892502321::get_offset_of_counter_11(),
	DSAManaged_t892502321::get_offset_of_j_missing_12(),
	DSAManaged_t892502321::get_offset_of_rng_13(),
	DSAManaged_t892502321::get_offset_of_KeyGenerated_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize118 = { sizeof (KeyGeneratedEventHandler_t2001522803), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize119 = { sizeof (KeyPairPersistence_t3637935872), -1, sizeof(KeyPairPersistence_t3637935872_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable119[9] = 
{
	KeyPairPersistence_t3637935872_StaticFields::get_offset_of__userPathExists_0(),
	KeyPairPersistence_t3637935872_StaticFields::get_offset_of__userPath_1(),
	KeyPairPersistence_t3637935872_StaticFields::get_offset_of__machinePathExists_2(),
	KeyPairPersistence_t3637935872_StaticFields::get_offset_of__machinePath_3(),
	KeyPairPersistence_t3637935872::get_offset_of__params_4(),
	KeyPairPersistence_t3637935872::get_offset_of__keyvalue_5(),
	KeyPairPersistence_t3637935872::get_offset_of__filename_6(),
	KeyPairPersistence_t3637935872::get_offset_of__container_7(),
	KeyPairPersistence_t3637935872_StaticFields::get_offset_of_lockobj_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize120 = { sizeof (MACAlgorithm_t2739465458), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable120[5] = 
{
	MACAlgorithm_t2739465458::get_offset_of_algo_0(),
	MACAlgorithm_t2739465458::get_offset_of_enc_1(),
	MACAlgorithm_t2739465458::get_offset_of_block_2(),
	MACAlgorithm_t2739465458::get_offset_of_blockSize_3(),
	MACAlgorithm_t2739465458::get_offset_of_blockCount_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize121 = { sizeof (PKCS1_t3312870480), -1, sizeof(PKCS1_t3312870480_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable121[4] = 
{
	PKCS1_t3312870480_StaticFields::get_offset_of_emptySHA1_0(),
	PKCS1_t3312870480_StaticFields::get_offset_of_emptySHA256_1(),
	PKCS1_t3312870480_StaticFields::get_offset_of_emptySHA384_2(),
	PKCS1_t3312870480_StaticFields::get_offset_of_emptySHA512_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize122 = { sizeof (PKCS8_t2103016899), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize123 = { sizeof (PrivateKeyInfo_t92917103), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable123[4] = 
{
	PrivateKeyInfo_t92917103::get_offset_of__version_0(),
	PrivateKeyInfo_t92917103::get_offset_of__algorithm_1(),
	PrivateKeyInfo_t92917103::get_offset_of__key_2(),
	PrivateKeyInfo_t92917103::get_offset_of__list_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize124 = { sizeof (EncryptedPrivateKeyInfo_t1722354997), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable124[4] = 
{
	EncryptedPrivateKeyInfo_t1722354997::get_offset_of__algorithm_0(),
	EncryptedPrivateKeyInfo_t1722354997::get_offset_of__salt_1(),
	EncryptedPrivateKeyInfo_t1722354997::get_offset_of__iterations_2(),
	EncryptedPrivateKeyInfo_t1722354997::get_offset_of__data_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize125 = { sizeof (RSAManaged_t3034748747), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable125[13] = 
{
	RSAManaged_t3034748747::get_offset_of_isCRTpossible_2(),
	RSAManaged_t3034748747::get_offset_of_keyBlinding_3(),
	RSAManaged_t3034748747::get_offset_of_keypairGenerated_4(),
	RSAManaged_t3034748747::get_offset_of_m_disposed_5(),
	RSAManaged_t3034748747::get_offset_of_d_6(),
	RSAManaged_t3034748747::get_offset_of_p_7(),
	RSAManaged_t3034748747::get_offset_of_q_8(),
	RSAManaged_t3034748747::get_offset_of_dp_9(),
	RSAManaged_t3034748747::get_offset_of_dq_10(),
	RSAManaged_t3034748747::get_offset_of_qInv_11(),
	RSAManaged_t3034748747::get_offset_of_n_12(),
	RSAManaged_t3034748747::get_offset_of_e_13(),
	RSAManaged_t3034748747::get_offset_of_KeyGenerated_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize126 = { sizeof (KeyGeneratedEventHandler_t108853709), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize127 = { sizeof (SymmetricTransform_t1394030013), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable127[12] = 
{
	SymmetricTransform_t1394030013::get_offset_of_algo_0(),
	SymmetricTransform_t1394030013::get_offset_of_encrypt_1(),
	SymmetricTransform_t1394030013::get_offset_of_BlockSizeByte_2(),
	SymmetricTransform_t1394030013::get_offset_of_temp_3(),
	SymmetricTransform_t1394030013::get_offset_of_temp2_4(),
	SymmetricTransform_t1394030013::get_offset_of_workBuff_5(),
	SymmetricTransform_t1394030013::get_offset_of_workout_6(),
	SymmetricTransform_t1394030013::get_offset_of_FeedBackByte_7(),
	SymmetricTransform_t1394030013::get_offset_of_FeedBackIter_8(),
	SymmetricTransform_t1394030013::get_offset_of_m_disposed_9(),
	SymmetricTransform_t1394030013::get_offset_of_lastBlock_10(),
	SymmetricTransform_t1394030013::get_offset_of__rng_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize128 = { sizeof (SafeBag_t2166702855), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable128[2] = 
{
	SafeBag_t2166702855::get_offset_of__bagOID_0(),
	SafeBag_t2166702855::get_offset_of__asn1_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize129 = { sizeof (PKCS12_t1362584794), -1, sizeof(PKCS12_t1362584794_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable129[17] = 
{
	PKCS12_t1362584794_StaticFields::get_offset_of_recommendedIterationCount_0(),
	PKCS12_t1362584794::get_offset_of__password_1(),
	PKCS12_t1362584794::get_offset_of__keyBags_2(),
	PKCS12_t1362584794::get_offset_of__secretBags_3(),
	PKCS12_t1362584794::get_offset_of__certs_4(),
	PKCS12_t1362584794::get_offset_of__keyBagsChanged_5(),
	PKCS12_t1362584794::get_offset_of__secretBagsChanged_6(),
	PKCS12_t1362584794::get_offset_of__certsChanged_7(),
	PKCS12_t1362584794::get_offset_of__iterations_8(),
	PKCS12_t1362584794::get_offset_of__safeBags_9(),
	PKCS12_t1362584794::get_offset_of__rng_10(),
	PKCS12_t1362584794_StaticFields::get_offset_of_password_max_length_11(),
	PKCS12_t1362584794_StaticFields::get_offset_of_U3CU3Ef__switchU24map8_12(),
	PKCS12_t1362584794_StaticFields::get_offset_of_U3CU3Ef__switchU24map9_13(),
	PKCS12_t1362584794_StaticFields::get_offset_of_U3CU3Ef__switchU24mapA_14(),
	PKCS12_t1362584794_StaticFields::get_offset_of_U3CU3Ef__switchU24mapB_15(),
	PKCS12_t1362584794_StaticFields::get_offset_of_U3CU3Ef__switchU24mapF_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize130 = { sizeof (DeriveBytes_t1740753016), -1, sizeof(DeriveBytes_t1740753016_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable130[7] = 
{
	DeriveBytes_t1740753016_StaticFields::get_offset_of_keyDiversifier_0(),
	DeriveBytes_t1740753016_StaticFields::get_offset_of_ivDiversifier_1(),
	DeriveBytes_t1740753016_StaticFields::get_offset_of_macDiversifier_2(),
	DeriveBytes_t1740753016::get_offset_of__hashName_3(),
	DeriveBytes_t1740753016::get_offset_of__iterations_4(),
	DeriveBytes_t1740753016::get_offset_of__password_5(),
	DeriveBytes_t1740753016::get_offset_of__salt_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize131 = { sizeof (X501_t349661534), -1, sizeof(X501_t349661534_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable131[15] = 
{
	X501_t349661534_StaticFields::get_offset_of_countryName_0(),
	X501_t349661534_StaticFields::get_offset_of_organizationName_1(),
	X501_t349661534_StaticFields::get_offset_of_organizationalUnitName_2(),
	X501_t349661534_StaticFields::get_offset_of_commonName_3(),
	X501_t349661534_StaticFields::get_offset_of_localityName_4(),
	X501_t349661534_StaticFields::get_offset_of_stateOrProvinceName_5(),
	X501_t349661534_StaticFields::get_offset_of_streetAddress_6(),
	X501_t349661534_StaticFields::get_offset_of_domainComponent_7(),
	X501_t349661534_StaticFields::get_offset_of_userid_8(),
	X501_t349661534_StaticFields::get_offset_of_email_9(),
	X501_t349661534_StaticFields::get_offset_of_dnQualifier_10(),
	X501_t349661534_StaticFields::get_offset_of_title_11(),
	X501_t349661534_StaticFields::get_offset_of_surname_12(),
	X501_t349661534_StaticFields::get_offset_of_givenName_13(),
	X501_t349661534_StaticFields::get_offset_of_initial_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize132 = { sizeof (X509Certificate_t324051957), -1, sizeof(X509Certificate_t324051957_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable132[21] = 
{
	X509Certificate_t324051957::get_offset_of_decoder_0(),
	X509Certificate_t324051957::get_offset_of_m_encodedcert_1(),
	X509Certificate_t324051957::get_offset_of_m_from_2(),
	X509Certificate_t324051957::get_offset_of_m_until_3(),
	X509Certificate_t324051957::get_offset_of_issuer_4(),
	X509Certificate_t324051957::get_offset_of_m_issuername_5(),
	X509Certificate_t324051957::get_offset_of_m_keyalgo_6(),
	X509Certificate_t324051957::get_offset_of_m_keyalgoparams_7(),
	X509Certificate_t324051957::get_offset_of_subject_8(),
	X509Certificate_t324051957::get_offset_of_m_subject_9(),
	X509Certificate_t324051957::get_offset_of_m_publickey_10(),
	X509Certificate_t324051957::get_offset_of_signature_11(),
	X509Certificate_t324051957::get_offset_of_m_signaturealgo_12(),
	X509Certificate_t324051957::get_offset_of_m_signaturealgoparams_13(),
	X509Certificate_t324051957::get_offset_of__dsa_14(),
	X509Certificate_t324051957::get_offset_of_version_15(),
	X509Certificate_t324051957::get_offset_of_serialnumber_16(),
	X509Certificate_t324051957::get_offset_of_issuerUniqueID_17(),
	X509Certificate_t324051957::get_offset_of_subjectUniqueID_18(),
	X509Certificate_t324051957::get_offset_of_extensions_19(),
	X509Certificate_t324051957_StaticFields::get_offset_of_encoding_error_20(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize133 = { sizeof (X509CertificateCollection_t3592472865), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize134 = { sizeof (X509CertificateEnumerator_t3487770522), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable134[1] = 
{
	X509CertificateEnumerator_t3487770522::get_offset_of_enumerator_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize135 = { sizeof (X509Extension_t1439760127), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable135[3] = 
{
	X509Extension_t1439760127::get_offset_of_extnOid_0(),
	X509Extension_t1439760127::get_offset_of_extnCritical_1(),
	X509Extension_t1439760127::get_offset_of_extnValue_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize136 = { sizeof (X509ExtensionCollection_t1640144839), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable136[1] = 
{
	X509ExtensionCollection_t1640144839::get_offset_of_readOnly_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize137 = { sizeof (ASN1_t924533535), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable137[3] = 
{
	ASN1_t924533535::get_offset_of_m_nTag_0(),
	ASN1_t924533535::get_offset_of_m_aValue_1(),
	ASN1_t924533535::get_offset_of_elist_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize138 = { sizeof (ASN1Convert_t3301846396), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize139 = { sizeof (BitConverterLE_t2825370260), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize140 = { sizeof (PKCS7_t3223261922), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize141 = { sizeof (ContentInfo_t1443605387), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable141[2] = 
{
	ContentInfo_t1443605387::get_offset_of_contentType_0(),
	ContentInfo_t1443605387::get_offset_of_content_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize142 = { sizeof (EncryptedData_t2656813772), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable142[4] = 
{
	EncryptedData_t2656813772::get_offset_of__version_0(),
	EncryptedData_t2656813772::get_offset_of__content_1(),
	EncryptedData_t2656813772::get_offset_of__encryptionAlgorithm_2(),
	EncryptedData_t2656813772::get_offset_of__encrypted_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize143 = { sizeof (StrongName_t117835354), -1, sizeof(StrongName_t117835354_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable143[6] = 
{
	StrongName_t117835354::get_offset_of_rsa_0(),
	StrongName_t117835354::get_offset_of_publicKey_1(),
	StrongName_t117835354::get_offset_of_keyToken_2(),
	StrongName_t117835354::get_offset_of_tokenAlgorithm_3(),
	StrongName_t117835354_StaticFields::get_offset_of_lockObject_4(),
	StrongName_t117835354_StaticFields::get_offset_of_initialized_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize144 = { sizeof (SecurityParser_t30730985), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable144[3] = 
{
	SecurityParser_t30730985::get_offset_of_root_13(),
	SecurityParser_t30730985::get_offset_of_current_14(),
	SecurityParser_t30730985::get_offset_of_stack_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize145 = { sizeof (SmallXmlParser_t3549787957), -1, sizeof(SmallXmlParser_t3549787957_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable145[13] = 
{
	SmallXmlParser_t3549787957::get_offset_of_handler_0(),
	SmallXmlParser_t3549787957::get_offset_of_reader_1(),
	SmallXmlParser_t3549787957::get_offset_of_elementNames_2(),
	SmallXmlParser_t3549787957::get_offset_of_xmlSpaces_3(),
	SmallXmlParser_t3549787957::get_offset_of_xmlSpace_4(),
	SmallXmlParser_t3549787957::get_offset_of_buffer_5(),
	SmallXmlParser_t3549787957::get_offset_of_nameBuffer_6(),
	SmallXmlParser_t3549787957::get_offset_of_isWhitespace_7(),
	SmallXmlParser_t3549787957::get_offset_of_attributes_8(),
	SmallXmlParser_t3549787957::get_offset_of_line_9(),
	SmallXmlParser_t3549787957::get_offset_of_column_10(),
	SmallXmlParser_t3549787957::get_offset_of_resetColumn_11(),
	SmallXmlParser_t3549787957_StaticFields::get_offset_of_U3CU3Ef__switchU24map18_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize146 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize147 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize148 = { sizeof (AttrListImpl_t4015491015), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable148[2] = 
{
	AttrListImpl_t4015491015::get_offset_of_attrNames_0(),
	AttrListImpl_t4015491015::get_offset_of_attrValues_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize149 = { sizeof (SmallXmlParserException_t2094031034), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable149[2] = 
{
	SmallXmlParserException_t2094031034::get_offset_of_line_11(),
	SmallXmlParserException_t2094031034::get_offset_of_column_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize150 = { sizeof (Runtime_t530188530), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize151 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize152 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize153 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable153[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize154 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize155 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize156 = { sizeof (Link_t2723257478)+ sizeof (Il2CppObject), sizeof(Link_t2723257478_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable156[2] = 
{
	Link_t2723257478::get_offset_of_HashCode_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Link_t2723257478::get_offset_of_Next_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize157 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable157[16] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize158 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable158[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize159 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable159[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize160 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable160[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize161 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable161[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize162 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize163 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable163[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize164 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize165 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize166 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize167 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize168 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize169 = { sizeof (KeyNotFoundException_t1722175009), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize170 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable170[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize171 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable171[5] = 
{
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize172 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable172[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize173 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable173[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize174 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable174[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize175 = { sizeof (ArrayList_t4252133567), -1, sizeof(ArrayList_t4252133567_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable175[5] = 
{
	0,
	ArrayList_t4252133567::get_offset_of__size_1(),
	ArrayList_t4252133567::get_offset_of__items_2(),
	ArrayList_t4252133567::get_offset_of__version_3(),
	ArrayList_t4252133567_StaticFields::get_offset_of_EmptyArray_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize176 = { sizeof (SimpleEnumerator_t579048438), -1, sizeof(SimpleEnumerator_t579048438_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable176[5] = 
{
	SimpleEnumerator_t579048438::get_offset_of_list_0(),
	SimpleEnumerator_t579048438::get_offset_of_index_1(),
	SimpleEnumerator_t579048438::get_offset_of_version_2(),
	SimpleEnumerator_t579048438::get_offset_of_currentElement_3(),
	SimpleEnumerator_t579048438_StaticFields::get_offset_of_endFlag_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize177 = { sizeof (ArrayListWrapper_t3918858854), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable177[1] = 
{
	ArrayListWrapper_t3918858854::get_offset_of_m_InnerArrayList_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize178 = { sizeof (SynchronizedArrayListWrapper_t3317806524), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable178[1] = 
{
	SynchronizedArrayListWrapper_t3317806524::get_offset_of_m_SyncRoot_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize179 = { sizeof (FixedSizeArrayListWrapper_t3816042801), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize180 = { sizeof (ReadOnlyArrayListWrapper_t4044524772), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize181 = { sizeof (BitArray_t4180138994), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable181[3] = 
{
	BitArray_t4180138994::get_offset_of_m_array_0(),
	BitArray_t4180138994::get_offset_of_m_length_1(),
	BitArray_t4180138994::get_offset_of__version_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize182 = { sizeof (BitArrayEnumerator_t4029388769), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable182[4] = 
{
	BitArrayEnumerator_t4029388769::get_offset_of__bitArray_0(),
	BitArrayEnumerator_t4029388769::get_offset_of__current_1(),
	BitArrayEnumerator_t4029388769::get_offset_of__index_2(),
	BitArrayEnumerator_t4029388769::get_offset_of__version_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize183 = { sizeof (CaseInsensitiveComparer_t157661140), -1, sizeof(CaseInsensitiveComparer_t157661140_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable183[3] = 
{
	CaseInsensitiveComparer_t157661140_StaticFields::get_offset_of_defaultComparer_0(),
	CaseInsensitiveComparer_t157661140_StaticFields::get_offset_of_defaultInvariantComparer_1(),
	CaseInsensitiveComparer_t157661140::get_offset_of_culture_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize184 = { sizeof (CaseInsensitiveHashCodeProvider_t2307530285), -1, sizeof(CaseInsensitiveHashCodeProvider_t2307530285_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable184[3] = 
{
	CaseInsensitiveHashCodeProvider_t2307530285_StaticFields::get_offset_of_singletonInvariant_0(),
	CaseInsensitiveHashCodeProvider_t2307530285_StaticFields::get_offset_of_sync_1(),
	CaseInsensitiveHashCodeProvider_t2307530285::get_offset_of_m_text_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize185 = { sizeof (CollectionBase_t1101587467), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable185[1] = 
{
	CollectionBase_t1101587467::get_offset_of_list_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize186 = { sizeof (CollectionDebuggerView_t1643796100), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize187 = { sizeof (Comparer_t3673668605), -1, sizeof(Comparer_t3673668605_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable187[3] = 
{
	Comparer_t3673668605_StaticFields::get_offset_of_Default_0(),
	Comparer_t3673668605_StaticFields::get_offset_of_DefaultInvariant_1(),
	Comparer_t3673668605::get_offset_of_m_compareInfo_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize188 = { sizeof (DictionaryEntry_t3048875398)+ sizeof (Il2CppObject), sizeof(DictionaryEntry_t3048875398_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable188[2] = 
{
	DictionaryEntry_t3048875398::get_offset_of__key_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	DictionaryEntry_t3048875398::get_offset_of__value_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize189 = { sizeof (Hashtable_t909839986), -1, sizeof(Hashtable_t909839986_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable189[14] = 
{
	0,
	Hashtable_t909839986::get_offset_of_inUse_1(),
	Hashtable_t909839986::get_offset_of_modificationCount_2(),
	Hashtable_t909839986::get_offset_of_loadFactor_3(),
	Hashtable_t909839986::get_offset_of_table_4(),
	Hashtable_t909839986::get_offset_of_hashes_5(),
	Hashtable_t909839986::get_offset_of_threshold_6(),
	Hashtable_t909839986::get_offset_of_hashKeys_7(),
	Hashtable_t909839986::get_offset_of_hashValues_8(),
	Hashtable_t909839986::get_offset_of_hcpRef_9(),
	Hashtable_t909839986::get_offset_of_comparerRef_10(),
	Hashtable_t909839986::get_offset_of_serializationInfo_11(),
	Hashtable_t909839986::get_offset_of_equalityComparer_12(),
	Hashtable_t909839986_StaticFields::get_offset_of_primeTbl_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize190 = { sizeof (Slot_t2022531261)+ sizeof (Il2CppObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable190[2] = 
{
	Slot_t2022531261::get_offset_of_key_0() + static_cast<int32_t>(sizeof(Il2CppObject)),
	Slot_t2022531261::get_offset_of_value_1() + static_cast<int32_t>(sizeof(Il2CppObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize191 = { sizeof (KeyMarker_t4029226070), -1, sizeof(KeyMarker_t4029226070_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable191[1] = 
{
	KeyMarker_t4029226070_StaticFields::get_offset_of_Removed_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize192 = { sizeof (EnumeratorMode_t2734922732)+ sizeof (Il2CppObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable192[4] = 
{
	EnumeratorMode_t2734922732::get_offset_of_value___1() + static_cast<int32_t>(sizeof(Il2CppObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize193 = { sizeof (Enumerator_t2466348361), -1, sizeof(Enumerator_t2466348361_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable193[8] = 
{
	Enumerator_t2466348361::get_offset_of_host_0(),
	Enumerator_t2466348361::get_offset_of_stamp_1(),
	Enumerator_t2466348361::get_offset_of_pos_2(),
	Enumerator_t2466348361::get_offset_of_size_3(),
	Enumerator_t2466348361::get_offset_of_mode_4(),
	Enumerator_t2466348361::get_offset_of_currentKey_5(),
	Enumerator_t2466348361::get_offset_of_currentValue_6(),
	Enumerator_t2466348361_StaticFields::get_offset_of_xstr_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize194 = { sizeof (HashKeys_t187688763), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable194[1] = 
{
	HashKeys_t187688763::get_offset_of_host_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize195 = { sizeof (HashValues_t2390200547), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable195[1] = 
{
	HashValues_t2390200547::get_offset_of_host_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize196 = { sizeof (SyncHashtable_t1343674558), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable196[1] = 
{
	SyncHashtable_t1343674558::get_offset_of_host_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize197 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize198 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize199 = { 0, -1, 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
